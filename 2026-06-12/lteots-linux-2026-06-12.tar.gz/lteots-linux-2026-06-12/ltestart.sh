#!/bin/bash
# Copyright (C) 2012-2026 Amarisoft
# LTE system starter version 2026-06-12

#export LC_ALL=C

user=$(whoami)

# Goto script directory
OTSDIR=$(dirname "$(readlink -f "$0")")
cd "$OTSDIR"


##########
# Config #
##########
if [ -e "config/ots.cfg" ] ; then
    cd config
    source "ots.cfg"
    cd ..
fi

# Use system hostname or configured one ?
if [ "$HOSTNAME" = "" ] ; then
    HOSTNAME="$(hostname)"
else
    HOSTNAME="${HOSTNAME//|/ }"
fi


#############
# Functions #
#############
function Log
{
    LOG="$(date '+%Y-%m-%d %H:%M:%S') [OTS] - $1: $2"
    if [ "$3" = "" ] ; then
        echo -e "$LOG"
    else
        echo -e "$LOG\n$(echo -ne "$3" | sed -e "s/$(echo -e \\033)\[[[:digit:]]*m//g" | sed -e "s/^/        /")"
    fi
}

function BackupLog
{
    local comp state N
    comp="$1"
    state="$2"

    if [ "$state" = "stop" ] && [ "$LOG_BACKUP_ON_STOP" = "n" ] ; then
        return
    fi

    CompGetVar "$comp" "LOG_FILE"

    if [ -e "$CLOG_FILE" ] && [ "$LOG_PATH" != "" ] ; then
        # Analyze first lines
        N="200"

        # Avoid storing logs with comments only
        HAS_LOG=$(head -n $N "$CLOG_FILE" | grep -v -l "#")
        if [ "$HAS_LOG" != "" ] ; then
            BackupLog1 "$comp" "$CLOG_FILE"
        else
            rm -f "$CLOG_FILE"
        fi
    fi
}

function BackupLog1
{
    local comp SRC mode DST
    comp="$1"
    SRC="$2"
    mode="$3"

    if [ "$LOG_PATH" != "" ] ; then
        DST="$LOG_PATH/$(basename "$SRC")"
    else
        DST="$SRC"
    fi
    DST+=".$(date +%Y%m%d.%H:%M:%S | sed -e "s/ /-/g")"

    Log "$comp" "Backup logs: $DST"
    if [ "$mode" = "empty" ] ; then
        cp "$SRC" "$DST"
        truncate -s 0 "$SRC"
    else
        mv "$SRC" "$DST"
    fi
}

function KillPID
{
    local comp var name
    comp="$1"
    var="$2"
    name="$3"

    pid=${!var}
    if [ "$pid" != "" ] ; then
        Log "$comp" "Kill $name process: $pid"
        kill -9 "$pid" 2>/dev/null
    fi
}

function KillCompPID
{
    local comp var name
    comp="$1"
    var="$2"
    name="$3"

    KillPID "$comp" "${comp}_${var}" "$name"
}

STOP_TIMEOUT="15"

function SignalHandler
{
    local comp STOP TIMEOUT
    Log "OTS" "Stopping service"

    # Close fifo
    rm -f "$FIFO_EVENT"
    FIFO_EVENT=""
    exec 3<&-

    # Clean screen/windows
    #WINDOWS=$(screen -S lte -Q windows | grep -P -o '\b\d+\b') # Fails on Ubuntu
    WINDOWS="$WIN_LIST"

    # Quit programs normally
    for i in $WINDOWS ; do
        # Normal quit
        screen -S lte -p "$i" -X stuff $'\nquit\n' 1>/dev/null
        sleep 0.1
    done

    # Stop MONITOR
    #KillPID "MONITOR" "PID_POLL" "poll"

    # Wait components to be stopped
    STOP="1"
    TIMEOUT=$(( $(date +%s) + STOP_TIMEOUT ))
    while [ $TIMEOUT -gt "$(date +%s)" ] ; do
        STOP="1"
        for comp in $COMP_LIST ; do
            PID="${comp}_PID_LAUNCHER"
            if [ "${!PID}" = "" ] ; then continue; fi

            # Check if processes still alive
            kill -0 "${!PID}" 1>/dev/null 2>&1
            if [ "$?" != "0" ] ; then
                Log "$comp" "Component stopped"
                eval "$PID="
            else
                STOP="0"
                Log "$comp" "Component stopping"
            fi
        done
        if [ "$STOP" = "1" ] ; then break; fi
        sleep 1
    done

    # Kill component processes
    for comp in $COMP_LIST ; do
        KillCompPID "$comp" "PID_INIT" "init"
        KillCompPID "$comp" "PID_ERROR" "error"
        KillCompPID "$comp" "PID_LAUNCHER" "launcher"
    done

    for i in $WINDOWS ; do
        sleep 0.3
        screen -S lte -p "$i" -X quit 1>/dev/null
    done

    # Backup logs
    for comp in $COMP_LIST ; do
        CompExecScript "$comp" "stopped" "Service stop"
        BackupLog "$comp" "stop"
    done

    BackupLog "MON" "stop"
    rm -f "$FIFO_MONITOR"

    rm -f "$WWW_CFG"

    ScreenFlush

    # Hyperthreading
    UpdateHT "$HT_STATE" "$HT_SYS_STATE"

    Log "OTS" "Service stopped"
    rm -f "$FIFO_EVENT"

    # Hack wait bit for all resources to be released in case of restart
    sleep 1

    exit 0
}

function SendEvent
{
    if [ "$FIFO_EVENT" != "" ] ; then
        echo "$1" > "$FIFO_EVENT"
    fi
}

function CompGetVar
{
    local comp tmp
    comp="$1"
    shift

    while [ "$1" != "" ] ; do
        tmp="${comp}_${1}"
        if [ ! -z ${!tmp+x} ] ; then
            eval "C${1}=\"${!tmp}\""
        else
            unset "C${1}"
        fi
        shift
    done
}

function CompSetVar
{
    local comp
    comp="$1"
    eval "${comp}_${2}=\"${3}\""
    eval "C${2}=\"${3}\"" # Update current
}

function CompSetFile
{
    local comp name file
    comp="$1"
    name="$2"
    file="$3"

    if [ "$file" != "" ] ; then
        CompSetVar "$comp" "$name" "$file"
    else
        file="C$name"
        file=${!file}
        if [ "${file}" = "" ] ; then
            return;
        fi
    fi

    if [[ "${file:0:1}" == / || "${file:0:2}" == ~[/a-z] ]] ; then
        CompSetVar "$comp" "${name}_FULL" "$file"
    else
        CompSetVar "$comp" "${name}_FULL" "$CPATH/$file"
    fi
}

function CompExec
{
    CompGetVar "$1" "WIN"

    if [ "$CWIN" != "" ] ; then
        screen -S lte -p "$CWIN" -X stuff $'\n' # Empty line in case of

        shift
        while [ "$1" != "" ] ; do
            screen -S lte -p "$CWIN" -X stuff "$1"$'\n'
            shift
        done
    fi
}

COMP_LIST=""
WIN_LIST=""
MME_LIST=""
ENB_LIST=""

function ScreenCreate
{
    # Remove pending sessions
    ScreenFlush

    Log "OTS" "Create screen session"
    which systemd-run 1>/dev/null 2>&1
    if [ "$?" = "0" ] ; then
        RET=$(systemd-run --scope screen -dm -S lte -c screenrc 2>&1)
        if [ "$?" != "0" ] ; then
            Log "OTS" "systemd-run error: $RET"
            screen -dm -S lte -c screenrc
        fi
    else
        screen -dm -S lte -c screenrc
    fi

    # Wait 5s fr creation completion
    timeout 5s bash <<EOT
    while true ; do
        if [ "$(screen -ls | grep lte)" != "" ] ; then
            exit 0
        fi
    done
EOT
    if [ "$?" != "0" ] ; then
        echo "Warning, timeout while creating screen session"
    fi
}

function ScreenFlush
{
    # Check remaining sessions
    REMAIN=$(screen -ls | grep Detached | grep -w lte | awk '{print $1;}')
    if [ "$REMAIN" != "" ] ; then
        # Try to kill them the usual way
        for i in $REMAIN ; do
            Log "OTS" "Flush previous screen session $i"
            screen -S "$i" -X kill
            sleep 1
        done
        screen -wipe 1>/dev/null

        # If PIDS are remaining (Ex: Ubuntu 14), kill them !!!
        PIDS=$(ps x | grep -w lte | grep screen | awk '{print $1;}')
        if [ "$PIDS" != "" ] ; then
            for p in $PIDS ; do
                Log "OTS" "Kill remaining lte screen"
                kill -9 "$p"
            done
            screen -wipe 1>/dev/null
        fi
    fi
}

function CompCreate
{
    local comp
    comp="$1"

    # Retrieve associated vars
    CompGetVar "$comp" "PATH" "INIT" "WIN" "CONFIG_FILE" "OUTPUT_FILE" "TYPE" "SCRIPT" "TITLE" "AUTOSTART"

    # Default type is component name
    if [ "$CTYPE" = "" ] ; then
        CompSetVar "$comp" "TYPE" "$comp"
    fi

    # Get associated program and check it type is valid
    local prog="PROG_$CTYPE"
    prog="${!prog}"
    if [ "$prog" = "" ] ; then
        Log "OTS" "$comp has invalid type: $CTYPE"
        return
    fi

    # Exists ?
    if [ "$CPATH" = "" ] ; then return; fi
    if [ ! -e "$CPATH/$prog" ] ; then return; fi

    # Init vars
    CompSetVar "$comp" "PROG" "$prog"
    CompSetState "$comp" "stopped"

    CompSetFile "$comp" "CONFIG_FILE"
    CompSetFile "$comp" "SCRIPT"

    # Redirect stdout with stderr ?
    if [ "$COUTPUT_FILE" != "" ] ; then
        CompSetVar "$comp" "OUTPUT_TYPE" "stdout"
        CompSetFile "$comp" "OUTPUT_FILE"
    else
        CompSetVar "$comp" "OUTPUT_TYPE" "stderr"
        CompSetFile "$comp" "OUTPUT_FILE" "/tmp/.stderr.$comp"
    fi

    if [ "$CAUTOSTART" = "" ] ; then
        CompSetVar "$comp" "AUTOSTART" "y"
    fi

    # Window # to comp
    eval "WIN_$CWIN=\"$comp\""

    # Screen session
    if [ "$COMP_LIST" = "" ] ; then
        ScreenCreate
        Log "$comp" "Set window #$CWIN for $comp"
        screen -S lte -X number "$CWIN"

        COMP_LIST="$comp"
        WIN_LIST="$CWIN"
    else
        Log "$comp" "Create window #$CWIN for $comp"
        screen -S lte -X screen "$CWIN"

        COMP_LIST="$comp $COMP_LIST"
        WIN_LIST+=" $CWIN"
    fi

    if [ "$CTITLE" = "" ] ; then
        CompSetVar "$comp" "TITLE" "$comp"
        CTITLE="$comp"
    fi

    case "$CTYPE" in
    MME)
        MME_LIST+=" $comp"
        ;;
    ENB)
        ENB_LIST+=" $comp"
        ;;
    esac

    # Set title after unseting PROMPT_COMMAND, using directly -X title may fail
    screen -S lte -p "$CWIN" -X stuff "unset PROMPT_COMMAND; unset command_not_found_handle; screen -S lte -p \"$CWIN\" -X title \"($CTITLE)\""$'\n'
    screen -S lte -p "$CWIN" -X stuff "cd \"$CPATH\""$'\n'
    screen -S lte -p "$CWIN" -X stuff "clear"$'\n'
}

function CompSetAutostart
{
    local comp auto
    comp="$1"
    auto="$2"

    Log "$comp" "Autostart: $auto"

    CompGetVar "$comp" "AUTOSTART"
    if [ "$CAUTOSTART" != "$auto" ] ; then
        touch "$CONFIG_FILE"
        if [ "$(grep "${comp}_AUTOSTART" "$CONFIG_FILE")" != "" ] ; then
            perl -p -i -e "s/${comp}_AUTOSTART=.*/${comp}_AUTOSTART=$auto/" "$CONFIG_FILE"
        else
            echo "${comp}_AUTOSTART=$auto" >> "$CONFIG_FILE"
        fi
        CompSetVar "$comp" "AUTOSTART" "$auto"
        CompPoll "$comp"
    fi
}

function CompSendMonitor
{
    local MSG
    if [ -e "$FIFO_MONITOR" ] ; then
        # One line
        MSG=$(echo -n "$1" | tr "\n" "|")
        # Truncate line, it shouldn't exceed page size to keep atomic operation on fifo
        echo "${MSG:0:2048}" > "$FIFO_MONITOR"
    fi
}

function CompError
{
    local comp section error msg LIFETIME error_str OIFS msg1
    comp="$1"
    section="$2"
    error="$3"
    msg="$4"

    msg=${msg:0:1000}
    msg=${msg//\`/\'}

    Log "$comp" "$section error: $error" "$msg"

    # Count errors to wait longer
    CompGetVar "$comp" "ERROR" "ERROR_STR" "START_TIME"

    CompSetState "$comp" "error" "$section|$error|$msg"
    WWWUpdateComp "$comp" "$error: $msg"

    # Notify
    LIFETIME="0"
    error_str="[$section] $error: $msg"
    if [ "$section" != "RUNTIME" ] ; then
        msg1=$(echo "$error_str" | head -n 1)
        screen -S lte -X echo "[$comp]${msg1:0:80}"
        if [ "$error_str" != "$CERROR_STR" ] ; then
            OIFS=$IFS
            IFS=$'\n'
            CompGetVar "$comp" "WIN"
            screen -S lte -p "$CWIN" -X stuff $'\n' # Empty line in case of
            for i in $(echo -e "$error_str") ; do
                screen -S lte -p "$CWIN" -X stuff "# $i"$'\n'
            done
            IFS=$OIFS
        fi
    else
        LIFETIME=$(( $(date +%s) - CSTART_TIME ))
    fi
    CompSetVar "$comp" "ERROR_STR" "$error_str"

    (
        # Wait before retrying
        if [ $LIFETIME -lt 60 ] ; then
            Log "$comp" "Restart in ${ERROR_DELAY}s"
            sleep "$ERROR_DELAY"
        fi
        SendEvent "$comp|restart"
    ) &
    CompSetVar "$comp" "PID_ERROR" "$!"
}

function CompExecScript
{
    local comp state msg ERR
    comp="$1"
    state="$2"
    msg="$3"

    CompGetVar "$comp" "PATH" "SCRIPT_FULL"

    # Custom script
    if [ -e "$CSCRIPT_FULL" ] ; then
        if [ -x "$CSCRIPT_FULL" ] ; then
            RES=$(cd "$CPATH" && $CSCRIPT_FULL "$comp" "$state" "$msg" 2>&1)
            ERR="$?"
            if [ "$ERR" != "0" ] ; then
                Log "$comp" "$CSCRIPT_FULL error: $ERR" "$RES"
            elif [ "$RES" != "" ] ; then
                Log "$comp" "$CSCRIPT_FULL" "$RES"
            fi
        else
            Log "$comp" "$CSCRIPT_FULL is lacking execution permission"
        fi
    fi
}

function CompSetState
{
    local comp="$1"
    local state="$2"
    local msg="$3"
    if [ "$msg" != "" ] ; then
        msg=$(echo -ne "$3" | sed -e "s/$(echo -e \\033)\[[[:digit:]]*m//g")
    fi

    CompSetVar "$comp" "STATE" "$state"
    CompSendMonitor "state|$comp|$state|$msg"

    CompExecScript "$comp" "$state" "$msg"

    CompGetVar "$comp" "WIN" "TITLE"
    case "$state" in
    started)
        screen -S lte -p "$CWIN" -X title "$CTITLE"
        ;;
    error)
        screen -S lte -p "$CWIN" -X title "$CTITLE!"
        ;;
    stopped|disabled)
        screen -S lte -p "$CWIN" -X title "($CTITLE)"
        ;;
    *)
        screen -S lte -p "$CWIN" -X title "$CTITLE..."
        ;;
    esac
}

function CompConfigValue
{
    set -o pipefail
    CVALUE=$(./json_util dump "$CCONFIG_FILE_FULL" "$1" 2>/dev/null | sed -e 's/"//g')
    CERROR="$?"
    set +o pipefail
}

function CompPollStarted
{
    local comp="$1"
    local timeout="$2"

    CompGetVar "$comp" "LOG_FILE"

    # Poll log file for started event
    if [ "$CLOG_FILE" != "" ] ; then
        STARTED=""
        for i in $(seq "$timeout") ; do
            if [ -e "$CLOG_FILE" ] ; then
                STARTED=$(grep -m 1 "# Started" "$CLOG_FILE")
                if [ "$STARTED" != "" ] ; then break; fi
            fi
            sleep 1
        done
        if [ "$STARTED" = "" ] ; then
            Log "$comp" "Warning: start timeout"
        fi
    fi
    SendEvent "$comp|started"
}

function CompPoll
{
    local comp S PORT PROG LIVE VAR
    comp="$1"

    # Check readyness
    CompGetVar "$comp" "AUTOSTART" "DEP" "STATE"
    if [ "$CAUTOSTART" != "y" ] ; then 
        if [ "$CSTATE" != "disabled" ] ; then
            if [ "$CSTATE" = "started" ] || [ "$CSTATE" = "starting" ] ; then
                CompExec "$comp" "quit"
            fi
            CompSetState "$comp" "disabled"
        fi
    else
        if [ "$CSTATE" = "disabled" ] ; then
            CompSetState "$comp" "stopped"
        fi
    fi
    if [ "$CSTATE" != "stopped" ] ; then return; fi
    for i in $CDEP ; do
        S="${i}_STATE"
        if [ "${!S}" != "started" ] ; then return; fi
    done

    CompGetVar "$comp" "PATH" "PROG" "ARGS" "CONFIG_FILE" "CONFIG_FILE_FULL" "WIN" "OUTPUT_TYPE" "OUTPUT_FILE" "TYPE" "TITLE" "INIT" "START_DELAY" "RRH_CHECK" "CMDLINE_ARGS"

    Log "$comp" "Starting"
    CompSetState "$comp" "starting"

    # Check config file is defined
    if [ -e "$CCONFIG_FILE_FULL" ] ; then

        # Check config file validity
        ERROR=$(./json_util test "$CCONFIG_FILE_FULL" 2>&1 )
        if [ "$?" != "0" ] ; then
            CompError "$comp" "CONFIG" "Syntax error" "$ERROR"
            return
        fi

        # COM interface
        CompConfigValue "com_addr"
        if [ "$CERROR" = "0" ] && [ "$CVALUE" != "" ] ; then
            PORT=$(echo "$CVALUE" | awk '{n=split($0,a,":"); print a[n]}')
            if [ "$PORT" = "" ] ; then PORT="9000"; fi
            CompSetVar "$comp" "COM_PORT" "$PORT"
            WWWUpdateComp "$comp"
        fi

        # Log file
        CompConfigValue "log_filename"
        if [ "$CERROR" = "0" ] && [ "$CVALUE" != "" ] ; then
            CompSetVar "$comp" "LOG_FILE" "$(readlink -f "$CVALUE")"
            LIVE="$(readlink -f "$WWW_PATH/live")/"
            if [ "${CLOG_FILE:0:${#LIVE}}" = "$LIVE" ] ; then
                WWWUpdate "$comp" "live" "${CLOG_FILE:${#LIVE}}"
            fi
        fi
    else
        CompGetVar "$comp" "MODE"
        if [ "$CMODE" != "standalone" ] ; then
            CompError "$comp" "CONFIG" "Missing" "$CCONFIG_FILE_FULL"
            return
        fi
    fi

    # Backup logs before starting
    BackupLog "$comp"

    PROG="./$CPROG"
    if [ "$CARGS" != "" ] ; then
        PROG+=" $CARGS"
    fi
    Log "START" "prod=$PROD_MODEL type=$CTYPE"

    # Restrict CPU
    RTCPUInit
    if [ "$RT_CPUSET" != "" ] ; then
        PROG="taskset $RT_CPUSET $PROG"
    fi

    case "${PROD_MODEL:0:2}" in
    CB)
        if [ "$MME_LIST" != "" ] && [ "$ENB_LIST" != "" ] ; then
            PROG+=" -D GTP_U_BUNDLING"
        fi
        ;;
    esac

    # ltelaunch config
    LAUNCH_CFG="$CPATH/.launch.$comp"
    rm -f "$LAUNCH_CFG"
    cat > "$LAUNCH_CFG" << LAUNCH_END
FIFO="$FIFO_EVENT"
COMP="$comp"
PROG="$PROG"
ARGS="$CCMDLINE_ARGS"
CONFIG="$CCONFIG_FILE"
OUTPUT_TYPE="$COUTPUT_TYPE"
OUTPUT_FILE="$COUTPUT_FILE"
LAUNCH_END

    # Async init
    {
        # lte_init.sh
        if [ ! -z ${CINIT+x} ] ; then
            Log "$comp" "Initialize with option '$CINIT'"
            INIT=$("$CPATH/lte_init.sh" $CINIT 2>&1)
            RES="$?"
            if [ "$RES" == "0" ] ; then
                Log "$comp" "Init success" "$INIT"
            else
                Log "$comp" "Init error" "$INIT"
            fi
            SendEvent "$comp|init|$RES"
        fi

        # Radio frontend
        # Legacy compatibility (2022/05/20)
        case "$CTYPE" in
        UE|ENB)
            VAR="${comp}_RRH_CHECK"
            if [ -z "${!VAR+x}" ] ; then
                eval "$VAR=\"config/rf_driver/rrh_check.sh\""
                CompGetVar "$comp" "RRH_CHECK"
            fi
            ;;
        esac

        # Check rrh
        if [ "$CRRH_CHECK" != "" ] ; then
            SCRIPT=$(echo "$CRRH_CHECK" | cut -d ' ' -f1)
            if [ "${SCRIPT:0:1}" != "/" ] ; then
                SCRIPT="$CPATH/$SCRIPT"
                CRRH_CHECK="$CPATH/$CRRH_CHECK"
            fi
            if [ -e "$SCRIPT" ] ; then
                set -o pipefail
                RRH=$($CRRH_CHECK --cfg "$CCONFIG_FILE_FULL" --temp 100 2>&1)
                RES="$?"
                if [ "$RES" == "0" ] ; then
                    Log "$comp" "RF frontend checked" "$RRH"
                else
                    Log "$comp" "RF frontend error" "$RRH"
                    SendEvent "$comp|error|RRH_CHECK"
                    exit 0
                fi
            fi
        fi

        # Wait ?
        if [ "$CSTART_DELAY" != "" ] ; then
            Log "$comp" "INIT" "Wait ${CSTART_DELAY}s"
            sleep "$CSTART_DELAY"
        fi

        SendEvent "$comp|launch|"

        # Poll log file for started event
        CompPollStarted "$comp" "45"
    } &
    CompSetVar "$comp" "PID_INIT" "$!"
}

function WWWUpdate
{
    local comp type value pattern
    comp="$1"
    type="$2"
    shift
    shift

    # Add WS
    if [ -d "$WWW_PATH" ]; then
        # Add params
        value="$1"
        shift
        for i in "$@" ; do
            value+="#$i"
        done

        # Remove and add
        pattern="${comp}#${type}#"
        perl -p -i -e "s/${pattern}.*\n//" "$WWW_CFG"
        echo "${pattern}${value}" >> "$WWW_CFG"
    fi
}

function WWWUpdateComp
{
    local comp msg
    comp="$1"
    msg="$2"

    msg=$(echo -e "$msg" | head -n 1)

    CompGetVar "$comp" "COM_PORT" "TITLE" "TYPE"
    WWWUpdate "$comp" "ws" "$CTYPE" "$HOSTNAME-$comp" "$CCOM_PORT" "$CTITLE" "$msg"
}

########
# Logs #
########
function UpdateSize
{
    local SIZE
    for S in "$@" ; do
        SIZE=$(( $(echo "${!S}" | sed -e "s/K/*1000/;s/M/*1000000/;s/G/*1000000000/") ))
        eval "$S=\"$SIZE\""
    done
}

function LogPollStart
{
    # Fork polling
    (
        UpdateSize "LOG_SIZE" "LOG_FILE_SIZE"

        # Legacy forces no unit to be KB
        LOG_PERSISTENT_SIZE=$(( $(echo "$LOG_PERSISTENT_SIZE" | sed -e "s/K/*1/;s/M/*1000/;s/G/*1000000/") ))

        cd "$LOG_PATH"
        while true ; do
            sleep "$LOG_POLL_DELAY"

            # Compress logs if needed
            if [[ "$LOG_GZIP" -gt "0" ]] ; then
                # Not too much as it may last a while
                LIST=$(find . -maxdepth 1 -type f -printf "%f\n" | grep -v "$LOG_FILE$" | grep -v "gz$" | xargs -r ls -tra | head -n $LOG_GZIP)
                for i in $LIST ; do
                    Log "OTS" "Compress $i"
                    gzip "$i"
                done
            fi

            # Remove logs if too much
            CLEAN="n"
            TSIZE=$(du -ks . | cut -d $'\t' -f1)
            if [[ $TSIZE -gt $LOG_PERSISTENT_SIZE ]] ; then
                TCOUNT="$LOG_PERSISTENT_COUNT"
                CLEAN="y"
            else
                TCOUNT=$(find . -type f | wc -l);
                if [[ $TCOUNT -gt $LOG_PERSISTENT_COUNT ]] ; then
                    CLEAN="y"
                fi
            fi
            if [ "$CLEAN" = "y" ] ; then
                LIST=$(find . -maxdepth 1 -type f -printf "%f\n" | grep -v "$LOG_FILE$" | xargs -r ls -tra)
                for i in $LIST ; do
                    Log "OTS" "Purge $i"
                    TSIZE=$(( TSIZE - $(du -sk "$i" | awk '{print $1;}') ))
                    TCOUNT=$(( TCOUNT - 1 ))
                    rm "$i"
                    if [[ $TSIZE -lt $LOG_PERSISTENT_SIZE && $TCOUNT -lt $LOG_PERSISTENT_COUNT ]] ; then break; fi
                done
            fi

            # Service log file
            if [ "$LOG_FILE" != "" ] ; then
                SIZE=$(du -b "$LOG_FILE" | awk '{print $1;}')
                if [ "$SIZE" -gt "$LOG_FILE_SIZE" ] ; then
                    # Rotate
                    SendEvent "OTS|rotate-logs"
                    exit 0
                fi
            fi
        done
    ) &
    #PID_POLL="$!"
}

if [ "$LOG_PATH" != "" ] ; then
    mkdir -p "$LOG_PATH"
fi

if [ "$LOG_FILE" != "" ] ; then
    exec 0>&-
    if [ "$LOG_PATH" != "" ] ; then
        LOG_FILE_FULL="$LOG_PATH/$LOG_FILE"

        # In case log is not a symlink
        LTE_LOG="/tmp/lte.log"
        if [ ! -L "$LTE_LOG" ] ; then
            if [ -e "$LTE_LOG" ] ; then
                cat "$LTE_LOG" >> "$LOG_FILE_FULL"
                rm -f $LTE_LOG
            fi
            ln -s "$LOG_FILE_FULL" "$LTE_LOG"
        fi
    else
        LOG_FILE_FULL="/tmp/$LOG_FILE"
    fi
    if [ "$LOG_FILE_SIZE" = "" ] ; then
        LOG_FILE_SIZE="$LOG_SIZE"
    fi
fi



# Few initializations
if [ "$LOG_FILE_FULL" != "" ] ; then
    touch "$LOG_FILE_FULL"
    exec 1>>"$LOG_FILE_FULL"
    exec 2>>"$LOG_FILE_FULL"
fi
SCRIPT_SILENT="1"
function ParseProduct
{
    ResetProduct
    if [[ $1 =~ ([A-Z]+)-([0-9]{8})([0-9]{2}) ]] ; then
        PROD_MODEL="${BASH_REMATCH[1]}"
        PROD_DATE="${BASH_REMATCH[2]}"
        PROD_REV="${BASH_REMATCH[3]}"
    fi
}

function ResetProduct
{
    PROD_MODEL=""
    PROD_DATE=""
    PROD_REV=""
    PROD_NAME=""
}

function UpdateProduct
{
    if [ "$MOTHERBOARD" = "" ] ; then
        DMIDECODE=$(which dmidecode)
        if [ "$DMIDECODE" ] ; then
            MOTHERBOARD=$($DMIDECODE -t 2 2>/dev/null | grep -P "Manufacturer:|Product Name:" | cut -d ':' -f2 | sed -e 's/^\s*//' | xargs echo)
        else
            MOTHERBOARD="Unknown"
        fi
    fi

    # Amarisoft products
    if [ "$PROD_REF" = "" ] ; then
        if [ -e "/etc/.amarisoft-product/hostname" ] ; then
            PROD_REF="$(cat /etc/.amarisoft-product/hostname)"
        else
            PROD_REF="$(hostname)"
        fi
        if [ -e "/etc/.amarisoft-product/host-id" ] ; then
            PROD_HOSTID="$(cat /etc/.amarisoft-product/host-id)"
        fi
        if [ -e "/etc/.amarisoft-product/dongle-id" ] ; then
            PROD_DONGLEID="$(cat /etc/.amarisoft-product/dongle-id)"
        fi
    fi

    ParseProduct "$PROD_REF"
    if [ "$PROD_MODEL" = "" ] ; then return; fi

    case "$PROD_MODEL" in
    UESB)
        PROD_NAME="UE Simbox"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="3 1 0 2"
        fi
        ;;
    UESBE)
        PROD_NAME="UE Simbox E"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    UESBNG|UEMBS|UESBMBS)
        PROD_MODEL="UESBMBS"
        PROD_NAME="UE Simbox Macro Base Station"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 4 5"
        fi
        ;;
    CBM)
        PROD_NAME="Callbox Mini"
        SDR_COUNT="1"
        if [ "$MOTHERBOARD" = "Shuttle Inc. XH410G" ] ; then
            SDR_MAP="0"
        elif [ "$MOTHERBOARD" = "Shuttle Inc. XH510G" ] ; then
            SDR_MAP="0"
        fi
        ;;
    CBC)
        PROD_NAME="Callbox Classic"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRock Z790M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PRO4" ] ; then
            SDR_MAP="0 2 1"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PLUS/Z490M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        fi
        ;;
    CBP)
        PROD_NAME="Callbox Pro"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="5 0 4 3 2 1"
        fi
        ;;
    CBU)
        PROD_NAME="Callbox Ultimate"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3 4 5 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="4 5 2 3 0 1 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="2 3 6 7 0 1 4 5"
        fi
        ;;
    CBX|CBE)
        PROD_MODEL="CBX"
        PROD_NAME="Callbox Extreme"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 10 11 8 9 4 5 6 7"
        fi
        ;;
    CBA)
        PROD_NAME="Callbox Advanced"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    CBOO|UESBOO)
        if [ "$PROD_MODEL" = "CBOO" ] ; then
            PROD_NAME="Callbox Infinity"
        else
            PROD_NAME="UE Simbox Infinity"
        fi
        SDR_COUNT="8"
        if [ "$MOTHERBOARD" = "Supermicro H13SSH-E" ] ; then
            SDR_MAP="8 9 10 11 4 5 6 7 0 1 2 3 12 13 14 15"
        fi
        ;;
    XXX)
        ResetProduct
        if [ "$SCRIPT_SILENT" != "1" ] ; then
            echo -e "\033[94mRecovery image found\033[0m"
        fi
        return
        ;;
    *)
        PROD_NAME="$PROD_MODEL"
        ;;
    esac
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$PROD_NAME model found\033[0m"
    fi
}
UpdateProduct

RT_CPUSET=""
function RTCPUInit1
{
    local BID FILE CT tries NB_LAT
    BID=$(cat /proc/sys/kernel/random/boot_id)
    FILE="/etc/.amarisoft-product/cpuset"
    RT_CPUSET0="$RT_CPUSET"

    if [ "$LINUX_DISTRIB" = "fedora" ] ; then
        if [[ $LINUX_VERSION -ge 40 ]] ; then
            rm -f $FILE
            return
        fi
    fi

    if [ -e "$FILE" ] ; then
        source "$FILE"
        if [ "$BOOT_ID" != "$BID" ] ; then
            RT_CPUSET=""
            rm -f $FILE
        else
            if [ "$RT_CPUSET0" != "$RT_CPUSET" ] ; then
                Log "OTS" "Recover cpuset: $RT_CPUSET"
            fi
            return
        fi
    fi

    CT=$(which cyclictest)
    if [ "$CT" = "" ] ; then return; fi

    tries="0"
    while true ; do
        RT_CPUSET="0x0"
        NB_LAT="0"
        Log "OTS" "Detecting CPU latency [$tries]"
        while read -r line ; do
            P=$(echo "$line" | grep -Po "T:\s*\K\d+")
            if [ "$P" != "" ] ; then
                MAX=$(echo "$line" | grep -Po "Max:\s+\K\d+")
                if [[ $MAX -lt 450 ]] ; then
                    RT_CPUSET=$(perl -e "printf '0x%x', $RT_CPUSET | (1<<$P);")
                else
                    Log "OTS" "High latency detected on core $P ($MAX us)"
                    NB_LAT=$(( NB_LAT + 1 ))
                    RT_SKIP_CORE=$P
                fi
            fi
        done < <($CT --smp -p50 -i200 -d0 -m -D8s -q)
        if [ "$NB_LAT" != "1" ] ; then
            if [ "$NB_LAT" != "0" ] ; then
                Log "OTS" "Too much CPU latencies found: $NB_LAT"
            else
                Log "OTS" "No CPU latencies found"
            fi
            if [[ $tries -lt 4 ]] ; then
                tries=$(( tries + 1 ))
                sleep 5
                continue
            fi
            if [ "$NB_LAT" = "0" ] ; then
                RT_CPUSET=""
            else
                return # Try later
            fi
        else
            Log "OTS" "Latency found on CPU: $RT_SKIP_CORE"
        fi

        echo "# Generated on $(date -u)" > $FILE
        echo "BOOT_ID=$BID" >> $FILE
        echo "RT_CPUSET=$RT_CPUSET # !$RT_SKIP_CORE" >> $FILE
        break
    done
}

function RTCPUInit
{
    case "$PROD_MODEL" in
    CBX|CBE|UESBMBS|UESBNG)
        RTCPUInit1
        ;;
    esac
}


LINUX_SERVICE=""
LINUX_PACKAGE=""
LINUX_DISTRIB="<unknown>"
LINUX_VERSION=""

if [ -e "/etc/os-release" ] ; then
    LINUX_DISTRIB=$(grep "^ID=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_VERSION=$(grep "^VERSION_ID=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_NAME=$(grep "^PRETTY_NAME=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
fi
if [ "$LINUX_VERSION" = "" ] || [ "$LINUX_DISTRIB" = "" ] ; then
    if [ -e "/etc/lsb-release" ] ; then
        LINUX_DISTRIB=$(grep "^DISTRIB_ID=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_VERSION=$(grep "^DISTRIB_RELEASE=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_NAME=$(grep "^DISTRIB_DESCRIPTION=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
    elif [ -e "/etc/fedora-release" ]; then
        LINUX_DISTRIB="fedora"
        LINUX_VERSION=$(cut -d " " -f3 /etc/fedora-release)
        LINUX_NAME="Fedora"
    fi
fi

if [ "$TARGET" = "" ] ; then
    TARGET="$(uname -m)"
    if [ "$TARGET" = "x86_64" ] ; then
        TARGET="linux"
    fi
fi

LINUX_VERSION=$(echo "$LINUX_VERSION" | cut -d '.' -f1)
LINUX_DISTRIB=$(echo "$LINUX_DISTRIB" | tr '[:upper:]' '[:lower:]')

case "$LINUX_DISTRIB" in
fedora)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mFedora $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -gt 20 ] ; then
        LINUX_PACKAGE="dnf"
    else
        LINUX_PACKAGE="yum"
    fi
    LINUX_SERVICE="systemd"
    ;;
rhel)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$LINUX_NAME found\033[0m"
    fi
    LINUX_PACKAGE="dnf"
    LINUX_SERVICE="systemd"
    ;;
ubuntu)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mUbuntu $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -lt "15" ] ; then
        LINUX_SERVICE="initd"
    else
        LINUX_SERVICE="systemd"
    fi
    LINUX_PACKAGE="apt"
    ;;
centos)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mCent OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="yum"
    ;;
raspbian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mRaspbian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
debian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mDebian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
*)
    echo "Sorry, $LINUX_DISTRIB distribution not supported only available on Fedora, Ubuntu and CentOS distributions."
    exit 1
    ;;
esac

function service_cmd
{
    local name="$1"
    local cmd="$2"

    case $LINUX_SERVICE in
    systemd)
        if [ -e "/lib/systemd/system/${name}.service" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                systemctl -q "${cmd}" "${name}" 1>/dev/null
            else
                systemctl -q "${cmd}" "${name}"
            fi
        fi
        ;;
    initd)
        if [ -e "/etc/init/${name}.conf" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                service "${name}" "${cmd}" 1>/dev/null
            else
                service "${name}" "${cmd}"
            fi
        fi
        ;;
    esac
}

function service_install
{
    local name="$1"
    local path="$2"
    local user="$3"
    local enable="$4"

    case $LINUX_SERVICE in
    systemd)
        rm -f "/lib/systemd/system/${name}.service"
        sed -e "s/<USER>/$user/" -e "s'<PATH>'$path'" "${path}/${name}.service" > "/lib/systemd/system/${name}.service"
        systemctl -q --system daemon-reload

        if [ "$enable" = "y" ] ; then
            systemctl -q enable "${name}"
            #systemctl -q enable NetworkManager-wait-online.service
        else
            systemctl -q disable "${name}"
        fi
        ;;
    initd)
        # Remove legacy
        local deamon="/etc/init.d/${name}.d"
        if [ -e "$deamon" ]; then
            $deamon stop
            update-rc.d "${name}.d" disable
            rm -f "$deamon"
        fi

        if [ "$enable" = "y" ] ; then
            rm -f "/etc/init/${name}.conf"
            sed -e "s/<USER>/$user/" -e "s'<PATH>'$path'" "${path}/${name}.conf" > "/etc/init/${name}.conf"
        else
            rm "/etc/init/${name}.conf"
        fi
        ;;
    esac
}

# Package manager state
LINUX_PACKAGE_READY="y"
function check_package_manager
{
    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    case "$LINUX_PACKAGE" in
    yum|dnf)
        # XXX
        ;;
    apt)
        LOCKED=$(lsof /var/lib/dpkg/lock 2>/dev/null)
        if [ "$LOCKED" != "" ] ; then
            LINUX_PACKAGE_READY="n"
        fi
        ;;
    esac

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}
check_package_manager

function install_package
{
    if [ "$LINUX_PACKAGE" = "" ] ; then return; fi

    if [ "$(whoami)" != "root" ] ; then
        echo "\031[93mRoot access needed to install package.[0m"
        exit 1
    fi

    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    while [ "$1" != "" ] ; do
        case "$LINUX_PACKAGE" in
        yum|dnf)
            if ! $LINUX_PACKAGE list installed "$1" &>/dev/null ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    $LINUX_PACKAGE -qq -y install "$1"
                else
                    $LINUX_PACKAGE -y install "$1"
                fi
            fi
            ;;
        apt)
            if ! apt-cache --quiet=0 policy "$1" | grep "Installed" | grep -v none &>/dev/null ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    apt-get -qq install -y "$1" &>/dev/null
                else
                    apt-get install -y "$1"
                fi
            fi
            ;;
        esac

        if [ "$?" != "0" ] ; then
            echo -e "  \033[93mCan't install package $1\033[0m"
            break
        fi
        shift;
    done

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}

function GetHTState
{
    if [ "$HT_SYS_STATE" = "" ] ; then
        if [ -e "/sys/devices/system/cpu/smt/control" ] ; then
            HT_SYS_STATE=$(cat "/sys/devices/system/cpu/smt/control")
            if [ "$HT_SYS_STATE" = "on" ] ; then
                # Control on but only 1 thread per core
                TPC=$(lscpu | grep -oP "Thread.+per core:.+\K\d+")
                if [ "$TPC" = "1" ] ; then
                    HT_SYS_STATE="off"
                fi
            fi
        fi
    fi
}

function SetHTState
{
    echo "$1" > "/sys/devices/system/cpu/smt/control" 2>&1
}
FIFO_EVENT="$OTSDIR/.lte.event"
CONFIG_FILE="$OTSDIR/.lte.config"

function WriteHeaders
{
    echo "# lteots version 2026-06-12"
    if [ -e "config/ots.cfg" ] ; then
        echo "# CFG=$(./lte_toolbox zip config/ots.cfg | tail -n 1)"
    fi
}
WriteHeaders

if [ -e "$CONFIG_FILE" ] ; then
    source "$CONFIG_FILE"
fi

# Path for multi environment support
export PATH="$PATH:/bin/:/usr/bin/:/usr/local/bin"


#############
# Execution #
#############
INFO="host: $HOSTNAME\n"
INFO+="user: $user\n"

# OS/HW info
if [ "$PROD_NAME" != "" ] ; then
    INFO+="model: $PROD_NAME [$PROD_DATE-$PROD_REV]\n"
fi
INFO+="cpu: $(lscpu | grep -oP "^Model name: +\K.+")\n"
INFO+="mem: $(lsmem | grep -oP "Total online memory: +\K.+")\n"
INFO+="motherboard: $MOTHERBOARD\n"
INFO+="os: $LINUX_DISTRIB v$LINUX_VERSION\n"
INFO+="boot: $(cat /proc/cmdline)\n"
INFO+="target: $TARGET"

Log "OTS" "Start service v2026-06-12" "$INFO"

# Hyperthreading
function UpdateHT
{
    if [ "$1" != "on" ] && [ "$1" != "off" ] ; then return; fi
    if [ "$2" != "on" ] && [ "$2" != "off" ] ; then return; fi
    if [ "$1" = "$2" ] ; then return; fi

    RES=$({
        SetHTState "$2"
    })
    Log "OTS" "Set hyperthreading $2" "$RES"
}
if [ "$HT_STATE" != "" ] ; then
    GetHTState
    UpdateHT "$HT_SYS_STATE" "$HT_STATE"
fi

# USB
function USBMount
{
    if [ -e "usb-mount.sh" ] ; then
        USB=$(./usb-mount.sh "$@" 2>&1)
        if [ "$?" != "0" ] ; then
            Log "OTS" "USB mount error" "$USB"
        elif [ "$USB" != "" ] ; then
            Log "OTS" "Mount USB" "$USB"
        fi
    fi
}
USBMount -v

# Core dumps
ulimit -c unlimited

# Init
if [ -d "$WWW_PATH" ]; then
    WWW_CFG="$WWW_PATH/.ots"
    rm -f "$WWW_CFG"
    echo "OTS#$HOSTNAME#$OTS_ADDRESS" > "$WWW_CFG"
fi

# Event listener
rm -f "$FIFO_EVENT"
mkfifo "$FIFO_EVENT"
exec 3<>"$FIFO_EVENT"

# Logs
if [ "$LOG_PATH" != "" ] ; then
    if [ "$LOG_SIZE" != "" ] ; then
        LOG_OPTIONS="file.rotate=$LOG_SIZE,file.path=$LOG_PATH"
        if [ "$LOG_COUNT" != "" ] ; then
            LOG_OPTIONS+=",file.rotate=#$LOG_COUNT"
        fi
        LogPollStart
    fi
fi


# Place sighandlers before starting components
trap SignalHandler INT TERM


#######
# MON #
#######
function MonitorStart
{
    local CFILE FILE COM_ADDR PORT ARGS
    CFILE="$MONITOR_PATH/$MONITOR_CONFIG_FILE"

    # Check config file validity
    ERROR=$(./json_util test "$CFILE" 2>&1)
    if [ "$?" = "0" ] ; then

        FILE=$(./json_util dump "$CFILE" "log_filename" | sed -e 's/"//g')
        CompSetVar "MON" "LOG_FILE" "$FILE"

        # COM interface
        COM_ADDR=$(./json_util dump "$CFILE" "com_addr" | sed -e 's/"//g')
        if [ "$COM_ADDR" != "" ] ; then
            PORT=$(echo "$COM_ADDR" | awk '{n=split($0,a,":"); print a[n]}')
            WWWUpdate "MONITOR" "ws" "MONITOR" "$HOSTNAME-MON" "$PORT"
        fi

        # Add to monitor daemon
        ARGS=""
        for comp in $COMP_LIST ; do
            CompGetVar "$comp" "CONFIG_FILE_FULL" "STATE" "PROG" "PATH"
            if [ "$CMODE" != "standalone" ] ; then
                ARGS+=" --comp $comp $CCONFIG_FILE_FULL $CSTATE $CPATH/$CPROG"
            fi
        done
        if [ "$OTS_ADDRESS" != "" ] ; then
            ARGS+=" --host $OTS_ADDRESS"
        fi

        CCONFIG_FILE_FULL="$CFILE"
        CompConfigValue "log_filename"
        if [ "$CERROR" = "0" ] && [ "$CVALUE" != "" ] ; then
            CLOG_FILE=$(readlink -f "$CVALUE")
        else
            CLOG_FILE=""
        fi

        BackupLog "MON"

        Log "MON" "Starting"
        # Fork
        (
            cd "$MONITOR_PATH"

            (
                CompPollStarted "MON" "$(( ERROR_DELAY - 1 ))"
            ) &
            PID="$!"

            # Launch
            ./ltemonitor.js --log "$LOG_OPTIONS" --hostname "$HOSTNAME" --osname "$LINUX_DISTRIB v$LINUX_VERSION" --fifo "$FIFO_MONITOR" $ARGS "$MONITOR_CONFIG_FILE" --ots-fifo "$FIFO_EVENT"

            kill $PID
            SendEvent "MON|stop|$?"

            {
                sleep "$ERROR_DELAY"
            } 3<>"$FIFO_MONITOR"
            SendEvent "MON|start"
        ) &

    else
        echo "Invalid monitor config $CFILE: $ERROR"
        # Fork
        (
            {
                sleep "$ERROR_DELAY"
                SendEvent "MON|start"
            } 3<>"$FIFO_MONITOR"
        ) &
    fi
    #PID_MONITOR="$!"
}

CompSetVar "MON" "TYPE" "MONITOR"
function HandleEventMON
{
    local comp type args
    comp="$1"
    type="$2"
    args="$3"

    case "$type" in
    start)
        MonitorStart
        ;;
    stop)
        BackupLog "MON" "stop"
        ;;
    esac

    #CompSetVar $comp "LOG_FILE" "$FILE"
}



# Component definition
PROG_LICENSE="ltelicense_server"
PROG_MBMSGW="ltembmsgw"
PROG_IMS="lteims"
PROG_UE="lteue"
PROG_N3IWF="lten3iwf"
PROG_MME="ltemme"
PROG_ENB="lteenb"
PROG_PROBE="lteprobe"
PROG_SCAN="ltescan"
PROG_VIEW="lteview"
PROG_SAT="ltesat"
PROG_SIMSERVER="ltesim_server"

SIMSERVER_MODE="standalone"

function CompStartInit
{
    local list USE_RT PS GUI
    list=""
    USE_RT=""

    # Check window and sort components by window #
    for comp in $COMPONENTS; do
        WIN="${comp}_WIN"
        if [ "${!WIN}" != "" ] ; then

            WIN_N="WIN_N${!WIN}"
            if [ "${!WIN_N}" = "" ] ; then
                list+=$(printf " %03d:%s" "${!WIN}" "${comp}")
                eval "WIN_N${!WIN}=\"$comp\""
            else
                Log "OTS" "Can't use Window ${!WIN} for $comp, already used by ${!WIN_N}"
            fi
        else
            Log "OTS" "No window defined for $comp"
        fi
    done

    # Reverse order
    list=$(echo "$list" | xargs printf "%s\n" | sort -r)

    for C in $list ; do
        comp=$(echo "$C" | cut -d ":" -f2)
        CompCreate "$comp"

        case "$CTYPE" in
        ENB|UE|VIEW)
            USE_RT="y"
            ;;
        esac
    done

    if [ "$USE_RT" = "y" ] ; then
        # Check X11/Wayland
        PS=$(ps faux)
        GUI=$(echo "$PS" | grep -v earlyoom | grep -ioP "Xorg|wayland" | head -n 1)
        if [ "$GUI" != "" ] ; then
            Log "OTS" "Warning, $GUI server detected, for optimal real time performances, we recommend to disable it"
        fi
    fi

    # Specific case for monitor
    if [ -d "$MONITOR_PATH" ] ; then

        # Fifo
        FIFO_MONITOR="$MONITOR_PATH/.fifo"
        rm -f "$FIFO_MONITOR"
        mkfifo "$FIFO_MONITOR"

        MON_TYPE="MON"
        MON_STATE="used"
        HandleEventMON "MON" "start"
    fi
}

function CompPollAll
{
    # Start components
    for comp in $COMP_LIST ; do
        CompPoll "$comp"
    done
}

CompStartInit
CompPollAll



##################
# Event listener #
##################
ERROR_10="Config error"
ERROR_40="TRX discontinuity"
ERROR_41="RF frontend error"
ERROR_66="License error"
ERROR_134="Abort"
ERROR_130="SIGINT received"
ERROR_131="Quit signal received"
ERROR_137="Out of memory"
ERROR_138="Bus error"
ERROR_139="Segmentation fault"

function HandleEventGeneric
{
    local comp type args error section msg core
    comp="$1"
    type="$2"
    args="$3"

    case "$type" in
    init)
        if [ "$args" = "0" ] ; then
            unset "${comp}_INIT"
        fi
        ;;
    launch)
        # Start right now
        CompGetVar "$comp" "PATH"
        CompSetVar "$comp" "START_TIME" "$(date +%s)"
        CompExec "$comp" "cd $CPATH" "$OTSDIR/ltelaunch.sh $comp"
        ;;
    starting)
        # Coming from ltelauncher.sh
        CompSetVar "$comp" "PID_LAUNCHER" "-$args"
        ;;
    started)
        CompSetVar "$comp" "PID_INIT" ""

        # Configure logs
        if [ "$LOG_OPTIONS" != "" ] ; then
            CompExec "$comp" "log $LOG_OPTIONS"
        fi
        CompSetState "$comp" "started"
        CompPollAll
        ;;
    restart)
        # Unset pid
        CompSetVar "$comp" "PID_ERROR" ""
        CompSetState "$comp" "stopped"
        CompPoll "$comp"
        ;;
    stop)
        CompSetVar "$comp" "PID_LAUNCHER" ""
        BackupLog "$comp" "stop"
        CompSetState "$comp" "stopped"
        CompPoll "$comp"
        ;;
    error)
        CompSetVar "$comp" "PID_LAUNCHER" ""

        # Init errors
        case "$args" in
        RRH_CHECK)
            CompError "$comp" "INIT" "RF frontend"
            return
            ;;
        esac

        BackupLog "$comp" "stop"
        KillCompPID "$comp" "PID_INIT" "init"

        CompGetVar "$comp" "STATE" ""
        if [ "$CSTATE" = "started" ] ; then
            section="RUNTIME"
        else
            section="INIT"
        fi

        error="ERROR_$args"
        msg=""
        error=${!error}
        if [ "$error" = "" ] ; then
            error="Unexpected termination #$args"
        fi

        # Get message from stderr/sdtout
        CompGetVar "$comp" "PATH" "OUTPUT_FILE_FULL"
        if [ -s "$COUTPUT_FILE_FULL" ] ; then
            if [ "$args" = "66" ] ; then
                msg=$(grep -A 10 "License error:" "$COUTPUT_FILE_FULL")
            fi
            if [ "$msg" = "" ] ; then
                msg=$(tail -n 6 "$COUTPUT_FILE_FULL")
            fi
        fi

        # Specific information
        case "$args" in
        139|131|134)
            msg+=$'\n'$(uname -a)$'\n'
            CompGetVar "$comp" "PROG" "PATH"
            core="/tmp/core.$CPROG"
            EXE=$(coredumpctl --no-pager -F COREDUMP_EXE list | grep "$CPROG" | tail -n 1)
            # Add crash callstack
            coredumpctl=$(coredumpctl -o "$core" dump "$EXE" 2>&1)
            if [ "$?" = "0" ] && [ -f "$core" ] ; then
                msg+=$(gdb -n -q -batch -ex bt "$EXE" "$core" | grep -v "New LWP" | grep -v "libthread_db")
                rm -f "$core"
            else
                msg+="Core file not found: $coredumpctl"
            fi
            ;;
        66)
            # Try to mount USB device in case of
            USBMount
            ;;
        esac
        CompError "$comp" "$section" "$error" "$msg"
        ;;
    esac

}

SET_LOGS_LAST_LOGS=""
SET_LOGS_LAST_COMPS=""
function SetLogs
{
    local LOGS COMPS comp
    LOGS="$1"
    COMPS="$2"

    if [ "$LOGS" = "" ] ; then return; fi

    for comp in $COMP_LIST ; do
        # Filter
        if [ "$COMPS" != "" ] && [ "$(echo "$COMPS" | grep -ow "$comp" || echo "")" = "" ] ; then continue; fi

        CompGetVar "$comp" "STATE" "LOG_FILE"
        if [ "$CSTATE" = "started" ] && [ "$CLOG_FILE" != "" ] ; then
            Log "$comp" "Set logs: $LOGS"
            CompExec "$comp" "log state=save,$LOGS"
        fi
    done
    SET_LOGS_LAST_LOGS="$LOGS"
    SET_LOGS_LAST_COMPS="$COMPS"
}

function SaveLogs
{
    local ID FILES FILES1 BINS DIR COMPS comp f file i j
    ID="$1"
    COMPS="$2"

    if [ "$ID" = "" ] ; then ID="debug"; fi

    Log "OTS" "Save logs $ID [$COMPS]"
    DIR="/tmp"

    declare -a FILES
    for comp in $COMP_LIST ; do
        # Filter
        if [ "$COMPS" != "" ] && [ "$(echo "$COMPS" | grep -ow "$comp" || echo "")" = "" ] ; then continue; fi

        CompGetVar "$comp" "STATE" "LOG_FILE"
        if [ "$CSTATE" = "started" ] && [ "$CLOG_FILE" != "" ] ; then
            f="$ID-$(echo "$comp" | tr '[:upper:]' '[:lower:]').log"
            rm -f "$DIR/$f" "$DIR/$f.bin"
            Log "$comp" "Save logs to $DIR/$f"
            CompExec "$comp" "log file.save=$DIR/$f,state=restore"
            FILES+=("$f")
        fi
    done
    FILES1="${FILES[@]}"

    if [ "$FILES1" = "" ] ; then
        Log "OTS" "Logs saved to <none>"
        return
    fi

    for i in $(seq 1 10) ; do
        for j in ${!FILES[@]} ; do
            file=${FILES[$j]}
            f="$DIR/$file"
            if [ -e "$f" ] && [ "$(lsof $f 2>/dev/null)" = "" ] ; then
                unset FILES[$j]
                if [ -e "$f.bin" ] ; then
                    FILES1+=" $file.bin"
                    FILES+=("$file.bin")
                fi
            fi
        done
        if [ "${#FILES[@]}" = "0" ] ; then break; fi
        sleep 2
    done

    if [ "${#FILES[@]}" != "0" ] ; then
        Log "OTS" "Timeout on ${FILES[@]}"
    fi

    (
        TAR="$ID.logs.tar.xz"
        cd $DIR
        rm -f "$TAR" "$ID.cfg"
        touch "$ID.cfg"
        echo "$SET_LOGS_LAST_LOGS" >> "$ID.cfg"
        echo "$SET_LOGS_LAST_COMPS" >> "$ID.cfg"

        tar cJf "$TAR" $FILES1 "$ID.cfg"
        rm -f $FILES1 "$ID.cfg"
        Log "OTS" "Logs saved to $DIR/$TAR"
    )
}

CompSetVar "OTS" "TYPE" "OTS"
function HandleEventOTS
{
    local comp type args line auto action comps
    comp="$1"
    type="$2"
    args="$3"
    line="$4"

    case "$type" in
    rotate-logs)
        BackupLog1 "OTS" "$LOG_FILE_FULL" "empty"
        WriteHeaders
        LogPollStart
        ;;
    comp-autostart)
        auto=$(echo "$line" | cut -d '|' -f4)
        CompSetAutostart "$args" "$auto"
        ;;
    comp)
        action=$(echo "$line" | cut -d '|' -f4)
        Log "$args" "Action $action"
        case "$action" in
        stop)
            CompSetVar "$args" "AUTOSTART" "n"
            CompPoll "$args"
            ;;
        start)
            CompSetVar "$args" "AUTOSTART" "y"
            CompPoll "$args"
            ;;
        esac
        ;;
    set-logs)
        comps=$(echo "$line" | cut -d '|' -f4)
        SetLogs "$args" "$comps"
        ;;
    save-logs)
        comps=$(echo "$line" | cut -d '|' -f4)
        SaveLogs "$args" "$comps"
        ;;
    esac
}

function HandleEventMME
{
    local comp type args
    comp="$1"
    type="$2"
    args="$3"

    CompGetVar "$comp" "PATH"

    HandleEventGeneric "$comp" "$type" "$args"

    case "$type" in
    init)
        # MME specific case
        if [ "$args" = "2" ] && [ "$MME_INIT_LOCAL" = "" ] ; then
            # Configure at least locally to allow LTE local connections
            Log "MME" "Initialize with local interface"
            INIT=$("$CPATH/lte_init.sh" lo 2>&1)
            MME_INIT_LOCAL="y"
        fi
        ;;
    started)
        if [ "$ENB_STATE" = "started" ] ; then
            CompExec "ENB" "cnconnect"
        fi

        if [ "$IMS_STATE" = "started" ] ; then
            CompExec "IMS" "rxconnect" "cxconnect"
        fi
        ;;
    esac
}

function HandleEventIMS
{
    local comp type args
    comp="$1"
    type="$2"
    args="$3"

    HandleEventGeneric "$comp" "$type" "$args"
    case "$type" in
    started)
        if [ "$MME_STATE" = "started" ] ; then
            CompExec "MME" "imsconnect"
        fi
        ;;
    esac
}

function HandleEventSIMSERVER
{
    HandleEventGeneric "$1" "$2" "$3"
}

function HandleEventENB
{
    HandleEventGeneric "$1" "$2" "$3"
}

function HandleEventN3IWF
{
    HandleEventGeneric "$1" "$2" "$3"
}

function HandleEventMBMSGW
{
    HandleEventGeneric "$1" "$2" "$3"
}

function HandleEventLICENSE
{
    HandleEventGeneric "$1" "$2" "$3"
}

function HandleEventUE
{
    HandleEventGeneric "$1" "$2" "$3"
}

function HandleEventSAT
{
    HandleEventGeneric "$1" "$2" "$3"
}


# Start event handler in child process
Log "OTS" "Listen to events"

while true ; do

    if read -u 3 line ; then

        comp=$(echo "$line" | cut -d '|' -f1)
        type=$(echo "$line" | cut -d '|' -f2)
        args=$(echo "$line" | cut -d '|' -f3)

        V="${comp}_STATE"
        if [ "$comp" = "OTS" ] || [ "${!V}" != "" ] ; then
            Log "$comp" "Event '$type': $args"
            CompGetVar "$comp" "TYPE"
            HandleFunc="HandleEvent$CTYPE"
            $HandleFunc "$comp" "$type" "$args" "$line"
        else
            Log "OTS" "Unknown component $comp"
        fi
    else
        echo "Event read error"
        sleep 1
    fi
done

