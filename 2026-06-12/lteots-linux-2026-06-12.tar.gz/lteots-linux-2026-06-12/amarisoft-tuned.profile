[main]
summary=Amarisoft optimization version 2026-06-12

[bootloader]
cmdline="mce=ignore_ce skew_tick=1 nosoftlockup mitigations=off audit=0"

[cpu]
energy_perf_bias=performance
force_latency=cstate.id:1|99
governor=performance
min_perf_pct=100

[sysctl]
kernel.numa_balancing=0
kernel.sched_migration_cost_ns=5000
kernel.sched_wakeup_granularity_ns=5000
kernel.sched_min_granularity_ns=3000000
kernel.sched_rt_runtime_us=-1
kernel.sched_nr_migrate=4
net.core.busy_poll=50
net.core.busy_read=50
net.ipv4.tcp_fastopen=3
vm.dirty_background_ratio=3
vm.dirty_ratio=10
vm.swappiness=10

[vm]
transparent_hugepages=never
