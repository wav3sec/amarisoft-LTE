#!/bin/bash
# Copyright (C) 2012-2026 Amarisoft
# Ettus USRP presence checker 2026-06-12

TYPE="##TYPE##"

set -e

while [ "$1" != "" ] ; do
    case "$1" in
    --ots)
        ;;
    --cfg)
        shift
        ADDRS=$(./json_util dump $1 rf_driver args | grep -oP "\d+\.\d+\.\d+\.\d+" || echo '')
        if [ "$ADDRS" != "" ] ; then
            for i in $ADDRS ; do
                uhd_usrp_probe --args=addr=$i
            done
        else
            uhd_usrp_probe
        fi
        ;;
    --temp)
        shift
        ;;
    *)
        echo "Unknown argument: $1" >&2
        exit 2
        ;;
    esac
    shift
done

exit 0

