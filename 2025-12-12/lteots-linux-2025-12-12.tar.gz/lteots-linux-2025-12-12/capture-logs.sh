#!/bin/bash
# Log capture tool version 2025-12-12

set -e

cd "$(dirname "$(readlink -f "$0")")"
source config/ots.cfg

EVENTS=".lte.event"

function Help
{
    echo "Usage:"
    echo "$(basename "$0") [options] [<monitor log config>]"
    echo "Capture logs for all components"
    echo "  options"
    echo "    -n <name>: logs name (default = debug)"
    echo "    -d <duration>: in seconds (if omited, will wait for ctrl+c)"
    echo "    -c <comp>: save logs for this component (ex: mme)"
    echo "        if omitted, save all components"
    echo "        Can be: $COMPONENTS"
    echo "    --nr: don't reset logs before capture"
    exit 1
}

ID="debug"
DURATION=""
LOGS=""
RESET="y"
declare -a COMPS

while [ "$1" != "" ] ; do

    case "$1" in
    -h|--help)
        Help
        ;;
    -n)
        ID="$2"
        shift
        ;;
    -d)
        DURATION="$2"
        shift
        ;;
    -c)
        comp=$(echo "$2" | tr '[:lower:]' '[:upper:]')
        if [ "$(echo "$COMPONENTS" | grep -ow "$comp")" = "" ] ; then
            echo "Unknown component $comp"
            exit 1
        fi
        COMPS+=("$comp")
        shift
        ;;
    --nr)
        RESET="n"
        ;;
    *)
        if [ "$LOGS" = "" ] ; then
            LOGS="$1"
        else
            Help
        fi
        ;;
    esac
    shift
done

if [ ! -p "$EVENTS" ] ; then
    echo "LTE service not started"
    exit 1
fi


function End
{
    (
        SAVED=$(timeout 10 grep -m 1 -oP "Logs saved to \K.+" <(tail -n 0 -f /tmp/lte.log))
        if [ "$SAVED" != "" ] ; then
            if [ "$SAVED" = "<none>" ] ; then
                echo "No logs to save"
                exit 1
            else
                echo "Saved to $SAVED:"
                tar tf $SAVED
            fi
        else
            echo "Error"
        fi
    ) &
    PID="$!"

    echo "OTS|save-logs|$ID|${COMPS[@]}" >> "$EVENTS"
    echo -e "\rSaving logs..."
    wait $PID
}

if [ "$LOGS" != "" ] ; then
    LOGS="permissive=1,$LOGS"
fi
if [ "$RESET" = "y" ] ; then
    echo "Reset logs"
    if [ "$LOGS" != "" ] ; then LOGS+=","; fi
    LOGS+="file=cut"
fi
if [ "$LOGS" != "" ] ; then
    echo "OTS|set-logs|$LOGS|${COMPS[@]}" >> "$EVENTS"
fi

trap End INT TERM

if [ "$DURATION" != "" ] ; then
    echo "Capture logs for $DURATION seconds..."
    for i in $(seq 1 $DURATION) ; do
        sleep 1

        if [ ! -p "$EVENTS" ] ; then
            echo "LTE service stopped before end of capture"
            exit 1
        fi
    done
    End
else
    echo "Start capturing logs, press ctrl+c to stop it..."
    while [ -p "$EVENTS" ] ; do
        sleep 1
    done
    echo "LTE service stopped before end of capture"
    exit 1
fi


