#!/bin/bash
# Copyright (C) 2022-2025 Amarisoft
# lteue cleanup script version 2025-12-12

case "$2" in
starting|stopped)
    # Clean network namespaces
    for ID in $(ip netns | cut -d ' ' -f1) ; do
        if [[ $ID == ue[[:digit:]]* ]] ; then
            echo "Clean netns $ID"
            ip netns del $ID
        fi
    done
    ;;
esac

