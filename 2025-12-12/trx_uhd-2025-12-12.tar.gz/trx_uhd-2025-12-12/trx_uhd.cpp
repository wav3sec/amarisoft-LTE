/* 
 * UHD driver 
 * Copyright (C) 2012-2025 Amarisoft
 */
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <inttypes.h>
#include <string.h>
#include <getopt.h>
#include <math.h>
#include <assert.h>
#include <unistd.h>
#include <sys/time.h>

#include <uhd/version.hpp>
#if UHD_VERSION < 3110000
#include <uhd/utils/thread_priority.hpp>
#include <uhd/utils/msg.hpp>
#else
#include <uhd/utils/thread.hpp>
#endif
#include <uhd/utils/safe_main.hpp>
#include <uhd/usrp/multi_usrp.hpp>
#include <uhd/exception.hpp>
#include <uhd/property_tree.hpp>
#include <uhd/usrp/mboard_eeprom.hpp>
#include <uhd/version.hpp>
#if UHD_VERSION >= 3140000
#include <uhd/utils/log.hpp>
#include <uhd/utils/log_add.hpp>
#endif
#include <uhd/types/metadata.hpp>

extern "C" {
#include "trx_driver.h"
};

/*
 * For UHD >= 3.13, it is recommended to compile driver with UHD_LOG_FASTPATH_DISABLE set to on
 */

static inline int max_int(int a, int b)
{
    if (a > b)
        return a;
    else
        return b;
}

typedef enum {
    UHD_SYNC_NONE,
    UHD_SYNC_EXTERNAL,
    UHD_SYNC_MIMO,
    UHD_SYNC_EXTERNAL_CLOCK,
} UHDSyncEnum;

typedef enum {
    UHD_BOARD_N2x0,
    UHD_BOARD_B2x0,
    UHD_BOARD_X3x0,
    UHD_BOARD_N3x0,

} UHDBoardType;

struct TRXUHDState {
    uhd::rx_streamer::sptr rx_stream[TRX_MAX_RF_PORT];
    uhd::tx_streamer::sptr tx_stream[TRX_MAX_RF_PORT];
    uhd::usrp::multi_usrp::sptr usrp;
    int dl_sample_bits;
    int ul_sample_bits;
    UHDSyncEnum sync_type;
    int rx_channel_count;
    int tx_channel_count;
    UHDBoardType board_type;
    int rf_port_count;
    int tx_port_channel_count[TRX_MAX_RF_PORT];
    bool tx_last_padding[TRX_MAX_RF_PORT];
    int64_t tx_next_timestamp[TRX_MAX_RF_PORT];
    int rx_port_channel_count[TRX_MAX_RF_PORT];
    int sample_rate[TRX_MAX_RF_PORT];
    double real_sample_rate[TRX_MAX_RF_PORT];
    int exception_retries;
    int rx_antenna_rx;

    /* TX/RX diff */
    int64_t next_clock_ts;
    int64_t last_clock_time;
    int64_t last_clock_ts;
#define TX_CLOCK_UPDATE_DELAY       INT64_C(1000)  /* ms */

    int stop;
};

static int time_error_count;
static int seq_error_count;
static int underflow_error_count;
static bool has_errors = false;
static int64_t last_error_disp_time;
static int64_t tx_underflow_count;
static int64_t rx_overflow_count;

static int64_t get_time_us(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (int64_t)tv.tv_sec * 1000000 + tv.tv_usec;
}

static inline void dump_errors(void)
{
    /* avoid displaying too many errors */
    if (has_errors && 
        (last_error_disp_time == 0 ||
         (get_time_us() - last_error_disp_time) >= 1000000)) {
        printf("UHD status: L=%d U=%d S=%d\n",
               time_error_count,
               underflow_error_count,
               seq_error_count);
        last_error_disp_time = get_time_us();
        time_error_count = 0;
        underflow_error_count = 0;
        seq_error_count = 0;
        has_errors = false;
    }
}

#if UHD_VERSION < 3110000
static void uhd_msg_handler(uhd::msg::type_t type, const std::string &msg)
{
    switch(type) {
    case uhd::msg::fastpath:
        /* single letter errors (see standard_async_msg_prints() in
           UHD driver) */
        if (msg.length() == 1) {
            const char *data = msg.data();
            switch(*data) {
            case 'L':
                time_error_count++;
                tx_underflow_count++;
                break;
            case 'U':
                underflow_error_count++;
                tx_underflow_count++;
                break;
            default:
            case 'S':
                seq_error_count++;
                rx_overflow_count++;
                break;
            }
            has_errors = true;
        }
        break;
    default:
        /* just output the message */
        printf("UHD: %s\n", msg.c_str());
        break;
    }
}
#else
static pthread_t uhd_log_thread_id = (pthread_t)-1;

static void *uhd_log_thread_func(void *arg)
{
    TRXUHDState *s = (TRXUHDState*)arg;
    uhd::async_metadata_t async_md;
    int i, n;

    pthread_setname_np(pthread_self(), "UHD/logs");

    while (!s->stop) {
        n = 0;
        for (i = 0; i < s->rf_port_count && !s->stop; i++) {
            /* Protect if no TX port defined (as in ltescan or lteview) */
            if (s->tx_port_channel_count[i] == 0)
                continue;
            if (s->tx_stream[i]->recv_async_msg(async_md, 0)) {
                switch (async_md.event_code) {
                case uhd::async_metadata_t::EVENT_CODE_UNDERFLOW:
                    underflow_error_count++;
                    tx_underflow_count++;
                    has_errors = true;
                    break;
                case uhd::async_metadata_t::EVENT_CODE_TIME_ERROR:
                    time_error_count++;
                    tx_underflow_count++;
                    has_errors = true;
                    break;
                case uhd::async_metadata_t::EVENT_CODE_BURST_ACK:
                case uhd::async_metadata_t::EVENT_CODE_USER_PAYLOAD:
                    break;
                default:
                    printf("\nUHD: %d\n", async_md.event_code);
                    break;
                }
                n++;
            }
        }
        if (!n) usleep(100000);
        dump_errors();
    }

    return NULL;
}
#endif

static void trx_uhd_write2(TRXState *s1, trx_timestamp_t timestamp, const void **psamples, int count,
                           int tx_port_index, TRXWriteMetadata *md)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    uhd::tx_metadata_t tx_md;

    if (md->flags & TRX_WRITE_FLAG_PADDING) {
        /* padding: no need to send anything */
        s->tx_last_padding[tx_port_index] = true;
    } else {
        if (s->tx_last_padding[tx_port_index] || timestamp > s->tx_next_timestamp[tx_port_index])
            tx_md.start_of_burst = true;
        s->tx_last_padding[tx_port_index] = false;
        tx_md.end_of_burst = 
            (md->flags & TRX_WRITE_FLAG_END_OF_BURST) ? true : false;
        tx_md.has_time_spec = true;
        tx_md.time_spec = uhd::time_spec_t::from_ticks(timestamp, s->real_sample_rate[tx_port_index]);

        uhd::tx_streamer::buffs_type buffs(psamples, 
                                           s->tx_port_channel_count[tx_port_index]);
        s->tx_stream[tx_port_index]->send(buffs, count, tx_md);

        if (md->flags & TRX_WRITE_MD_FLAG_CUR_TIMESTAMP_REQ) {
            int64_t now = get_time_us();

            /* Don't get clock from USRP too often as it is not fast (~100us)
             * => Estimate it with system clock every TX_CLOCK_UPDATE_DELAY ms
             */
            if (timestamp >= s->next_clock_ts) {
                s->last_clock_time = now;
                s->last_clock_ts   = s->usrp->get_time_now().to_ticks(s->real_sample_rate[tx_port_index]);
                s->next_clock_ts   = timestamp + TX_CLOCK_UPDATE_DELAY * s->sample_rate[tx_port_index] / 1000;
            }

            md->cur_timestamp_set = 1;
            md->cur_timestamp = s->last_clock_ts + (now - s->last_clock_time) * s->sample_rate[tx_port_index] / 1000000;
        }

#if UHD_VERSION < 3110000
        if (s->rx_channel_count != 1 || s->tx_channel_count != 0)
            dump_errors();
#endif

        /* XXX: in case of network error, the UHD driver return an invalid
           number of written samples */
        //    assert((int)num_tx_samps == count);
    }
    s->tx_next_timestamp[tx_port_index] = timestamp + count;
}

static int trx_uhd_read2(TRXState *s1, trx_timestamp_t *ptimestamp, void **psamples, int count,
                         int rf_port_index, TRXReadMetadata *md)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    uhd::rx_metadata_t rx_md;
    size_t num_rx_samps;
    int ecount = s->exception_retries;
    int np = s->rx_port_channel_count[rf_port_index];
    bool single = true;

    /* Use multi frame read for sample rate larger than 30.72MHz */
    if (s->sample_rate[rf_port_index] >= 30.72e6)
        single = false;
    
 redo:
    /* Note: we only get one packet to reduce the latency, 1 sec timeout for first frame */
    uhd::rx_streamer::buffs_type buffs(psamples, np);
    num_rx_samps = s->rx_stream[rf_port_index]->recv(buffs, count, rx_md, 1.0, single);
    //fprintf(stderr, "recv(start=%d) =>%d\n", start, num_rx_samps);

#if 0
    printf("read %d samples timestamp=%f\n", 
           (int)num_rx_samps, rx_md.time_spec.get_real_secs());
#endif
    if (rx_md.error_code == uhd::rx_metadata_t::ERROR_CODE_OVERFLOW) {
#if UHD_VERSION >= 3110000
        rx_overflow_count++;
        seq_error_count++;
        has_errors = true;
#endif
        goto redo;
    }
    
    *ptimestamp = rx_md.time_spec.to_ticks(s->real_sample_rate[rf_port_index]);
    
    if (rx_md.error_code == uhd::rx_metadata_t::ERROR_CODE_TIMEOUT) {
        fprintf(stderr, "trx_uhd_read: Read Timeout\n");
        goto done;
    }
    if (rx_md.error_code != uhd::rx_metadata_t::ERROR_CODE_NONE) {
        fprintf(stderr, "trx_uhd_read: error code = 0x%x\n", rx_md.error_code);
        if (ecount-- > 0) {
            usleep((s->exception_retries - ecount) * 500);
            goto redo;
        }

        exit(1);
    }
#if 0
    /* TEST */
    {
        static int64_t cur_timestamp[TRX_MAX_RF_PORT];
        if (cur_timestamp[rf_port_index] != 0 &&
            cur_timestamp[rf_port_index] != *ptimestamp) {
            printf("ts error: %" PRId64 "expected=%" PRId64 "diff=%" PRId64 "\n",
                   *ptimestamp, cur_timestamp[rf_port_index], *ptimestamp -
cur_timestamp[rf_port_index]);
        }
        cur_timestamp[rf_port_index] = *ptimestamp + num_rx_samps;
    }
#endif
 done:
    assert(num_rx_samps > 0);
    return num_rx_samps;
}

static void trx_uhd_set_tx_gain(TRXState *s1, double gain, int chain)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;

    s->usrp->set_tx_gain(gain, chain);
}

static void trx_uhd_set_rx_gain(TRXState *s1, double gain, int chain)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;

    s->usrp->set_rx_gain(gain, chain);
}

static void trx_uhd_get_tx_gain(TRXState *s1, double *gain, int chain)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    double txgain;

    txgain = s->usrp->get_tx_gain(chain);
    *gain = txgain;
}

static void trx_uhd_get_rx_gain(TRXState *s1, double *gain, int chain)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    double rxgain;

    rxgain = s->usrp->get_rx_gain(chain);
    *gain = rxgain;
}

static int trx_uhd_get_abs_tx_power(TRXState *s1, float *presult, int chain)
{
    return 1;   /* Not Implemented */
}

static int trx_uhd_get_abs_rx_power(TRXState *s1, float *presult, int chain)
{
    return 1;   /* Not Implemented */
}

static void trx_uhd_msg_recv(TRXState *s1, TRXMsg *msg)
{
    msg->set_string(msg, "error", "not implemented");
    msg->send(msg);    
}

/* return -1 if no GPS, 0 if GPS not locked, 1 if GPS locked */
static int check_gps_lock(TRXUHDState *s)
{
    std::vector<std::string> sensor_names;

    sensor_names = s->usrp->get_mboard_sensor_names(0);
    if (std::find(sensor_names.begin(), sensor_names.end(), 
                  "gps_locked") != sensor_names.end()) {
        return s->usrp->get_mboard_sensor("gps_locked", 0).to_bool();
    } else {
        return -1;
    }
}

static int trx_uhd_start(TRXState *s1, const TRXDriverParams *p)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    const char *sample_fmt, *otw_format;
    int i, j, channel_count, base, n;

    s->tx_channel_count = p->tx_channel_count;
    s->rx_channel_count = p->rx_channel_count;
    s->rf_port_count    = p->rf_port_count;
           
    for(i = 0; i < s->rf_port_count; i++) {
        s->tx_port_channel_count[i] = p->tx_port_channel_count[i];
        s->rx_port_channel_count[i] = p->rx_port_channel_count[i];
        s->sample_rate[i] = p->sample_rate[i].num / p->sample_rate[i].den;
    }

    if (check_gps_lock(s) == 0) {
        printf("Warning: The GPS is not locked. If you need time synchronization, you should restart the program when the GPS is locked.\n");
    }

    channel_count = max_int(s->tx_channel_count, s->rx_channel_count);
    switch(s->sync_type) {
    default:
    case UHD_SYNC_NONE:
        /* no sync */
        /* Note: B210 does not like set_time_now() for MIMO */
        //        s->usrp->set_time_now(uhd::time_spec_t(0.0));
        break;
    case UHD_SYNC_EXTERNAL:
        s->usrp->set_clock_source("external");
        s->usrp->set_time_source("external");
        s->usrp->set_time_unknown_pps(uhd::time_spec_t(0.0));
        /* wait for PPS pulse */
        usleep(1000 * 1000);
        break;
    case UHD_SYNC_MIMO:
        if (channel_count != 2) {
            fprintf(stderr, "MIMO synchronization only works with two channels\n");
            exit(1);
        }
        s->usrp->set_clock_source("mimo", 1);
        s->usrp->set_time_source("mimo", 1);
        s->usrp->set_time_now(uhd::time_spec_t(0.0), 0);
        /* wait for MIMO sync */
        usleep(100 * 1000);
        break;
    case UHD_SYNC_EXTERNAL_CLOCK:
        s->usrp->set_clock_source("external");
        usleep(100 * 1000);
        break;
    }

#if 0
    {
      for(i = 0; i < channel_count; i++)
        printf("%d: time=%s clock=%s\n",
               i, s->usrp->get_time_source(i).c_str(),
               s->usrp->get_clock_source(i).c_str());
    }
#endif

    for (i = n = 0; i < s->rf_port_count; i++) {
        for (j = 0; j < s->tx_port_channel_count[i]; j++, n++) {
            s->usrp->set_tx_rate(s->sample_rate[i], n);
        }
    }

    /* XXX: the B210 cannot set the exact LTE sample rate (there is a
       relative error of about 2e-8 at 11.52 MHz. So from_ticks() and
       to_ticks() give non continuous timestamps. The eNodeB can cope
       with it, but not the B210 on the TX side. So we use the exact
       sample rate in from_ticks() and to_ticks() and give the
       approximate sample rate to the eNodeB because it cannot cope
       with sample rate which does not give an integer number of
       samples per subframe. The drawback is that it cannot work with
       GPS synchronization */

    for (i = n = 0; i < s->rf_port_count; i++) {
        double sr;

        for (j = 0; j < s->rx_port_channel_count[i]; j++, n++) {
            s->usrp->set_rx_rate(s->sample_rate[i], n);
            sr = s->usrp->get_rx_rate(n);

            if (!j) {
                s->real_sample_rate[i] = sr;
            } else if (sr != s->real_sample_rate[i]) {
                fprintf(stderr, "Bad sample rate for rf_port=%d,"
                        " %f found %f expected\n",
                        j, sr, s->real_sample_rate[i]);
                exit(1);
            }
        }
    }

    if (s->board_type != UHD_BOARD_N3x0) {
        for (i = 0; i < s->tx_channel_count; i++) {
            s->usrp->set_tx_bandwidth(p->tx_bandwidth[i], i);
        }
        for (i = 0; i < s->rx_channel_count; i++) {
            s->usrp->set_rx_bandwidth(p->rx_bandwidth[i], i);
        }
    }

    if (p->tx_freq[0] == p->rx_freq[0]) {
        /* TDD: try to use the same antenna for TX and RX */
        for(i = 0; i < s->rx_channel_count; i++) {
            std::vector<std::string> antennas;
            antennas = s->usrp->get_rx_antennas(i);
            /* for SBX/B2x0, RX antenna is by default connected to
               RX2 */
            if (s->rx_antenna_rx) {
                s->usrp->set_rx_antenna("RX2", i);
            } else {
                if (std::find(antennas.begin(), antennas.end(), 
                              "TX/RX") != antennas.end()) {
                    s->usrp->set_rx_antenna("TX/RX", i);
                }
            }
        }
    }

    for(i = 0; i < s->tx_channel_count; i++) {
        std::vector<std::string> sensor_names;

        s->usrp->set_tx_freq(p->tx_freq[i], i);

        /* Note: some boards do not have the lo_locked sensor */
        sensor_names = s->usrp->get_tx_sensor_names(i);
        if (std::find(sensor_names.begin(), sensor_names.end(), 
                      "lo_locked") != sensor_names.end()) {
            while (!s->usrp->get_tx_sensor("lo_locked", i).to_bool()){
                usleep(10 * 1000);
            }
        }
    }
    
    for(i = 0; i < s->rx_channel_count; i++) {
        std::vector<std::string> sensor_names;

        s->usrp->set_rx_freq(p->rx_freq[i], i);

        /* Note: some boards do not have the lo_locked sensor */
        sensor_names = s->usrp->get_rx_sensor_names(i);
        if (std::find(sensor_names.begin(), sensor_names.end(), 
                      "lo_locked") != sensor_names.end()) {
            while (!s->usrp->get_rx_sensor("lo_locked", i).to_bool()){
                usleep(10 * 1000);
            }
        }
    }

    for(i = 0; i < s->tx_channel_count; i++) {
        s->usrp->set_tx_gain(p->tx_gain[i], i);
    }
    
    for(i = 0; i < s->rx_channel_count; i++) {
        s->usrp->set_rx_gain(p->rx_gain[i], i);
    }
#if 0
    /* dump actual parameters */
    printf("Chan Gain(dB)   Freq(MHz)\n");
    for(i = 0; i < s->tx_channel_count; i++) {
        printf(" TX%d %8.1f %11.6f\n",
               i + 1, s->usrp->get_tx_gain(i),
               s->usrp->get_tx_freq(i) / 1e6);
    }
    for(i = 0; i < s->rx_channel_count; i++) {
        printf(" RX%d %8.1f %11.6f\n",
               i + 1, s->usrp->get_rx_gain(i),
               s->usrp->get_rx_freq(i) / 1e6);
    }
#endif
    /* RX */
    sample_fmt = "fc32"; /* complex floats */
    if (s->ul_sample_bits == 16)
        otw_format = "sc16";
    else if (s->ul_sample_bits == 12)
        otw_format = "sc12";
    else
        otw_format = "sc8";

    base = 0;
    for(j = 0; j < s->rf_port_count; j++) {
        uhd::stream_args_t rx_stream_args(sample_fmt, otw_format);
        /* set the channels */
        n = s->rx_port_channel_count[j];
        for(i = 0; i < n; i++)
            rx_stream_args.channels.push_back(base + i);
        s->rx_stream[j] = s->usrp->get_rx_stream(rx_stream_args);
        base += n;
    }

    /* TX */
    if (s->dl_sample_bits == 16)
        otw_format = "sc16";
    else if (s->dl_sample_bits == 12)
        otw_format = "sc12";
    else
        otw_format = "sc8";

    base = 0;
    for(j = 0; j < s->rf_port_count; j++) {
        uhd::stream_args_t tx_stream_args(sample_fmt, otw_format);
        /* set the channels */
        n = s->tx_port_channel_count[j];
        if (!n)
            continue;
        for(i = 0; i < n; i++)
            tx_stream_args.channels.push_back(base + i);
        s->tx_stream[j] = s->usrp->get_tx_stream(tx_stream_args);
        base += n;
    }

#if UHD_VERSION >= 3110000
    pthread_create(&uhd_log_thread_id, NULL, uhd_log_thread_func, s);
#endif

    /* set real time thread priority */
    uhd::set_thread_priority_safe();

    //    printf("UHD start: cur_time=%f\n", s->usrp->get_time_now().get_real_secs());

    uhd::stream_cmd_t stream_cmd(uhd::stream_cmd_t::STREAM_MODE_START_CONTINUOUS);
    stream_cmd.num_samps = 0; /* not used */

    /* stream_now = true does not work with several channels  */
    if (s->rx_channel_count == 1 && s->tx_channel_count == 0)
        stream_cmd.time_spec = s->usrp->get_time_now() + uhd::time_spec_t(0.001);
    else
        stream_cmd.time_spec = s->usrp->get_time_now() + uhd::time_spec_t(0.500);
        
    stream_cmd.stream_now = false;

    s->usrp->issue_stream_cmd(stream_cmd);
    return 0;
}

static void trx_uhd_stop(TRXState *s1)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    int j;

#if UHD_VERSION >= 3110000
    if (uhd_log_thread_id != (pthread_t)-1) {
        s->stop = 1;
        pthread_join(uhd_log_thread_id, NULL);
        uhd_log_thread_id = (pthread_t)-1;
    }
#endif
    /* issue stop RX command */
    uhd::stream_cmd_t stream_cmd(uhd::stream_cmd_t::STREAM_MODE_STOP_CONTINUOUS);
    s->usrp->issue_stream_cmd(stream_cmd);
    
    for(j = 0; j < s->rf_port_count; j++) {
        s->rx_stream[j].reset();
    }
}

static void trx_uhd_end(TRXState *s1)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;

    trx_uhd_stop(s1);

    delete s;
}

#define SRATE_N2x0_COUNT 12

static int n2x0_get_sample_rate(TRXState *s, TRXFraction *psample_rate,
                                int *psample_rate_num, int sample_rate_min)
{
    static const int sample_rate_num_tab[SRATE_N2x0_COUNT] = { 
        1, 2, 3, 4,
        5, 6, 8, 9,
        10, 12, 24
    };
    /* XXX: we only support integer sample rates which are multiple of
       1000. Both limitations could be removed if needed. */
    static const int usrp_div_tab[SRATE_N2x0_COUNT] = {
        /* divisor freq=100/div Mhz */
        50, /* 2 */
        16, /* 6.25 */
        16, /* 6.25 */
        10, /* 10 */
        
        10, /* 10 */
        8, /* 12.5 */
        4, /* 25 */
        4, /* 25 */
        
        4, /* 25 */
        4, /* 25 */
        2, /* 50 */
    };
    int i;

    /* leave some space for the low pass filter */
    sample_rate_min = lround(sample_rate_min * 1.15);

    for(i = 0; i < SRATE_N2x0_COUNT; i++) {
        if (sample_rate_min <= sample_rate_num_tab[i] * 1920000) {
            break;
        }
    }
    if (i == SRATE_N2x0_COUNT)
        return -1;
    *psample_rate_num = sample_rate_num_tab[i];
    psample_rate->num = 100000000 / usrp_div_tab[i];
    psample_rate->den = 1;
    //    printf("num=%d rate=%d\n", *psample_rate_num, psample_rate->num);
    return 0;
}

static bool is_allowed_sample_rate_num(unsigned int n)
{
    if (n == 0)
        return false;
    /* must only have 2, 3 or 5 as prime factors */
    while ((n % 2) == 0)
        n /= 2;
    while ((n % 3) == 0)
        n /= 3;
    while ((n % 5) == 0)
        n /= 5;
    return (n == 1);
}

static int b2x0_get_sample_rate(TRXState *s1, TRXFraction *psample_rate,
                                int *psample_rate_num, int sample_rate_min)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    int i, sample_rate;

    /* leave some space for the low pass filter */
    sample_rate_min = lround(sample_rate_min * 1.15);

    /* allowed master clock: from 1.92 to 61.44 MHz */
    for(i = 1; i <= 32; i++) {
        if (!is_allowed_sample_rate_num(i))
            continue;
        sample_rate = i * 1920000;
        if (sample_rate_min <= sample_rate)
            break;
    }
    if (i > 32) 
        return -1;
    *psample_rate_num = i;
    psample_rate->num = sample_rate;
    psample_rate->den = 1;
    //    printf("num=%d rate=%d\n", *psample_rate_num, psample_rate->num);
    /* update the B200 master clock */
    s->usrp->set_master_clock_rate(sample_rate);
    return 0;
}


#define SRATE_X3x0_COUNT    5

static int x3x0_get_sample_rate(TRXState *s1, TRXFraction *psample_rate,
                                int *psample_rate_num, int sample_rate_min)
{
    static const int usrp_div_tab[SRATE_X3x0_COUNT] = {
        32, /* 5.76 */
        16, /* 11.52 */
        12, /* 15.36 */
        8,  /* 23.04 */
        4,  /* 46.08 */
    };
    int i;

    /* leave some space for the low pass filter */
    sample_rate_min = lround(sample_rate_min * 1.15);

    for(i = 0; i < SRATE_X3x0_COUNT; i++) {
        if (sample_rate_min <= 184.32e6 / usrp_div_tab[i]) {
            break;
        }
    }
    if (i == SRATE_X3x0_COUNT)
        return -1;

    *psample_rate_num = 96 / usrp_div_tab[i];
    psample_rate->num = 184.32e6 / usrp_div_tab[i];
    psample_rate->den = 1;

    return 0;
}

/* Experimental */
static int n3x0_get_sample_rate(TRXState *s1, TRXFraction *psample_rate,
                                int *psample_rate_num, int sample_rate_min)
{
    static const int usrp_div_tab[] = {
        64, 32, 16, 14, 12, 8, 6, 4, 2, 1, 0
    };
    int i, sample_rate;
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    double master_clock_rate = s->usrp->get_master_clock_rate();

    if (master_clock_rate == 122.88e6) {
    } else if (master_clock_rate == 125e6) {
        return -1;
    } else if (master_clock_rate == 153.6e6) {
        return -1;
    }

    /* leave some space for the low pass filter */
    sample_rate_min = lround(sample_rate_min * 1.15);

    for(i = 0; usrp_div_tab[i] > 0; i++) {
        sample_rate = master_clock_rate / usrp_div_tab[i];
        if (sample_rate_min <= sample_rate) {
            if (!(sample_rate % 1000)) {
                psample_rate->num = sample_rate;
                psample_rate->den = 1;
                *psample_rate_num = 0;
                return 0;
            }
        }
    }
    return -1;
}

static int trx_uhd_get_sample_rate(TRXState *s1, TRXFraction *psample_rate,
                                   int *psample_rate_num, int sample_rate_min)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    double master_clock_rate;

    switch (s->board_type) {
    case UHD_BOARD_B2x0:
        return b2x0_get_sample_rate(s1, psample_rate, psample_rate_num, sample_rate_min);
    case UHD_BOARD_N2x0:
        master_clock_rate = s->usrp->get_master_clock_rate();
        if (master_clock_rate == 100e6) {
            /* N2x0 has a clock rate of 100 MHz */
            return n2x0_get_sample_rate(s1, psample_rate, psample_rate_num, sample_rate_min);
        } else {
            /* the user must do manual sample rate configuration */
            return -1;
        }
        break;
    case UHD_BOARD_X3x0:
        return x3x0_get_sample_rate(s1, psample_rate, psample_rate_num, sample_rate_min);
    case UHD_BOARD_N3x0:
        return n3x0_get_sample_rate(s1, psample_rate, psample_rate_num, sample_rate_min);
    }
    return -1;
}

static int trx_uhd_get_tx_samples_per_packet(TRXState *s1)
{
    TRXUHDState *s = (TRXUHDState *)s1->opaque;
    if (s->tx_stream[0])
        return s->tx_stream[0]->get_max_num_samps();
    else
        return 0;
}

static int trx_uhd_get_stats(TRXState *s1, TRXStatistics *m)
{
    m->tx_underflow_count = tx_underflow_count;
    m->rx_overflow_count = rx_overflow_count;
    return 0;
}

void trx_uhd_dump_info(TRXState *s1, trx_printf_cb cb, void *opaque)
{
    std::string str;
    TRXUHDState *s = (TRXUHDState *)s1->opaque;

    uhd::property_tree::sptr tree = s->usrp->get_device()->get_tree();
    str = tree->access<std::string>("/mboards/0/name").get();

    cb(opaque, "UHD version %s, %s\n", UHD_VERSION_ABI_STRING, str.c_str());
}

static void check_abi(void)
{
#ifdef UHD_VERSION_ABI_STRING
    if(std::string(UHD_VERSION_ABI_STRING) == ::uhd::get_abi_string())
        return;
    
    throw std::runtime_error(str(boost::format(
      "\nLTEENB detected ABI compatibility mismatch with UHD library.\n"
      "LTEENB was build against ABI: %s,\n"
      "but UHD library reports ABI: %s\n"
      "Suggestion: install an ABI compatible version of UHD.\n"
                                               ) % UHD_VERSION_ABI_STRING % ::uhd::get_abi_string()));
#endif
}

#define RESERVED_MAGIC  0x24535258

/* Internal reserved structure (not publicly defined in trx_driver.h) */
typedef struct {
    /* Use exactly two "void *" items for magic and extended API version */
    union {
        int i;
        void *p;
    } trx_magic; /* if equal to RESERVED_MAGIC, then next field is actual API version */
    union {
        int i;
        void *p;
    } app_api_version; /* extended version info */
} reserved_internal;
    

int trx_driver_init(TRXState *s1)
{
    TRXUHDState *s;
    char *str, *args, *subdev;
    int dl_sample_bits, ul_sample_bits;
    double val;
    int app_api_version;    
    reserved_internal *resp;
    
    if (s1->trx_api_version != TRX_API_VERSION) {
        fprintf(stderr, "ABI compatibility mismatch between LTEENB and TRX UHD driver (LTEENB ABI version=%d, TRX UHD driver ABI version=%d)\n",
                s1->trx_api_version, TRX_API_VERSION);
        return -1;
    }
    app_api_version = s1->trx_api_version;    
    /* Backward compatibility with older app versions: check Magic value */
    resp = ((reserved_internal*)(&s1->reserved + 1)) - 1;
    if (resp->trx_magic.i == RESERVED_MAGIC) {
        app_api_version = resp->app_api_version.i;
    } else {
        /* Was previously set at start of reserved region which was a bad idea
         * as it may move accross versions
         * Added on 09/26/2022 */
        resp = (reserved_internal*)&s1->reserved;
        if (resp->trx_magic.i == RESERVED_MAGIC)
            app_api_version = resp->app_api_version.i;
    }

    
    check_abi();

    args = trx_get_param_string(s1, "args");
    if (!args) {
        fprintf(stderr, "UHD driver: 'args' parameter\n");
        return -1;
    }
    
    if (trx_get_param_double(s1, &val, "dl_sample_bits") < 0) {
        dl_sample_bits = 16;
    } else {
        dl_sample_bits = (int)val;
    }
    if (dl_sample_bits != 8 && dl_sample_bits != 16 && dl_sample_bits != 12) {
        fprintf(stderr, "UHD driver: unsupported dl_sample_bits. Allowed values: 8 or 16\n");
        return -1;
    }
        
    if (trx_get_param_double(s1, &val, "ul_sample_bits") < 0) {
        ul_sample_bits = 16;
    } else {
        ul_sample_bits = (int)val;
    }
    if (ul_sample_bits != 8 && ul_sample_bits != 16 && ul_sample_bits != 12) {
        fprintf(stderr, "UHD driver: unsupported ul_sample_bits. Allowed values: 8 or 16\n");
        return -1;
    }

    s = new TRXUHDState();

    s->dl_sample_bits = dl_sample_bits;
    s->ul_sample_bits = ul_sample_bits;
    
#if UHD_VERSION < 3110000
    uhd::msg::register_handler(&uhd_msg_handler);
#endif
    
    /* init UHD */
    std::string args1(args);
    s->usrp = uhd::usrp::multi_usrp::make(args1);
    free(args);

    subdev = trx_get_param_string(s1, "tx_subdev");
    if (subdev) {
        std::string subdev1(subdev);
        s->usrp->set_tx_subdev_spec(subdev1);
    }
    free(subdev);
    subdev = trx_get_param_string(s1, "rx_subdev");
    if (subdev) {
        std::string subdev1(subdev);
        s->usrp->set_rx_subdev_spec(subdev1);
    }
    free(subdev);

    /* test if B200/B210 */
    {
        std::string uhd_str;

        uhd::property_tree::sptr tree = s->usrp->get_device()->get_tree();
        uhd_str = tree->access<std::string>("/mboards/0/name").get();
        if (uhd_str == "B200" || uhd_str == "B210") {
            s->board_type = UHD_BOARD_B2x0;
        } else if (uhd_str == "X300" || uhd_str == "X310") {
            s->board_type = UHD_BOARD_X3x0;
        } else if (strstr(uhd_str.c_str(), "n3xx")) {
            s->board_type = UHD_BOARD_N3x0;
        } else {
            s->board_type = UHD_BOARD_N2x0;
        }
    }

#if UHD_VERSION >= 3140000
    /* Stop display of INFO logs */
    //uhd::log::set_console_level(uhd::log::warning);
    uhd::log::set_log_level(uhd::log::off);
#endif

    str = trx_get_param_string(s1, "sync");
    if (!str || !strcmp(str, "none")) {
        s->sync_type = UHD_SYNC_NONE;
    } else if (!strcmp(str, "external")) {
        s->sync_type = UHD_SYNC_EXTERNAL;
    } else if (!strcmp(str, "mimo")) {
        s->sync_type = UHD_SYNC_MIMO;
    } else if (!strcmp(str, "external_clock")) {
        s->sync_type = UHD_SYNC_EXTERNAL_CLOCK;
    } else {
        fprintf(stderr, "Invalid synchronization type. Allowed values are: none, external, mimo\n");
        exit(1);
    }
    free(str);

    if (trx_get_param_double(s1, &val, "exception_retries") < 0) {
        s->exception_retries = 0;
    } else {
        s->exception_retries = (int)val;
    }

    str = trx_get_param_string(s1, "rx_antenna");
    if (str && !strcmp(str, "rx")) {
        s->rx_antenna_rx = 1;
    }
    free(str);

    s1->opaque = s;
    s1->trx_end_func = trx_uhd_end;
    s1->trx_write_func2 = trx_uhd_write2;
    s1->trx_start_func = trx_uhd_start;
    s1->trx_read_func2 = trx_uhd_read2;
    s1->trx_set_tx_gain_func = trx_uhd_set_tx_gain;
    s1->trx_set_rx_gain_func = trx_uhd_set_rx_gain;
    s1->trx_get_sample_rate_func = trx_uhd_get_sample_rate;
    s1->trx_get_tx_samples_per_packet_func = trx_uhd_get_tx_samples_per_packet;
    s1->trx_get_stats = trx_uhd_get_stats;
    s1->trx_dump_info = trx_uhd_dump_info;
    
    s1->trx_get_abs_tx_power_func = trx_uhd_get_abs_tx_power;
    s1->trx_get_abs_rx_power_func = trx_uhd_get_abs_rx_power;

    s1->trx_msg_recv_func = trx_uhd_msg_recv;
    
    if (s1->trx_api_version >= 15) {
        s1->trx_get_tx_gain_func = trx_uhd_get_tx_gain;
        s1->trx_get_rx_gain_func = trx_uhd_get_rx_gain;
    }

    /* Add extra APIs only if App has correct version */
    if (app_api_version >= 16)
        s1->trx_stop_func = trx_uhd_stop;

    return 0;
}

