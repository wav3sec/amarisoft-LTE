/*
 * Copyright (c) 2015 Fabrice Bellard
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "convert_common.hpp"
#include <uhd/utils/byteswap.hpp>
#include <immintrin.h>

typedef struct Complex {
    float re, im;
} Complex;

typedef union Int128Union {
    __m128i v;
    int8_t s8[16];
    uint8_t u8[16];
    int16_t s16[8];
    uint16_t u16[8];
    int32_t s32[4];
    uint32_t u32[4];
    uint64_t u64[2];
} Int128Union;

static inline void _mm_storeh_si128(__m128i *ptr, __m128i v)
{
    _mm_storeh_pd((double *)ptr, (__m128d)v);
}

static inline __m128 _mm_loadl_ps(const float *ptr)
{
    return (__m128)_mm_load_sd((const double *)ptr);
}

static inline void _mm_storel_ps(float *ptr, __m128 val)
{
    _mm_storel_pi((__m64 *)ptr, val);
}

static const Int128Union cfff0 = {
    .u16 = { 0xfff0, 0xfff0, 0xfff0, 0xfff0, 0xfff0, 0xfff0, 0xfff0, 0xfff0 }
};

static const Int128Union c8 = {
    .u16 = { 8, 8, 8, 8, 8, 8, 8, 8 }
};

/* word order: 00022244 4666888a aaccceee */
static const Int128Union perm0_l = {
    .u8 = { 0x0e, 0x0f, 0xff, 0x0a, 0xff, 0xff, 0xff, 0xff,
            0xff, 0x02, 0x03, 0xff, 0x0b, 0xff, 0x06, 0x07, }
};

static const Int128Union perm0_h = {
    .u8 = { 0xff, 0x0c, 0x0d, 0xff, 0xff, 0xff, 0xff, 0xff,
            0x05, 0xff, 0x00, 0x01, 0x08, 0x09, 0xff, 0x04, }
};

static const Int128Union perm1_l = {
    .u8 = { 0xff, 0x02, 0x03, 0xff, 0xff, 0xff, 0xff, 0xff,
            0x0b, 0xff, 0x06, 0x07, 0x0e, 0x0f, 0xff, 0x0a, }
};

static const Int128Union perm1_h = {
    .u8 = { 0x05, 0xff, 0x00, 0x01, 0xff, 0xff, 0xff, 0xff,
            0x08, 0x09, 0xff, 0x04, 0xff, 0x0c, 0x0d, 0xff,  }
};

static void cvt_fc32_to_sc12le(uint32_t *dst, const Complex *src, 
                               int head_len, int n, float mult1)
{
    __m128i a0, a1, b0, c0, c1, d0;
    __m128 mult;

    mult = _mm_set1_ps(mult1);

    if (head_len != 0) {
        Complex src_buf[4];
        memset(src_buf, 0, sizeof(Complex) * (4 - head_len));
        memcpy(src_buf + 4 - head_len, src, sizeof(Complex) * head_len);

        a0 = _mm_cvtps_epi32(((__m128 *)src_buf)[0] * mult);
        a1 = _mm_cvtps_epi32(((__m128 *)src_buf)[1] * mult);

        b0 = _mm_packs_epi32(a0, a1);
        b0 = _mm_adds_epi16(b0, c8.v);
        c0 = _mm_srli_epi16(b0, 4);
        c1 = b0 & cfff0.v;
        d0 = _mm_shuffle_epi8(c0, perm0_l.v) |
            _mm_shuffle_epi8(c1, perm0_h.v);

        switch(head_len) {
        case 1:
            dst[0] = _mm_cvtsi128_si32(d0);
            break;
        case 2:
            dst[0] = _mm_extract_epi32(d0, 3);
            dst[1] = _mm_cvtsi128_si32(d0);
            break;
        default:
        case 3:
            _mm_storeh_si128((__m128i *)dst, d0);
            dst[2] = _mm_cvtsi128_si32(d0);
            break;
        }
        dst += head_len;
        src += head_len;
        n -= head_len;
    }

    while (n >= 4) {
        a0 = _mm_cvtps_epi32(_mm_loadu_ps((float *)src) * mult);
        a1 = _mm_cvtps_epi32(_mm_loadu_ps((float *)(src + 2)) * mult);
        b0 = _mm_packs_epi32(a0, a1);
        b0 = _mm_adds_epi16(b0, c8.v);
        c0 = _mm_srli_epi16(b0, 4);
        c1 = b0 & cfff0.v;
        d0 = _mm_shuffle_epi8(c0, perm0_l.v) |
            _mm_shuffle_epi8(c1, perm0_h.v);

        _mm_storeh_si128((__m128i *)dst, d0);
        dst[2] = _mm_cvtsi128_si32(d0);

        dst += 3;
        src += 4;
        n -= 4;
    }
    if (n != 0) {
        switch(n) {
        case 1:
            a0 = _mm_cvtps_epi32(_mm_loadl_ps((float *)src) * mult);
            a1 = _mm_setzero_si128();
            break;
        case 2:
            a0 = _mm_cvtps_epi32(_mm_loadu_ps((float *)src) * mult);
            a1 = _mm_setzero_si128();
            break;
        default:
        case 3:
            a0 = _mm_cvtps_epi32(_mm_loadu_ps((float *)src) * mult);
            a1 = _mm_cvtps_epi32(_mm_loadl_ps((float *)(src + 2)) * mult);
            break;
        }

        b0 = _mm_packs_epi32(a0, a1);
        b0 = _mm_adds_epi16(b0, c8.v);
        c0 = _mm_srli_epi16(b0, 4);
        c1 = b0 & cfff0.v;
        d0 = _mm_shuffle_epi8(c0, perm0_l.v) |
            _mm_shuffle_epi8(c1, perm0_h.v);
        switch(n) {
        case 1:
            dst[0] = _mm_extract_epi32(d0, 2);
            break;
        case 2:
            _mm_storeh_si128((__m128i *)dst, d0);
            break;
        default:
            _mm_storeh_si128((__m128i *)dst, d0);
            dst[2] = _mm_cvtsi128_si32(d0);
            break;
        }
    }
}

static const Int128Union iperm_l = {
    .u8 = { 0x01, 0x02, 0xff, 0xff, 0x06, 0x07, 0xff, 0xff,
            0x0b, 0x04, 0xff, 0xff, 0x08, 0x09, 0xff, 0xff, }
};

static const Int128Union iperm_h = {
    .u8 = { 0x02, 0x03, 0xff, 0xff, 0x07, 0x00, 0xff, 0xff,
            0x04, 0x05, 0xff, 0xff, 0x09, 0x0a, 0xff, 0xff, }
};

/* preconditions: 0 <= head_len <= 3. n >= head_len */
static void cvt_sc12le_to_fc32(Complex *dst, const uint32_t *src, 
                               int head_len, int n, float mult1)
{
    __m128i a0, bl, bh, c0, c1;
    __m128 mult, d0, d1;

    mult = _mm_set1_ps(mult1);

    if (head_len != 0) {
        Int128Union src_buf;
        
        memset(src_buf.u32, 0, (3 - head_len) * 4);
        memcpy(src_buf.u32 + 3 - head_len, src, head_len * 4);

        a0 = src_buf.v;
        /* a0: 00022244 4666888a aaccceee */
        bl = _mm_shuffle_epi8(a0, iperm_l.v);
        /* bl: zzzzz222 zzzzz666 zzzzzaaa zzzzzeee */
        bl = _mm_slli_epi32(bl, 20);
        bl = _mm_srai_epi32(bl, 20);

        bh = _mm_shuffle_epi8(a0, iperm_h.v);
        /* bh: zzzz000x zzzz444x zzzz888x zzzzcccx */
        bh = _mm_slli_epi32(bh, 16);
        bh = _mm_srai_epi32(bh, 20);
        
        c0 = _mm_unpacklo_epi32(bh, bl);
        c1 = _mm_unpackhi_epi32(bh, bl);
        d0 = _mm_cvtepi32_ps(c0) * mult;
        d1 = _mm_cvtepi32_ps(c1) * mult;

        switch(head_len) {
        case 1:
            _mm_storeh_pd((double *)dst, (__m128d)d1);
            break;
        case 2:
            ((__m128 *)dst)[0] = d1;
            break;
        default:
        case 3:
            _mm_storeh_pd((double *)dst, (__m128d)d0);
            _mm_storeu_ps((float *)(dst + 1), d1);
            break;
        }
        src += head_len;
        dst += head_len;
        n -= head_len;
    }

    while (n >= 4) {
        a0 = _mm_loadu_si128((__m128i *)src);
        /* a0: 00022244 4666888a aaccceee */
        bl = _mm_shuffle_epi8(a0, iperm_l.v);
        /* bl: zzzzz222 zzzzz666 zzzzzaaa zzzzzeee */
        bl = _mm_slli_epi32(bl, 20);
        bl = _mm_srai_epi32(bl, 20);

        bh = _mm_shuffle_epi8(a0, iperm_h.v);
        /* bh: zzzz000x zzzz444x zzzz888x zzzzcccx */
        bh = _mm_slli_epi32(bh, 16);
        bh = _mm_srai_epi32(bh, 20);
        
        c0 = _mm_unpacklo_epi32(bh, bl);
        c1 = _mm_unpackhi_epi32(bh, bl);
        d0 = _mm_cvtepi32_ps(c0) * mult;
        d1 = _mm_cvtepi32_ps(c1) * mult;
        _mm_storeu_ps((float *)dst, d0);
        _mm_storeu_ps((float *)(dst + 2), d1);
        
        src += 3;
        dst += 4;
        n -= 4;
    }
    if (n) {
        __m128i src_buf;
        
        memcpy(&src_buf, src, n * 4);
        
        a0 = src_buf;
        /* a0: 00022244 4666888a aaccceee */
        bl = _mm_shuffle_epi8(a0, iperm_l.v);
        /* bl: zzzzz222 zzzzz666 zzzzzaaa zzzzzeee */
        bl = _mm_slli_epi32(bl, 20);
        bl = _mm_srai_epi32(bl, 20);

        bh = _mm_shuffle_epi8(a0, iperm_h.v);
        /* bh: zzzz000x zzzz444x zzzz888x zzzzcccx */
        bh = _mm_slli_epi32(bh, 16);
        bh = _mm_srai_epi32(bh, 20);
        
        c0 = _mm_unpacklo_epi32(bh, bl);
        c1 = _mm_unpackhi_epi32(bh, bl);
        d0 = _mm_cvtepi32_ps(c0) * mult;
        d1 = _mm_cvtepi32_ps(c1) * mult;

        switch(n) {
        case 1:
            _mm_storel_ps((float *)dst, d0);
            break;
        case 2:
            _mm_storeu_ps((float *)dst, d0);
            break;
        default:
        case 3:
            _mm_storeu_ps((float *)dst, d0);
            _mm_storel_ps((float *)(dst + 2), d1);
            break;
        }
    }
}

DECLARE_CONVERTER(fc32, 1, sc12_item32_le, 1, PRIORITY_SIMD)
{
    const fc32_t *input = reinterpret_cast<const fc32_t *>(inputs[0]);
    size_t output = size_t(outputs[0]);
    
    cvt_fc32_to_sc12le((uint32_t *)(output & ~3), (Complex *)input,
                       output & 3, nsamps, float(scale_factor) * 16.0f);
}

DECLARE_CONVERTER(sc12_item32_le, 1, fc32, 1, PRIORITY_SIMD)
{
    size_t input = size_t(inputs[0]);
    fc32_t *output = reinterpret_cast<fc32_t *>(outputs[0]);

    cvt_sc12le_to_fc32((Complex *)output, (uint32_t *)(input & ~3),
                       input & 3, nsamps, scale_factor);
}
