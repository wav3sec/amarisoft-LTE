#!/bin/bash
# Copyright (C) 2015-2025 Amarisoft
# UHD driver installer version 2025-12-12

set -e

DIR=$(cd $(dirname $0) && pwd)
cd ${DIR}

FE_LIST=$(cat fe_list)
FE=""

function Help
{
    echo "Usage:"
    echo "> $0 [-g] <path> ue|enb [frontend]"
    echo "      frontend: $FE_LIST (default is n2x0)"
    exit 1
}

# Parse command line
while [ "$1" != "" ] ; do
    case "$1" in
    -h|--help)
        Help;
        ;;
    *)
        if [ "$DST" = "" ] ; then
            DST=$(cd $1 && pwd)
        else
            if [ "$TYPE" = "" ] ; then
                TYPE="$1"
            else
                FE=""
                for i in ${FE_LIST} ; do
                    if [ "$i" = "$1" ] ; then
                        FE="$1"
                    fi
                done
                if [ "$FE" = "" ] ; then
                    echo -e "Unknown frontend $1"
                    Help
                fi
            fi
        fi
        ;;
    esac
    shift
done

function HelpTRX
{
    local MSG types
    MSG="$1"
    if [ "$MSG" != "" ] ; then
        echo "$MSG"
    fi

    echo "Usage:"
    types=$(find "$DIR" -maxdepth 1 -printf "%P\n" | grep "config" | cut -d "." -f2 | xargs echo | tr ' ' '|')
    echo "> $0 [--no-upgrade] <path> $types [<frontend name>]"
    exit 1
}

UPGRADE="y"
DIR="$(cd "$(dirname "$0")" && pwd)"

while [ "$1" != "" ] ; do
    case "$1" in
    --no-upgrade)
        UPGRADE="n"
        ;;
    --force-upgrade)
        UPGRADE="f"
        ;;
    --dma32)
        if [ "$DMA32" = "" ] ; then
            Help "Unknown argument: $1"
        fi
        DMA32="y"
        ;;
    --no-package)
        LINUX_PACKAGE=""
        ;;
    *)
        if [ "$DST" = "" ] ; then
            DST=$(cd "$1" && pwd)
            if [ ! -d "$DST" ] ; then
                Help "Directory '$DST' not found"
            fi
        else
            if [ "$TYPE" = "" ] ; then
                TYPE="$1"
            else
                if [ "$FE" = "" ] ; then
                    FE="$1"
                else
                    Help "Unknown argument: $1"
                fi
            fi
        fi
        ;;
    esac
    shift
done

if [ "$DST" = "" ] || [ "$TYPE" = "" ] ; then
    Help
fi

if [ ! -d "${DIR}/config.${TYPE}/" ] ; then
    Help "No configuration files for $TYPE"
fi

function Install
{
    local ID="$1"
    shift

    rm -Rf "${DST}/config/${ID}"
    cp -r "${DIR}/config.${TYPE}/" "${DST}/config/${ID}"
    ${DST}/config/rf_select.sh "${ID}" 1>/dev/null

    for i in "$@"; do
        rm -f "${DST:?}/$i"
        if [ -e "${DIR}/$i" ] ; then
            ln -s "${DIR}/$i" "${DST}"
        fi
    done
}

LINUX_SERVICE=""
LINUX_PACKAGE=""
LINUX_DISTRIB="<unknown>"
LINUX_VERSION=""

if [ -e "/etc/os-release" ] ; then
    LINUX_DISTRIB=$(grep "^ID=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_VERSION=$(grep "^VERSION_ID=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_NAME=$(grep "^PRETTY_NAME=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
fi
if [ "$LINUX_VERSION" = "" ] || [ "$LINUX_DISTRIB" = "" ] ; then
    if [ -e "/etc/lsb-release" ] ; then
        LINUX_DISTRIB=$(grep "^DISTRIB_ID=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_VERSION=$(grep "^DISTRIB_RELEASE=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_NAME=$(grep "^DISTRIB_DESCRIPTION=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
    elif [ -e "/etc/fedora-release" ]; then
        LINUX_DISTRIB="fedora"
        LINUX_VERSION=$(cut -d " " -f3 /etc/fedora-release)
        LINUX_NAME="Fedora"
    fi
fi

if [ "$TARGET" = "" ] ; then
    TARGET="$(uname -m)"
    if [ "$TARGET" = "x86_64" ] ; then
        TARGET="linux"
    fi
fi

LINUX_VERSION=$(echo "$LINUX_VERSION" | cut -d '.' -f1)
LINUX_DISTRIB=$(echo "$LINUX_DISTRIB" | tr '[:upper:]' '[:lower:]')

case "$LINUX_DISTRIB" in
fedora)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mFedora $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -gt 20 ] ; then
        LINUX_PACKAGE="dnf"
    else
        LINUX_PACKAGE="yum"
    fi
    LINUX_SERVICE="systemd"
    ;;
rhel)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$LINUX_NAME found\033[0m"
    fi
    LINUX_PACKAGE="dnf"
    LINUX_SERVICE="systemd"
    ;;
ubuntu)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mUbuntu $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -lt "15" ] ; then
        LINUX_SERVICE="initd"
    else
        LINUX_SERVICE="systemd"
    fi
    LINUX_PACKAGE="apt"
    ;;
centos)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mCent OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="yum"
    ;;
raspbian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mRaspbian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
debian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mDebian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
*)
    echo "Sorry, $LINUX_DISTRIB distribution not supported only available on Fedora, Ubuntu and CentOS distributions."
    exit 1
    ;;
esac

function service_cmd
{
    local name="$1"
    local cmd="$2"

    case $LINUX_SERVICE in
    systemd)
        if [ -e "/lib/systemd/system/${name}.service" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                systemctl -q "${cmd}" "${name}" 1>/dev/null
            else
                systemctl -q "${cmd}" "${name}"
            fi
        fi
        ;;
    initd)
        if [ -e "/etc/init/${name}.conf" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                service "${name}" "${cmd}" 1>/dev/null
            else
                service "${name}" "${cmd}"
            fi
        fi
        ;;
    esac
}

function service_install
{
    local name="$1"
    local path="$2"
    local user="$3"
    local enable="$4"

    case $LINUX_SERVICE in
    systemd)
        rm -f "/lib/systemd/system/${name}.service"
        sed -e "s/<USER>/$user/" -e "s'<PATH>'$path'" "${path}/${name}.service" > "/lib/systemd/system/${name}.service"
        systemctl -q --system daemon-reload

        if [ "$enable" = "y" ] ; then
            systemctl -q enable "${name}"
            #systemctl -q enable NetworkManager-wait-online.service
        else
            systemctl -q disable "${name}"
        fi
        ;;
    initd)
        # Remove legacy
        local deamon="/etc/init.d/${name}.d"
        if [ -e "$deamon" ]; then
            $deamon stop
            update-rc.d "${name}.d" disable
            rm -f "$deamon"
        fi

        if [ "$enable" = "y" ] ; then
            rm -f "/etc/init/${name}.conf"
            sed -e "s/<USER>/$user/" -e "s'<PATH>'$path'" "${path}/${name}.conf" > "/etc/init/${name}.conf"
        else
            rm "/etc/init/${name}.conf"
        fi
        ;;
    esac
}

# Package manager state
LINUX_PACKAGE_READY="y"
function check_package_manager
{
    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    case "$LINUX_PACKAGE" in
    yum|dnf)
        # XXX
        ;;
    apt)
        LOCKED=$(lsof /var/lib/dpkg/lock 2>/dev/null)
        if [ "$LOCKED" != "" ] ; then
            LINUX_PACKAGE_READY="n"
        fi
        ;;
    esac

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}
check_package_manager

function install_package
{
    if [ "$LINUX_PACKAGE" = "" ] ; then return; fi

    if [ "$(whoami)" != "root" ] ; then
        echo "\031[93mRoot access needed to install package.[0m"
        exit 1
    fi

    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    while [ "$1" != "" ] ; do
        case "$LINUX_PACKAGE" in
        yum|dnf)
            if ! $LINUX_PACKAGE list installed "$1" &>/dev/null ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    $LINUX_PACKAGE -qq -y install "$1"
                else
                    $LINUX_PACKAGE -y install "$1"
                fi
            fi
            ;;
        apt)
            if ! apt-cache --quiet=0 policy "$1" | grep "Installed" | grep -v none &>/dev/null ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    apt-get -qq install -y "$1" &>/dev/null
                else
                    apt-get install -y "$1"
                fi
            fi
            ;;
        esac

        if [ "$?" != "0" ] ; then
            echo -e "  \033[93mCan't install package $1\033[0m"
            break
        fi
        shift;
    done

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}

function GetHTState
{
    if [ "$HT_SYS_STATE" = "" ] ; then
        if [ -e "/sys/devices/system/cpu/smt/control" ] ; then
            HT_SYS_STATE=$(cat "/sys/devices/system/cpu/smt/control")
            if [ "$HT_SYS_STATE" = "on" ] ; then
                # Control on but only 1 thread per core
                TPC=$(lscpu | grep -oP "Thread.+per core:.+\K\d+")
                if [ "$TPC" = "1" ] ; then
                    HT_SYS_STATE="off"
                fi
            fi
        fi
    fi
}

function SetHTState
{
    echo "$1" > "/sys/devices/system/cpu/smt/control" 2>&1
}
function question
{
    local i var opt_list C
    var="$3"
    opt_list=`echo "$2" | sed -e 's/\B/ /g'`

    # Already set ?
    if [ "${!var}" != "" ] ; then
        echo -e "$1 [$2] ${!var}"
        return
    fi

    if [ "$USE_DEFAULT" = "y" ] ; then
        for i in $opt_list ; do
            opt=`echo $i | tr '[:upper:]' '[:lower:]'`
            if [ "$opt" != "$i" ] ; then
                echo -e "$1 [$2] $opt"
                eval "$var=$opt"
                return
            fi
        done
    fi

    read -t 0.2 -n 1000 discard || true; # Flush STDIN
    echo -n -e "$1 [$2] "
    while true ; do
        read -n 1 -s C

        eval "$var=$(echo \"$C\" | tr '[:upper:]' '[:lower:]')"

        for i in $opt_list ; do
            opt=`echo "$i" | tr '[:upper:]' '[:lower:]'`
            if [ "$opt" = "${!var}" ] ; then
                echo "$opt"
                return
            fi
            if [ "$opt" != "$i" ] && [ "${!var}" = "" ] ; then
                echo "$opt"
                eval "$var=$opt"
                return
            fi
        done
    done
}

function choice
{
    local C local choice txt var choices indent def i ctxt a defC
    txt="$1"
    var="$2"
    choices="$3"
    indent=$(echo "$txt" | sed -e "s/[^ ].*//")

    # Default
    def="${!var}"
    for choice in $choices ; do
        if [ "$def" = "" ] || [ "${!var}" = "$choice" ] ; then
            def="$choice"
        fi
    done

    # Header
    read -t 0.2 -n 1000 discard || true ; # Flush STDIN
    echo "$txt"
    declare -a A=({1..9} {a..z})
    i=0
    for choice in $choices ; do
        ctxt=$(echo $choice | sed -e "s/_/ /g")
        a=${A[$i]}
        if [ "$def" = "$choice" ] ; then
            echo "$indent  $a) $ctxt (default)"
            defC="$a"
        else
            echo "$indent  $a) $ctxt"
        fi
        i=$(( i + 1 ))
    done

    echo -n "$indent  > "
    while true ; do
        if [ "$USE_DEFAULT" = "y" ] ; then
            C=""
        else
            read -n 1 -s C
        fi

        if [ "$C" = "" ] && [ "$defC" != "" ] ; then
            echo "$defC ($def)"
            eval "$var=\"$def\""
            return
        fi

        i=0
        for choice in $choices ; do
            if [ "${A[$i]}" = "$C" ] ; then
                echo "$C ($choice)"
                eval "$var=\"$choice\""
                return
            fi
            i=$(( i + 1 ))
        done
    done
}

function prompt
{
    while true ; do
        read -t 0.2 -n 1000 discard || true; # Flush STDIN
        echo -e "$1"
        read -p "    > " "$2"

        if [ "${!2}" != "" ] || [ "$3" = "null" ] ; then
            break;
        fi
    done
}

echo "* Install TRX UHD driver to ${DST}"

# Do I need to install ?
LIBUHD=$(whereis libuhd.so | cut -d ':' -f2)
if [ "$LIBUHD" = "" ] ; then
    case "$LINUX_DISTRIB" in
    fedora)
        install_package uhd-devel boost-devel gcc-c++ make
        ;;
    ubuntu)
        if [ "$LINUX_PACKAGE" = "apt" ] ; then
            E=$(apt-cache search libuhd-dev)
            if [ "$E" = "" ] ; then
                question "* UHD driver not available, do you want to install Ettus repository ?" "Yn" "REPOS"
                if [ "$REPOS" = "y" ] ; then
                    echo "* Add Ettus repository for UHD"
                    sudo add-apt-repository -y ppa:ettusresearch/uhd &>/dev/null
                    sudo apt-get -qq update -y
                fi
            fi
        fi
        install_package g++ libuhd-dev libboost-dev make
        ;;
    esac
fi

echo "* Compile"
set +e
make -s
if [ "$?" != "0" ] ; then
    echo "Compilation failed, try c++11 mode"
    make -s USE_CXX11=y
    if [ "$?" != "0" ] ; then
        echo "Compilation failed"
        exit 1
    fi
    echo "c++11 compilation successfull"
fi
set -e

cp trx_uhd.so ${DST}

if [ "$FE" = "" ] ; then
    FE="n2x0"
fi

for i in ${FE_LIST} ; do
    # Delete default files and copy configs
    rm -Rf ${DST}/config/${i}
    cp -r ${DIR}/config.${TYPE}/${i} ${DST}/config/${i}
    cat rrh_check.sh | sed -e "s/##TYPE##/${i}/" > ${DST}/config/$i/rrh_check.sh
    chmod --reference rrh_check.sh ${DST}/config/$i/rrh_check.sh
done

${DST}/config/rf_select.sh $FE 1>/dev/null


# Check calibration
if [ ! -d "$HOME/.uhd/cal" ] ; then
    echo "  ***************"
    echo "  *** Warning ***"
    echo "  ***************"
    echo ""
    echo "  => It seems that your USRP has not been calibrated on this machine."
    echo "     You need it unless you'll have signal stability issue."
    echo "     Please refer to eNB documentation (Section USRP N200/N210 setup)."
    echo "     Note that if you have two USRP for MIMO, you need to calibrate both."
    echo ""
    echo "  Calibration ex:"
    echo "    uhd_cal_rx_iq_balance --args addr=192.168.10.2"
    echo "    uhd_cal_tx_iq_balance --args addr=192.168.10.2"
    echo "    uhd_cal_tx_dc_offset --args addr=192.168.10.2"
    echo ""
fi



