/*
 * Copyright (C) 2020-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-12-12
 */

LTELog.prototype._getDCI = function (logList, index, dci_dir, k)
{
    var cell = this.getCell();
    var nslots = cell.getSlotCount();
    var maxFrameDiff = 10;

    // look in both sides
    for (var step = -1; step < 2; step += 2) {

        var limit = this.timestamp * step + maxFrameDiff*10;
        for (var i = index + step; ; i += step) {

            var log = logList[i];
            if (!log || log.timestamp * step >= limit) break;

            var c = log.getCell();
            if (c !== cell) continue;
            if (log.channel !== PDCCH) continue;
            if (log.ue_id !== this.ue_id) continue;
            if (!log[dci_dir]) continue;

            var slot = log.slot;
            var frame = log.frame;

            var so = log[k];
            /* LTE DCI 0 grant */
            if (so === undefined && dci_dir === 'dci_ul')
                so = 4;
            if (so !== undefined) {
                slot += so;
                while (slot >= nslots) {
                    slot -= nslots;
                    frame++;
                }
            }

            //console.log(this.frame, this.slot, log.frame, log.slot, frame, slot, k, nslots, log, log[k]);
            if (this.frame === frame && this.slot === slot) {
                return log;
            }
            if (Math.abs(log.frame - frame) > maxFrameDiff) break;
        }
    }
    return null;
};

LTELog.prototype._getAckNackLog = function (logList, index, k1)
{
    var slot = this.slot + k1;
    var frame = this.frame;
    var cell = this.getCell();
    var nslots = cell.getSlotCount();
    var maxFrameDiff = 10;
    while (slot >= nslots) {
        slot -= nslots;
        frame++;
    }

    var limit = this.timestamp + maxFrameDiff*10;
    for (var i = index + 1;; i++) {
        var log = logList[i];
        if (!log || log.timestamp >= limit) break;

        if (log.channel !== PUCCH && log.channel !== PUSCH) continue;
        if (log.ue_id !== this.ue_id) continue;
        if (log.getCell() !== cell) continue;
        if (log.ack === undefined) continue;

        if (log.frame === frame && log.slot === slot) {
            return log;
        }
        if (log.frame > frame) break;
    }
};

LTELog.prototype._addPDSCHForAckNack = function (logList, index)
{
    var maxFrameDiff = 10;
    var limit = this.timestamp - maxFrameDiff*10;
    var cell = this.getCell();

    for (var i = index; i--;) {
        var log = logList[i];
        if (!log || log.timestamp < limit) break;

        if (log.channel !== PDSCH) continue;
        if (log.ue_id !== this.ue_id) continue;
        if (log.getCell() !== cell) continue;
        if (log.k1 === undefined) continue;

        var an_log = log._getAckNackLog(logList, i, log.k1);
        if (an_log && an_log.index == index)
            this._linkLogs(log);
        if (an_log && an_log.frame < this.frame)
            break;
    }
};


LTELog.prototype._linkLogs = function (log)
{
    this._aLogs.push(log);
    if (!log._aLogsBack)
        log._aLogsBack = [];
    log._aLogsBack.push(this);
}

LTELog.prototype.getAssociatedLogs = function (logList, index)
{
    switch (this.layer) {
    case 'PHY':
    case 'S72':
        break;
    default:
        return [];
    }

    var aLogs = this._aLogs;
    if (aLogs !== undefined)
        return aLogs.concat(this._aLogsBack || []);

    if (index === undefined)
        index = logList.indexOf(this);

    this._aLogs = [];

    switch (this.layer) {
    case 'PHY':
        this.getAssociatedLogsPhy(logList, index);
        break;
    case 'S72':
        this.getAssociatedLogsS72(logList, index);
        break;
    }
    return this.getAssociatedLogs();
}

LTELog.prototype.getAssociatedLogsS72 = function (logList, index)
{
    switch (this.info) {
    case CTRLDL:
    case CTRLUL:
        var limit = this.timestamp + 10; // XXX: limit
        for (var i = index + 1;; i++) {
            var log = logList[i];
            if (!log || log.timestamp >= limit) break;

            switch (log.info) {
            case IQDL:
            case IQUL:
                if (log.s72dir === this.s72dir &&
                    log.rtc_id === this.rtc_id &&
                    log.sect_id === this.sect_id &&
                    log.slot === this.slot)
                    this._linkLogs(log);
                break;
            }
        }
        break;
    }

    var pid = this.pid;
    if (pid !== undefined) {
        var limit = this.timestamp + 10; // XXX: limit
        for (var i = index + 1;; i++) {
            var log = logList[i];
            if (!log || log.timestamp >= limit) break;
            if (log.layer !== 'S72') continue;

            if (pid === log.pid)
                this._linkLogs(log);
        }

        var limit = this.timestamp - 10; // XXX: limit
        for (var i = index; i--;) {
            var log = logList[i];
            if (!log || log.timestamp <= limit) break;
            if (log.layer !== 'S72') continue;

            if (pid === log.pid)
                this._linkLogs(log);
        }
    }
}

LTELog.prototype.getAssociatedLogsPhy = function (logList, index)
{
    switch (this.channel) {
    case PDSCH:
        var dci = this._getDCI(logList, index, 'dci_dl', 'k0');
        if (dci) {
            this._linkLogs(dci);
            if (this.k1 !== undefined) {
                var an_log = this._getAckNackLog(logList, index, this.k1);
                if (an_log)
                    this._linkLogs(an_log);
            }
        }
        break;
    case PUSCH:
        var dci = this._getDCI(logList, index, 'dci_ul', 'k2');
        if (dci) {
            this._linkLogs(dci);
            if (this.ack !== undefined) {
                this._addPDSCHForAckNack(logList, index);
            }
        }
        break;
    case NPDSCH:
        var log0 = logList[index];
        if (log0.hasRB && log0.tb[0] && !log0.sf && !log0.rep) {
            var limit = this.timestamp + 200; // XXX: limit
            for (var i = index + 1;; i++) {
                var log = logList[i];
                if (!log || log.timestamp >= limit) break;

                if (log.channel === NPUSCH) {
                    if (log.ack === 0 || log.ack === 1 || log.ack === 2 && log.harq === log0.harq) {
                        this._linkLogs(log);
                        break;
                    }
                } else if (log.channel === NPDSCH) {
                    if (log.harq === log0.harq && (log.sf || log.rep))
                        this._linkLogs(log);
                }
            }
        }
        break;
    case PUCCH:
        if (this.ack !== undefined) {
            this._addPDSCHForAckNack(logList, index);
        }
        break;
    }
};

