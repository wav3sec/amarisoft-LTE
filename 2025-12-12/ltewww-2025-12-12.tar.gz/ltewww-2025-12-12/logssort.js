

onmessage = function (e)
{
    var tabTS = e.data.ts;
    var tabID = e.data.id;
    var size = tabTS.byteLength;
    var count = size / 4;

    var tabIdx = new Int32Array(count);
    for (var i = 0; i < count; i++)
        tabIdx[i] = i;

    tabIdx.sort(function (i0, i1) {

        var diff = tabTS[i0] - tabTS[i1];
        if (!diff)
            return tabID[i0] - tabID[i1];

        return diff;
    });

    postMessage(tabIdx, [tabIdx.buffer]);
}

