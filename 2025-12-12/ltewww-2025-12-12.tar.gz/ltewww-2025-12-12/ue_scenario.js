Ext.define("lte.sim.panel", {

    extend: 'Ext.panel.Panel',
    layout: 'fit',

    constructor: function (config) {

        var ref = this._simRef = config.simRef;
        this._simStore = config.simStore;
        this._updateParent = config.updateParent;

        lteLogs.setLogger("SIM", this);

        // Init
        var sim = this._sim = {};
        for (var id in lteSim.sections) {
            sim[id] = lteLogs.clone(ref.data[id]);
        }

        if (sim.ue.type === undefined) {
            if (sim.ue.tun_enabled) {
                sim.ue.type = 'tun';
                delete sim.ue.tun_enabled;
            }
        }

        this.callParent(arguments);
    },

    initComponent: function () {

        var sim = this._sim;

        // Store temporary values
        this._simTmp = {
            // Default
            category: {lte: 10, endc: 10, nbiot: -2},
            nas_5gs: {lte: false, nbiot: false},
            as_release: {lte: 8, endc: 15, nbiot: 13, nr: 15},
            res_len: {xor: 0, milenage: 0, tuak: 0},
        };
        // Current
        var ratInfo = lteSim.getRatInfo(sim.ue.rat);
        this._simTmp.category[ratInfo.eutra] = sim.ue.category;
        this._simTmp.nas_5gs[ratInfo.rat] = sim.ue.nas_5gs;
        this._simTmp.as_release[this.getAsReleaseType(ratInfo)] = sim.ue.as_release;
        this._simTmp.res_len[sim.ue.sim_algo] = sim.ue.res_len;

        // Top menu
        var addSimButton = Ext.create('Ext.Button', {
            text: 'Apply changes',
            scope: this,
            handler: function() {
                this._addSim();
                this._updateParent();
            }
        });
        this._simName = Ext.create("Ext.form.field.Text", {
            value: sim.name,
            width: 200,
            allowBlank: false,
        });
        this._simLoop = Ext.create("Ext.form.field.Number", {
            fieldLabel: 'Loop',
            labelWidth: 40,
            width: 120,
            value: sim.loop || 0,
            allowDecimals: false,
            minValue: 0,
            maxValue: 1000000,
            step: 1
        });

        this.tbar = {
            bodyPadding: 5,
            items: [addSimButton, this._simName, this._simLoop]
        };

        this.callParent(arguments);

        // PDN
        this._pdnStore = Ext.create('Ext.data.Store', {
            fields: ['name', 'type'], // XXX pap/chap
            data: sim.pdn,
        });
        this._pdnCombo = Ext.create('Ext.form.field.ComboBox', {
            store: this._pdnStore,
            queryMode: 'local',
            valueField: 'name',
            displayField: 'name',
            name: 'pdn',
            fieldLabel: 'PDN',
            labelWidth: 50,
            allowBlank: true,
            editable: false,
            listeners: {
                scope: this,
                select: function(me, records, eOpts) {
                    this._pdnSelect(records[0]);
                },
            }
        });
        this._pdnDelete = Ext.create('Ext.Button', {
            iconCls: 'icon-minus',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip("Delete PDN"),
            handler: function () {
                this._pdnStore.remove(this._selectedPDN.record);
                this._pdnSelect(this._pdnStore.getAt(0));
            },
        });

        this._pdnPanel = Ext.create('Ext.panel.Panel', {
            layout: 'fit',
            autoScroll: true,
            title: 'PDN',
            tbar: {
                items: [
                    this._pdnCombo,
                    Ext.create('Ext.Button', {
                        iconCls: 'icon-plus',
                        scope: this,
                        tooltip: lteLogs.tooltip("Add a PDN"),
                        handler: function () {
                            var records = this._pdnStore.add({
                                name: 'pdn' + this._pdnStore.getCount(),
                                type: 'ipv4',
                                connect: 'attach',
                            });
                            this._pdnCombo.select(records[0]);
                            this._pdnSelect(records[0]);
                        },
                    }),
                    this._pdnDelete
                ]
            },
        });

        // Channel simulator
        var chanSimForm = this._chanSimForm = Ext.create('Ext.form.Panel', {
            bodyPadding: 5,
            defaults: {
                xtype: 'numberfield',
                width: '100%',
            },
            items: [{
                /* 0 */
                xtype: 'combobox',
                value: sim.chan.type,
                fieldLabel: 'Channel type',
                name: 'chan.type',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                        {value: 'none', text: 'Channel simulation disabled'},
                        {value: 'awgn', text: 'Additive white Gaussian noise'},
                        {value: 'epa', text: 'Extended Pedestrian A'},
                        {value: 'eva', text: 'Extended Vehicular A'},
                        {value: 'etu', text: 'Extended Typical Urban'},
                        {value: 'mbsfn', text: 'MBSFN channel'},
                        {value: 'tdla30', text: 'TDLA30 channel'},
                        {value: 'tdlb100', text: 'TDLB100 channel'},
                        {value: 'tdlc300', text: 'TDLC300 channel'},
                        {value: 'tdla', text: 'TDL channel A'},
                        {value: 'tdlb', text: 'TDL channel B'},
                        {value: 'tdlc', text: 'TDL channel C'},
                        {value: 'tdld', text: 'TDL channel D'},
                        {value: 'tdle', text: 'TDL channel E'},
                    ],
                    fields: ['value', 'text']
                }),
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        chanSimUpdate();
                    }
                }
            }, {
                /* 1 */
                fieldLabel: 'Max distance (m)',
                minValue: 1,
                maxValue: lteSim.MAX_DISTANCE,
                step: 1,
                value: sim.chan.max_distance,
                name: "chan.max_distance",
                validator: function (val) {
                    var min = chanSimForm.getForm().findField('chan.min_distance').getValue();
                    return val >= min;
                },
            }, {
                /* 2 */
                fieldLabel: 'Min distance (m)',
                minValue: 1,
                maxValue: lteSim.MAX_DISTANCE,
                step: 1,
                value: sim.chan.min_distance,
                name: "chan.min_distance",
                validator: function (val) {
                    var max = chanSimForm.getForm().findField('chan.max_distance').getValue();
                    return val <= max;
                },
            }, {
                /* 3 */
                fieldLabel: 'Speed (km/h)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 0,
                    maxValue: 400,
                    step: 1,
                    flex: 1,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    value: sim.chan.speed,
                    name: 'chan.speed'
                },
                this._createVariabilityField(sim.chan.speed_var, 'chan.speed_var', 0, 200),
                ]
            }, {
                /* 4 */
                fieldLabel: 'Direction (°)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 180,
                    maxValue: -180,
                    step: 1,
                    flex: 1,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    value: sim.chan.direction,
                    name: 'chan.direction'
                },
                this._createVariabilityField(sim.chan.direction_var, 'chan.direction_var', 0, 180),
                ]
            }, {
                /* 5 */
                fieldLabel: 'Initial radius (m)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 0,
                    maxValue: lteSim.MAX_DISTANCE,
                    step: 1,
                    flex: 1,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    value: sim.chan.initial_radius,
                    name: 'chan.initial_radius',
                    validator: function (val) {
                        if (val < 0) return true;
                        var max = chanSimForm.getForm().findField('chan.max_distance').getValue();
                        var min = chanSimForm.getForm().findField('chan.min_distance').getValue();
                        return val >= min && val <= max;
                    },
                },
                this._createVariabilityField(sim.chan.initial_radius_var, 'chan.initial_radius_var', 0, lteSim.MAX_DISTANCE),
                ]
            }, {
                /* 6 */
                fieldLabel: 'Initial angle (°)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: -180,
                    maxValue: 180,
                    step: 1,
                    flex: 1,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    value: sim.chan.initial_angle,
                    name: 'chan.initial_angle',
                },
                this._createVariabilityField(sim.chan.initial_angle_var, 'chan.initial_angle_var', 0, 180),
                ]
            }, {
                /* 7 */
                xtype: 'combobox',
                value: sim.chan.bounce,
                fieldLabel: 'Bounce mode',
                name: 'chan.bounce',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                        {value: 'random', text: 'Random angle'},
                        {value: 'back', text: 'Get back to the opposite direction'},
                        {value: 'normal', text: 'Bounce with a normal angle'},
                    ],
                    fields: ['value', 'text']
                }),
            }, {
                /* 8 */
                fieldLabel: 'Noise spectral density in dBm/Hz',
                minValue: -200,
                maxValue: 0,
                step: 1,
                value: sim.chan.noise_spd,
                name: "chan.noise_spd"
            },
            {
                /* 9 */
                fieldLabel: 'Path loss (A/B)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 0,
                    maxValue: 400,
                    step: 0.1,
                    flex: 1,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    value: sim.chan.A,
                    name: 'chan.A',
                    style: 'margin-right: 10px;'
                }, {
                    xtype: 'numberfield',
                    minValue: 0,
                    maxValue: 400,
                    step: 0.1,
                    flex: 1,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    value: sim.chan.B,
                    name: 'chan.B'
                }]
            },
            {
                /* 10 */
                xtype: 'combobox',
                value: sim.chan.mimo_corr || 'none',
                fieldLabel: 'Mimo correlation',
                name: 'chan.mimo_corr',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                        {value: 'none', text: 'Disabled'},
                        {value: 'low', text: 'Low'},
                        {value: 'medium', text: 'Medium'},
                        {value: 'high', text: 'High'},
                        {value: 'cross_pol_medium', text: 'Medium with cross polarized antennas'},
                        {value: 'cross_pol_high', text: 'High with cross polarized antennas'},
                    ],
                    fields: ['value', 'text']
                }),
            },
            {
                fieldLabel: 'Doppler frequency',
                minValue: -200,
                maxValue: 200,
                step: 0.1,
                value: sim.chan.freq_doppler || 0,
                name: "chan.freq_doppler"
            }, {
                fieldLabel: 'Delay spread in ns',
                minValue: 0,
                maxValue: 1000,
                step: 1,
                value: sim.chan.delay_spread || 0,
                name: "chan.delay_spread"
            }],
        });

        var chanSimUpdate = () => {
            var form = this._chanSimForm;
            var items = form.items.getRange();

            var visible = [];
            var common = true;
            visible[0] = true;

            var idx = 10;
            var mimo_corr = idx++;
            var freq_doppler = idx++;
            var delay_spread = idx++;


            switch (items[0].getValue()) {
            case 'none':
                common = false;
                break;
            case 'awgn':
                visible[mimo_corr] = false;
                visible[freq_doppler] = false;
                visible[delay_spread] = false;
                break;
            case 'tdla':
            case 'tdlb':
            case 'tdlc':
            case 'tdld':
            case 'tdle':
                break;
            default:
                visible[delay_spread] = false;
                break;
            }

            for (var i = 0; i < items.length; i++) {
                if (visible[i] === undefined) visible[i] = common;
                items[i].setVisible(visible[i]);
            }
        };
        chanSimUpdate();

        //collapsed: !sim.power.enabled,
        this._powerOnOffForm = Ext.create('Ext.form.Panel', {
            bodyPadding: 5,
            defaults: {
                xtype: 'numberfield',
                width: '100%',
            },
            items: [{
                fieldLabel: 'Enabled',
                xtype: 'checkbox',
                name: 'power.enabled',
                value: sim.power.enabled,
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        powerOnOffUpdate();
                    }
                }
            }, {
                fieldLabel: 'Duration',
                minValue: 10,
                maxValue: MAX_DURATION,
                step: 1,
                allowDecimals: true,
                value: sim.power.duration,
                name: "power.duration"
            }, {
                fieldLabel: 'Connection attempt/s',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 0.01,
                    allowDecimals: true,
                    maxValue: 200,
                    flex: 1,
                    value: sim.power.caps,
                    name: "power.caps",
                },
                this._createVariabilityField(sim.power.caps_var, 'power.caps_var', 0, 200),
                ]
            }, {
                fieldLabel: 'Max simult. connected UE',
                minValue: 1,
                maxValue: 5000,
                allowDecimals: true,
                value: sim.power.on_max,
                name: "power.on_max"
            }, {
                fieldLabel: 'Power on duration (s)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 1,
                    maxValue: MAX_DURATION,
                    flex: 1,
                    allowDecimals: true,
                    value: sim.power.on_time,
                    name: "power.on_time"
                },
                this._createVariabilityField(sim.power.on_time_var, 'power.on_time_var', 0, 3600),
                ]
            }, {
                fieldLabel: 'Power off duration (s)',
                xtype: 'fieldcontainer',
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    minValue: 1,
                    maxValue: MAX_DURATION,
                    flex: 1,
                    allowDecimals: true,
                    value: sim.power.off_time,
                    name: "power.off_time"
                },
                this._createVariabilityField(sim.power.off_time_var, 'power.off_time_var', 0, 3600),
                ]
            }],
        });
        var powerOnOffUpdate = (function () {
            var form = this._powerOnOffForm;
            var items = form.items.getRange();

            var on = items[0].getValue();
            for (var i = 1; i < items.length; i++) {
                items[i].setVisible(on);
            }
        }).bind(this);
        powerOnOffUpdate();

        // Scripts
        this._scriptStore = Ext.create('Ext.data.Store', {
            fields: ['name', 'type'],
            data: sim.scripts,
        });
        this._scriptCombo = Ext.create('Ext.form.field.ComboBox', {
            store: this._scriptStore,
            queryMode: 'local',
            valueField: 'name',
            displayField: 'name',
            name: 'script',
            fieldLabel: 'Simulations',
            labelWidth: 80,
            allowBlank: true,
            editable: false,
            listeners: {
                scope: this,
                select: function(me, records, eOpts) {
                    this._scriptSelect(records[0]);
                },
            }
        });
        this._scriptAdd = Ext.create('Ext.Button', {
            iconCls: 'icon-plus',
            scope: this,
            tooltip: lteLogs.tooltip("Add a script"),
            handler: this._newScript.bind(this),
        });
        this._scriptDelete = Ext.create('Ext.Button', {
            iconCls: 'icon-moins',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip("Remove script"),
            handler: function () {
                this._scriptStore.remove(this._selectedScript.record);
                this._selectedScript = null;
                this._scriptSelect(this._scriptStore.getAt(0));
            },
        });

        this._scriptPanel = Ext.create('Ext.panel.Panel', {
            layout: 'fit',
            title: 'Simulations',
            tbar: {
                items: [
                    this._scriptCombo,
                    this._scriptAdd,
                    this._scriptDelete,
                ]
            },
        });

        this._createUEPanel = this._createUEForm(sim.ue);

        this._tabPanel = Ext.create('Ext.tab.Panel', {
            activeTab: 0,
            layout: 'fit',
            items: [
                this._createUEPanel,
                {
                    title: 'Power on/off',
                    layout: 'fit',
                    autoScroll: true,
                    items: [this._powerOnOffForm]
                },
                this._scriptPanel,
                this._pdnPanel,
                {
                    title: 'Channel simulation',
                    layout: 'fit',
                    autoScroll: true,
                    items: [this._chanSimForm]
                },
            ]
        });

        this.add(this._tabPanel);
        this._scriptSelect(this._scriptStore.getAt(0));
        this._pdnSelect(this._pdnStore.getAt(0));
        this._tabPanel.setActiveTab(0);
    },

    getAsReleaseType: function (ratInfo) {
        if (ratInfo.nr)
            return 'nr';
        return ratInfo.eutra;
    },

    _createUEForm: function (ue) {

        var ratInfo = lteSim.getRatInfo(ue.rat);

        var multiRat = ratInfo.rat;
        if (!ratInfo.multi) {
            if (multiRat === 'nr') multiRat = 'nr|lte';
            else multiRat = 'lte|nr';
        }

        var panel = Ext.create('Ext.form.Panel', {
            title: 'Create UEs',
            bodyPadding: 5,
            autoScroll: true,
            defaults: {
                xtype: 'numberfield',
                width: '100%',
                labelWidth: 120
            },
            items: [{
                value: ue.count,
                fieldLabel: 'Count',
                maxValue: 50000,
                minValue: 0,
                name: 'ue.count',
            }, {
                xtype: 'fieldcontainer',
                fieldLabel: 'IMSI',
                layout: 'hbox',
                items: [{
                    value: ue.imsi,
                    fieldLabel: '',
                    xtype: 'textfield',
                    name: 'ue.imsi',
                    allowBlank: false,
                    flex: 1,
                    minLength: 1,
                    maxLength: 50,
                    validator: function(val) {
                        return lteSim.genStringValidator(val, /^\d+$/, 15);
                    },
                    inputAttrTpl: " data-qtip='15 digits mixed with ${f(i)}, where i is UE index and f a mathematical formula.'",
                }, {
                    labelWidth: 2,
                    fieldLabel: ' ',
                    labelSeparator: '',
                    boxLabel: 'MNC 3 digits',
                    value: ue.mnc_3digits,
                    width: 105,
                    xtype: 'checkbox',
                    name: 'ue.mnc_3digits',
                }]
            }, {
                value: ue.cell_index,
                fieldLabel: 'Cell list',
                xtype: 'textfield',
                name: 'ue.cell_index',
                allowBlank: true,
                minLength: 0,
                maxLength: 100,
                validator: function(val) {
                    return lteSim.getCellIndexes(val) !== false;
                },
                inputAttrTpl: " data-qtip='List of &amp;lt;index&amp;gt;[/&amp;lt;weight (default=1)&amp;gt;] separeted by commas' ",
            }, {
                value: ue.preferred_plmn_list,
                fieldLabel: 'Preferred PLMNs',
                xtype: 'textfield',
                name: 'ue.preferred_plmn_list',
                allowBlank: true,
                minLength: 0,
                maxLength: 100,
                validator: function(val) {
                    if (!val) return true;
                    var plmns = val.split(/,/);
                    for (var i = 0; i < plmns.length; i++) {
                        if (!plmns[i].match(/^\d{5,6}$/))
                            return false;
                    }
                    return true;
                },
                inputAttrTpl: " data-qtip='List of PLMNs separeted by commas, may be empty'",
            }, {
                xtype: 'fieldcontainer',
                fieldLabel: 'APN',
                layout: 'hbox',
                items: [{
                    value: ue.apn,
                    xtype: 'textfield',
                    name: 'ue.apn',
                    allowBlank: true,
                    minLength: 0,
                    maxLength: 100,
                    flex: 1,
                }, {
                    name: 'ue.attach_pdn_type',
                    value: ue.attach_pdn_type,
                    xtype: 'combobox',
                    labelSeparator: '',
                    labelWidth: 20,
                    fieldLabel: ' ',
                    flex: 0.5,
                    queryMode: 'local',
                    valueField: 'value',
                    displayField: 'text',
                    store: Ext.create('Ext.data.Store', {
                        data: [
                            {value: 'ipv4', text: 'IPv4'},
                            {value: 'ipv6', text: 'IPv6'},
                            {value: 'ipv4v6', text: 'IPv4v6'},
                            {value: 'ethernet', text: 'Ethernet'},
                        ],
                        fields: ['value', 'text']
                    }),
                }]
            }, {
                fieldLabel: 'RAT',
                xtype: 'radiogroup',
                name: 'ue.rat',
                layout: {
                    type: 'hbox',
                },
                items: [
                    {boxLabel: 'LTE', name: 'ue.rat', inputValue: 'lte', checked: ue.rat === 'lte', flex: 1},
                    {boxLabel: 'NB-IoT', name: 'ue.rat', inputValue: 'nbiot', checked: ue.rat === 'nbiot', flex: 1.5},
                    {boxLabel: 'NR SA', name: 'ue.rat', inputValue: 'nr', checked: ue.rat === 'nr', flex: 1.5},
                    {boxLabel: 'Multi RAT', name: 'ue.rat', inputValue: 'multi', checked: ratInfo.multi === true, flex: 2},
                ],
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        updateCategory();
                    }
                }
            }, {
                fieldLabel: 'Multi RAT',
                xtype: 'radiogroup',
                name: 'ue.multi-rat',
                layout: {
                    type: 'hbox',
                },
                items: [
                    {boxLabel: 'NSA',    name: 'ue.multi-rat', inputValue: 'nsa',    checked: multiRat === 'nsa',    flex: 1},
                    {boxLabel: 'LTE+NR', name: 'ue.multi-rat', inputValue: 'lte|nr', checked: multiRat === 'lte|nr', flex: 1.5},
                    {boxLabel: 'NR+LTE', name: 'ue.multi-rat', inputValue: 'nr|lte', checked: multiRat === 'nr|lte', flex: 1.5},
                    {boxLabel: 'NSA+NR', name: 'ue.multi-rat', inputValue: 'nsa|nr', checked: multiRat === 'nsa|nr', flex: 1.5},
                    {boxLabel: 'NR+NSA', name: 'ue.multi-rat', inputValue: 'nr|nsa', checked: multiRat === 'nr|nsa', flex: 1.5},
                ],
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        updateCategory();
                    }
                }
            }, {
                value: ue.as_release,
                fieldLabel: 'AS release',
                name: 'ue.as_release',
                maxValue: 17,
                minValue: 8,
                listeners: {
                    scope: this,
                    change: function (field, as_release, oldValue, eOpts) {
                        this._simTmp.as_release[this.getAsReleaseType(getRatInfo())] = as_release;
                        updateCategory();
                    }
                }
            }, {
                xtype: 'combobox',
                value: ue.nas_5gs,
                fieldLabel: 'NAS type',
                name: 'ue.nas_5gs',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                        {value: false, text: 'EPS'},
                        {value: true, text: '5GS'}
                    ],
                    fields: ['value', 'text']
                }),
                listeners: {
                    scope: this,
                    change: function (field, nas_5gs, oldValue, eOpts) {
                        this._simTmp.nas_5gs[getRatInfo().rat] = nas_5gs;
                        updateCategory();
                    }
                }
            }, {
                xtype: 'combobox',
                value: ue.category,
                fieldLabel: 'Category',
                name: 'ue.category',
                queryMode: 'local',
                valueField: 'value',
                allowBlank: false,
                forceSelection: true,
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                    ],
                    fields: ['value', 'text']
                }),
                listeners: {
                    scope: this,
                    change: function (field, cat, oldValue, eOpts) {
                        this._simTmp.category[getRatInfo().eutra] = cat;
                        updateCategory();
                    }
                }
            }, {
                value: ue.dl_category,
                fieldLabel: 'DL Category',
                name: 'ue.dl_category',
                maxValue: 20,
                minValue: 0,
            }, {
                value: ue.ul_category,
                fieldLabel: 'UL Category',
                name: 'ue.ul_category',
                maxValue: 20,
                minValue: 0,
            }, {
                xtype: 'combobox',
                value: ue.forced_ri,
                fieldLabel: 'Forced RI',
                name: 'ue.forced_ri',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                        {value: 0, text: 'Auto'},
                        {value: 1, text: 'Always SISO'},
                        {value: 2, text: 'Always MIMO'}
                    ],
                    fields: ['value', 'text']
                }),
            }, {
                xtype: 'combobox',
                value: ue.forced_cqi,
                fieldLabel: 'Forced CQI',
                name: 'ue.forced_cqi',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [{value: -1, text: 'Auto'}].concat((new Array(16)).fill(null).map(function (v, i) { return {value: i, text: i}; })),
                    fields: ['value', 'text']
                }),
            }, {
                fieldLabel: 'Algo',
                xtype: 'radiogroup',
                name: 'ue.sim_algo',
                items: [
                    {boxLabel: 'XOR', name: 'ue.sim_algo', inputValue: 'xor', checked: ue.sim_algo === 'xor'},
                    {boxLabel: 'Milenage', name: 'ue.sim_algo', inputValue: 'milenage', checked: ue.sim_algo === 'milenage'},
                    {boxLabel: 'TUAK', name: 'ue.sim_algo', inputValue: 'tuak', checked: ue.sim_algo === 'tuak'},
                    {boxLabel: 'Card reader', name: 'ue.sim_algo', inputValue: 'external', checked: ue.sim_algo === 'external'},
                ],
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        updateAlgo();
                        var form = panel.getForm();
                        form.findField('ue.K').validate();
                    }
                }
            }, {
                value: ue.K,
                fieldLabel: 'K',
                xtype: 'textfield',
                name: 'ue.K',
                minLength: 1,
                allowBlank: false,
                validator: function(val) {
                    if (getSimAlgo() === 'tuak' && lteSim.genStringValidator(val, /^[\dabcdefABCDEF]+$/, 64))
                        return true;
                    return lteSim.genStringValidator(val, /^[\dabcdefABCDEF]+$/, 32);
                },
                inputAttrTpl: " data-qtip='32 hexadecimal chars mixed with ${f(i)}, where i is UE index and f a mathematical formula.' ",
            }, {
                xtype: 'combobox',
                value: ue.res_len,
                fieldLabel: 'Response length',
                name: 'ue.res_len',
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                store: Ext.create('Ext.data.Store', {
                    data: [
                    ],
                    fields: ['value', 'text']
                }),
                listeners: {
                    scope: this,
                    change: function (field, res_len, oldValue, eOpts) {
                        this._simTmp.res_len[getSimAlgo()] = res_len;
                    }
                }
            }, {
                value: ue.op,
                fieldLabel: 'OP',
                xtype: 'textfield',
                name: 'ue.op',
                hidden: ue.sim_algo !== 'milenage' || ue.opc.length > 0,
                minLength: 1,
                allowBlank: true,
                validator: function(val) {
                    return lteSim.genStringValidator(val, /^[\dabcdefABCDEF]+$/, 32);
                },
                inputAttrTpl: " data-qtip='32 hexadecimal chars mixed with ${f(i)}, where i is UE index and f a mathematical formula.' ",
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        updateAlgo();
                    }
                }
            }, {
                value: ue.opc,
                fieldLabel: 'OPc',
                xtype: 'textfield',
                name: 'ue.opc',
                hidden: ue.sim_algo !== 'milenage' || ue.op.length > 0,
                minLength: 1,
                allowBlank: true,
                validator: function(val) {
                    return lteSim.genStringValidator(val, /^[\dabcdefABCDEF]+$/, 32);
                },
                inputAttrTpl: " data-qtip='32 hexadecimal chars mixed with ${f(i)}, where i is UE index and f a mathematical formula.' ",
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        updateAlgo();
                    }
                }
            }, {
                value: ue.top,
                fieldLabel: 'TOP',
                xtype: 'textfield',
                name: 'ue.top',
                hidden: ue.sim_algo !== 'tuak',
                minLength: 1,
                allowBlank: true,
                validator: function(val) {
                    return lteSim.genStringValidator(val, /^[\dabcdefABCDEF]+$/, 64);
                },
                inputAttrTpl: " data-qtip='64 hexadecimal chars mixed with ${f(i)}, where i is UE index and f a mathematical formula.' ",
            }, {
                fieldLabel: 'Type',
                xtype: 'radiogroup',
                name: 'ue.type',
                items: [
                    {boxLabel: 'Sim', name: 'ue.type', inputValue: 'sim', checked: ue.type === 'sim'},
                    {boxLabel: 'TUN', name: 'ue.type', inputValue: 'tun', checked: ue.type === 'tun'},
                    {boxLabel: 'Remote', name: 'ue.type', inputValue: 'rue', checked: ue.type === 'rue'},
                ],
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        var form = panel.getForm();
                        switch (newValue['ue.type']) {
                        case 'sim':
                            form.findField('ue.tun_setup_script').setHidden(true);
                            form.findField('ue.rue_addr').setHidden(true);
                            break;
                        case 'tun':
                            form.findField('ue.tun_setup_script').setHidden(false);
                            form.findField('ue.rue_addr').setHidden(true);
                            break;
                        case 'rue':
                            form.findField('ue.tun_setup_script').setHidden(false);
                            form.findField('ue.rue_addr').setHidden(false);
                            break;
                        }
                    }
                }
            }, {
                xtype: 'fieldcontainer',
                fieldLabel: '',
                items: [{
                    fieldLabel: 'Setup script',
                    value: ue.tun_setup_script,
                    xtype: 'textfield',
                    name: 'ue.tun_setup_script',
                    hidden: ue.type === 'sim',
                }, {
                    fieldLabel: 'Remote address',
                    value: ue.rue_addr,
                    xtype: 'textfield',
                    name: 'ue.rue_addr',
                    hidden: ue.type !== 'rue',
                }]
            }, {
                value: ue.spec_tolerance,
                fieldLabel: 'Specification tolerance',
                name: 'ue.spec_tolerance',
                xtype: 'checkbox',
            }, {
                value: ue.purge_all,
                fieldLabel: 'Remove UEs',
                name: 'ue.purge_all',
                xtype: 'checkbox',
            }]
        });

        var getRatInfo = function () {
            var form = panel.getForm();
            var rat = form.findField('ue.rat').getValue()['ue.rat'];
            if (rat === 'multi')
                rat = form.findField('ue.multi-rat').getValue()['ue.multi-rat'];
            return lteSim.getRatInfo(rat);
        };

        var updateCategory = (function () {

            var form = panel.getForm();
            var ratInfo = getRatInfo();

            var fields = {
                'ue.as_release': {},
                'ue.nas_5gs': {},
                'ue.category': {},
                'ue.dl_category': {},
                'ue.ul_category': {},
                'ue.forced_ri': {},
                'ue.multi-rat': {},
            };
            for (var id in fields) {
                fields[id].comp = form.findField(id);
                fields[id].state = false;
            }

            var asType = this.getAsReleaseType(ratInfo);
            var as = this._simTmp.as_release[asType];

            var eutra = ratInfo.eutra;
            if (eutra) {
                var cat = this._simTmp.category[eutra];

                if (eutra === 'endc' && as < 15)        as = 15;
                else if (cat == -3 && as < 14)          as = 14;
                else if (cat < 0 && as < 13)            as = 13;
                else if (cat == 0 && as < 12)           as = 12;
                else if (cat == 13 && as < 12)          as = 12;
                else if (cat >= 9 && as < 11)          as = 11;
                else if (cat >= 6 && as < 10)           as = 10;
                else if (cat === 'custom' && as < 12)   as = 12;

                fields['ue.forced_ri'].state = cat >= 2;

                if (cat === 'custom') {
                    fields['ue.dl_category'].state = true;
                    fields['ue.ul_category'].state = true;
                }
                fields['ue.as_release'].state = true;
                fields['ue.category'].state = true;

                var category = fields['ue.category'].comp;
                switch (eutra) {
                case 'nbiot':
                    category.getStore().loadData([
                        {value: -3, text: 'NB-IoT NB2'},
                        {value: -2, text: 'NB-IoT NB1'},
                    ]);
                    break;
                case 'lte':
                    category.getStore().loadData([
                        {value: -1, text: 'Category M1'},
                        {value: 0, text: 'Category 0'},
                        {value: 1, text: 'Category 1'},
                        {value: 2, text: 'Category 2'},
                        {value: 3, text: 'Category 3'},
                        {value: 4, text: 'Category 4'},
                        {value: 5, text: 'Category 5'},
                        {value: 6, text: 'Category 6'},
                        {value: 7, text: 'Category 7'},
                        {value: 8, text: 'Category 8'},
                        {value: 9, text: 'Category 9'},
                        {value: 10, text: 'Category 10'},
                        {value: 11, text: 'Category 11'},
                        {value: 12, text: 'Category 12'},
                        {value: 13, text: 'Category 13'},
                        {value: 'custom', text: 'Custom DL/UL config'},
                    ]);
                    break;
                case 'endc':
                    category.getStore().loadData([
                        {value: 1, text: 'Category 1'},
                        {value: 2, text: 'Category 2'},
                        {value: 3, text: 'Category 3'},
                        {value: 4, text: 'Category 4'},
                        {value: 5, text: 'Category 5'},
                        {value: 6, text: 'Category 6'},
                        {value: 7, text: 'Category 7'},
                        {value: 8, text: 'Category 8'},
                        {value: 9, text: 'Category 9'},
                        {value: 10, text: 'Category 10'},
                        {value: 11, text: 'Category 11'},
                        {value: 12, text: 'Category 12'},
                        {value: 13, text: 'Category 13'},
                        {value: 'custom', text: 'Custom DL/UL config'},
                    ]);
                    break;
                }
                category.setValue(this._simTmp.category[eutra]);
            }

            if (ratInfo.nr) {
                fields['ue.as_release'].state = true;
                if (as < 15) as = 15;
            }
            if (ratInfo.multi)
                fields['ue.multi-rat'].state = true;
            if (ratInfo.rat === 'lte' || ratInfo.rat === 'nbiot') {
                fields['ue.nas_5gs'].state = true;
                fields['ue.nas_5gs'].comp.setValue(this._simTmp.nas_5gs[ratInfo.rat]);
            }

            fields['ue.as_release'].comp.setValue(as);

            for (var id in fields) {
                form.findField(id).setHidden(!fields[id].state);
            }

        }).bind(this);

        var getSimAlgo = function () {
            var form = panel.getForm();
            return form.findField('ue.sim_algo').getValue()['ue.sim_algo'];
        };

        var updateAlgo = (function () {

            var form = panel.getForm();
            var op = form.findField("ue.op");
            var opc = form.findField("ue.opc");
            var _top = form.findField("ue.top");
            var imsi = form.findField('ue.imsi');
            var k = form.findField('ue.K');
            var res_len = form.findField('ue.res_len');

            // res_len
            var sim_algo = getSimAlgo();
            var data = [{value: 0, text: 'Automatic'}];
            switch (sim_algo) {
            case 'tuak':
                data.push(
                    {value: 4, text: '4'},
                    {value: 8, text: '8'},
                    {value: 16, text: '16'},
                );
                _top.setHidden(false);
                op.setHidden(true);
                opc.setHidden(true);
                imsi.setHidden(false);
                k.setHidden(false);
                _top.validate();
                break;
            case 'milenage':
                for (var i = 4; i < 16; i++) {
                    data.push({value: i, text: '' + i});
                }
                k.setHidden(false);
                op.setHidden(opc.getValue().length > 0);
                opc.setHidden(op.getValue().length > 0);
                opc.validate();
                op.validate();
                _top.setHidden(true);
                imsi.setHidden(false);
                break;
            case 'external':
                k.setHidden(true);
                imsi.setHidden(true);
                op.setHidden(true);
                opc.setHidden(true);
                _top.setHidden(true);
                res_len.setHidden(true);
                res_len = null;
                break;
            default:
                for (var i = 4; i < 16; i++) {
                    data.push({value: i, text: '' + i});
                }
                _top.setHidden(true);
                k.setHidden(false);
                op.setHidden(true);
                opc.setHidden(true);
                imsi.setHidden(false);
                break;
            }
            if (res_len) {
                res_len.setHidden(false);
                res_len.getStore().loadData(data);
                res_len.setValue(this._simTmp.res_len[sim_algo]);
            }

        }).bind(this);

        updateCategory();
        updateAlgo();

        var fields = panel.getForm().getFields();
        for (var i = 0, length = fields.length; i < length; i++) {
            fields.getAt(i).validate();
        }

        return panel;
    },

    _createVariabilityField: function (value, id, min, max) {
        return {
            fieldLabel: '&nbsp;+/-',
            labelSeparator: '',
            width: 110,
            labelWidth: 20,
            xtype: 'numberfield',
            minValue: min,
            maxValue: max,
            allowDecimals: true,
            value: value,
            name: id,
        };
    },

    _pdnUpdate: function () {
        if (this._selectedPDN) {
            if (this._selectedPDN.form.getForm().isValid()) {
                var values = this._selectedPDN.form.getForm().getFieldValues();
                for (var id in values) {
                    this._selectedPDN.record.set(id, values[id]);
                }
            }
        }
    },

    _pdnSelect: function (record) {

        this._pdnUpdate();
        this._selectedPDN = null;

        this._pdnPanel.removeAll();
        if (!record) {
            this._pdnDelete.setDisabled(true);
            this._pdnCombo.setValue('');
            return;
        }
        this._pdnDelete.setDisabled(false);

        var pdn = record.getData();
        this._selectedPDN = {
            pdn: pdn,
            record: record,
            form: Ext.create('Ext.form.Panel', {
                bodyPadding: 5,
                items: [{
                    value: pdn.name,
                    fieldLabel: 'Name',
                    xtype: 'textfield',
                    name: 'name',
                    minLength: 1,
                    allowBlank: false,
                    validator: function(val) {
                        return !!(val && val.match(/^[\w\d][\w\d-\.]*$/));
                    }
                }, {
                    fieldLabel: 'Type',
                    xtype: 'radiogroup',
                    name: 'type',
                    items: [
                        {boxLabel: 'IPv4', name: 'type', inputValue: 'ipv4', checked: pdn.type === 'ipv4'},
                        {boxLabel: 'IPv6', name: 'type', inputValue: 'ipv6', checked: pdn.type === 'ipv6'},
                        {boxLabel: 'IPv4v6', name: 'type', inputValue: 'ipv4v6', checked: pdn.type === 'ipv4v6'},
                        {boxLabel: 'Ethernet', name: 'type', inputValue: 'ethernet', checked: pdn.type === 'ethernet'},
                    ],
                }, {
                    fieldLabel: 'Connect',
                    xtype: 'radiogroup',
                    name: 'connect',
                    items: [
                        {boxLabel: 'On attach', name: 'connect', inputValue: 'attach', checked: pdn.connect === 'attach'},
                        {boxLabel: 'On demand', name: 'connect', inputValue: 'demand', checked: pdn.connect === 'demand'},
                    ],
                    listeners: {
                        scope: this,
                        change: function (field, newValue, oldValue, eOpts) {
                        }
                    }
                }]
            })
        };
        this._pdnPanel.add(this._selectedPDN.form);
        this._pdnCombo.setValue(pdn.name);
    },

    _updateScript: function () {
        if (this._selectedScript) {
            console.log('???', this._selectedScript.form.getForm().getFieldValues());
            if (this._selectedScript.form.getForm().isValid()) {
                var values = this._selectedScript.form.getForm().getFieldValues();
                for (var id in values) {
                    this._selectedScript.record.set(id, values[id]);
                }
            } else {
                Ext.Msg.alert("Error", "Invalid configuration");
            }
        }
    },

    _scriptSelect: function (record) {

        this._updateScript();
        this._selectedScript = null;

        this._scriptPanel.removeAll();
        if (!record) {
            this._scriptDelete.setDisabled(true);
            this._scriptCombo.setValue('');
            return;
        }
        this._scriptDelete.setDisabled(false);

        var script = record.getData();
        this._selectedScript = {
            script: script,
            record: record,
            form: Ext.create('Ext.form.Panel', {
                bodyPadding: 5,
                width: '100%',
                defaults: {
                    width: '100%',
                },
                items: this._getScriptFormItems(script),
                autoScroll: true,
                listeners: {
                    scope: this,
                    validitychange: function(form, valid, eOpts) {
                    }
                },
            })
        };
        this._scriptPanel.add(this._selectedScript.form);
        this._scriptCombo.setValue(script.name);
    },

    _addSimValue: function (sim, fields) {

        var skip = {};
        for (var i = 0, length = fields.length; i < length; i++) {
            var field = fields.getAt(i);
            var name = field.getName();
            if (skip[name]) continue;
            var ids = name.split('.');

            var value = field.getValue();
            if (typeof value === 'object' && value !== null) {
                value = value[name]; // Subfields must have same name
            }
            sim[ids[0]][ids[1]] = value;
            skip[name] = true;
        }
    },

    _addSim: function () {

        var name = this._simName.getValue();
        if (!name) {
            Ext.Msg.alert("Error", "Name is empty");
            return;
        }

        var sim = this._sim;
        sim.name = name;

        // PDNs
        this._pdnUpdate();
        sim.pdn = [];
        for (var i = 0; i < this._pdnStore.getCount(); i++) {
            var pdn = this._pdnStore.getAt(i).getData();
            delete pdn.id;
            sim.pdn.push(pdn);
        }

        // Scripts
        this._updateScript();
        sim.scripts = [];
        for (var i = 0; i < this._scriptStore.getCount(); i++) {
            var script = this._scriptStore.getAt(i).getData();
            delete script.id;
            sim.scripts.push(script);
        }

        // Others
        this._addSimValue(sim, this._createUEPanel.getForm().getFields());
        this._addSimValue(sim, this._powerOnOffForm.getForm().getFields());
        this._addSimValue(sim, this._chanSimForm.getForm().getFields());

        // UEs
        var ue = sim.ue;
        if (ue.rat === 'multi')
            ue.rat = ue['multi-rat'];
        delete ue['multi-rat'];

        sim.loop = this._simLoop.getValue();

        for (var i in sim) {
            this._simRef.set(i, sim[i]);
        }
        this._simRef.dirty = true;
        this._simStore.sync();
    },

    _newScript: function () {
        var sim = this._sim;
        if (sim.ue.count) {
            var defList = lteSim.ipDefinitionList.filter( (def) => {
                if (def.noIp) return true;
                switch (sim.ue.type) {
                case 'sim':
                    return def.type !== 'app';
                default:
                    return def.type === 'app';
                }
            });
        } else {
            defList = lteSim.ipDefinitionList.slice();
        }

        var addScriptStore = Ext.create('Ext.data.Store', {
            fields: ["name", "type", "fields"],
            data: defList,
        });
        var addScriptCombo = Ext.create('Ext.form.field.ComboBox', {
            store: addScriptStore,
            queryMode: 'local',
            valueField: 'type',
            displayField: 'name',
            name: 'type',
            fieldLabel: 'Type',
            allowBlank: false,
            width: '100%',
            listeners: {
                scope: this,
                change: function(me, newValue, oldValue, eOpts) {
                    var length = this._sim.scripts.length;
                    for (var i = 0, max = length; i < length; i++) {
                        var m = this._sim.scripts[i].name.match(/#(\d+)$/);
                        if (m && m.length > 0)
                            max = Math.max(max, m[1] - 0);
                    }
                    addScriptName.setValue(lteSim.getIpDefinition(newValue).name + " #" + max);
                }
            }
        });
        var addScriptName = Ext.create("Ext.form.field.Text", {
            xtype: 'textfield',
            value: '',
            allowBlank: false,
            name: 'name',
            fieldLabel: 'Name',
            width: '100%',
        });
        var addScriptForm = Ext.create('Ext.form.Panel', {
            bodyPadding: 5,
            items: [addScriptCombo, addScriptName],
            autoScroll: true,
            buttons: [{
                text: "Add script",
                scope: this,
                handler: function() {
                    if (addScriptForm.isValid()) {
                        var script = addScriptForm.getForm().getFieldValues();
                        var records = this._scriptStore.add(script);
                        lteSim.updateSimConfig({scripts: [script]});
                        this._scriptCombo.select(records[0]);
                        this._scriptSelect(records[0]);
                        window.close();
                    }
                }
            }]
        });

        var window = Ext.create('Ext.window.Window', {
            title: 'Add script',
            height: 150,
            width: 400,
            layout: 'fit',
            modal: true,
            resizeable: false,
            items: addScriptForm,
        });
        window.show();
    },

    _getScriptFormItems: function (script) {

        this.info("Set script", script);

        var def = lteSim.getIpDefinition(script.type);

        var items = [{
            xtype: 'textfield',
            name: 'type',
            value: def.name,
            fieldLabel: 'Type',
            editable: false,
            disabled: true,
        }, {
            xtype: 'textfield',
            name: 'name',
            value: script.name,
            fieldLabel: 'Name',
            allowBlank: false,
        }, {
            xtype: 'numberfield',
            name: 'probability',
            fieldLabel: 'Probability',
            value: script.probability,
            allowDecimals: true,
            decimalPrecision: 2,
            minValue: 0,
            step: 0.01,
            maxValue: 1,
        }, {
            fieldLabel: 'Start delay',
            xtype: 'fieldcontainer',
            layout: 'hbox',
            items: [{
                xtype: 'numberfield',
                name: 'start_delay',
                value: script.start_delay,
                allowDecimals: true,
                decimalPrecision: 3,
                minValue: 0,
                step: 0.5,
                maxValue: MAX_DURATION,
                flex: 1,
            },
            this._createVariabilityField(script.start_delay_var, 'start_delay_var', 0, 3600),
            ]
        }, {
            fieldLabel: 'Duration',
            xtype: 'fieldcontainer',
            layout: 'hbox',
            items: [{
                xtype: 'numberfield',
                name: 'duration',
                maxValue: MAX_DURATION,
                value: script.duration,
                allowDecimals: true,
                decimalPrecision: 3,
                minValue: 0.5,
                step: 0.5,
                flex: 1,
            },
            this._createVariabilityField(script.duration_var, 'duration_var', 0, 3600),
            ]
        }];

        Object.keys(def.fields).forEach( (field) => {
            switch (field) {
            case 'apn':
                var item = {
                    xtype: 'textfield',
                    name: 'apn',
                    fieldLabel: 'APN',
                    value: script.apn || '',
                };
                break;
            case "url":
                var item = {
                    xtype: 'textfield',
                    value: script.url,
                    fieldLabel: 'URL',
                    allowBlank: false,
                    validator: function(val) {
                        if (val.match(/^http:\/\/[\w\d]+\.\w+/))
                            return true;
                        return lteLogs.tooltip("URL required");
                    }
                };
                break;

            case 'payload_len':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Payload size',
                    value: script.payload_len,
                    step: 100,
                    maxValue: 1500,
                    minValue: 12,
                };
                break;

            case 'bit_rate':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Bitrate ',
                    value: script.bit_rate,
                    maxValue: 15e9,
                    minValue: 1000,
                    step: 100000,
                };
                break;

            case 'delay':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Delay',
                    maxValue: MAX_DURATION,
                    value: script.delay,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    minValue: 0.5,
                    step: 0.1,
                };
                break;

            case 'max_delay':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Maximum delay',
                    maxValue: MAX_DURATION,
                    value: script.max_delay,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    minValue: 0,
                    step: 0.1,
                };
                break;

            case 'max_cnx':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Maximum connections',
                    maxValue: 1000,
                    value: script.max_cnx,
                    allowDecimals: false,
                    minValue: 1,
                    step: 1,
                };
                break;

            case 'dst_addr':
                var item = {
                    xtype: 'textfield',
                    fieldLabel: 'Destination',
                    value: script.dst_addr,
                    validator: function(val) {
                        if (script.type === 'ethernet') {
                            if (val === '*' || val.match(/^[a-f\d]{2}:[a-f\d]{2}:[a-f\d]{2}:[a-f\d]{2}:[a-f\d]{2}:[a-f\d]{2}$/i))
                                return true;
                            return lteLogs.tooltip("MAC Address required");
                        }
                        if (val.match(/^\d+\.\d+\.\d+\.\d+$/))
                            return true;
                        var ipv6 = val.match(/^([0-9a-fA-F]{0,4}:){1,7}:?[0-9a-fA-F]{0,4}$/);
                        if (ipv6) {
                            if (val.indexOf("::") >= 0 || ipv6.split(/:/).length === 8)
                                return true;
                        }
                        return lteLogs.tooltip("Address IP required");
                    }
                };
                break;

            case 'connections':
                var item = {
                    fieldLabel: 'Connections',
                    xtype: 'fieldcontainer',
                    layout: 'hbox',
                    items: [{
                        xtype: 'numberfield',
                        minValue: 1,
                        maxValue: 20,
                        step: 1,
                        width: 100,
                        allowDecimals: false,
                        value: script.connections,
                        name: 'connections'
                    }, {
                        xtype: 'numberfield',
                        fieldLabel: 'Window size',
                        labelWidth: 90,
                        minValue: 0,
                        maxValue: 16*1024*1024,
                        step: 65536,
                        flex: 1,
                        allowDecimals: false,
                        value: script.window_size,
                        name: 'window_size',
                        margin: '0 0 0 10'
                    }]
                };
                break;

            case 'threshold':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Minimum bitrate',
                    value: script.threshold,
                    maxValue: 15e9,
                    minValue: 1000,
                    step: 100000,
                };
                break;

            case 'direction':
                var item = {
                    xtype: 'radiogroup',
                    fieldLabel: 'Direction',
                    columns: 3,
                    items: [
                        { boxLabel: 'DL/UL', name: 'direction', inputValue: 'all', checked: script.direction === 'all' },
                        { boxLabel: 'DL', name: 'direction', inputValue: 'dl', checked: script.direction === 'dl' },
                        { boxLabel: 'UL', name: 'direction', inputValue: 'ul', checked: script.direction === 'ul' },
                    ]
                };
                break;

            case 'mean_talking_duration':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Mean talking duration',
                    maxValue: 60,
                    value: script.mean_talking_duration,
                    allowDecimals: true,
                    decimalPrecision: 1,
                    minValue: 1,
                    step: 0.1,
                };
                break;

            case 'vaf':
                var item = {
                    xtype: 'numberfield',
                    fieldLabel: 'Voice activity factor %',
                    maxValue: 100,
                    value: script.vaf,
                    allowDecimals: false,
                    //decimalPrecision: 0,
                    minValue: 1,
                    step: 1,
                };
                break;

            case 'prog':
                var item = {
                    xtype: 'textfield',
                    fieldLabel: 'Program',
                    value: script.prog,
                };
                break;

            case 'args':
                var item = {
                    xtype: 'textfield',
                    fieldLabel: 'Arguments',
                    value: script.args,
                    validator: function(val) {
                        return lteSim.genStringExec(val, {d: 0, i: 0}) !== null;
                    },
                    inputAttrTpl: " data-qtip='String with $d, $i or ${f(i, d)}, where i is UE index, d duration and f a mathematical formula.'",
                };
                break;

            case 'tag':
                var item = {
                    xtype: 'textfield',
                    fieldLabel: 'Tag',
                    value: script.tag,
                };
                break;

            default:
                return;
            }
            item.name = field;
            items.push(item);
        });

        return items;
    }
});


