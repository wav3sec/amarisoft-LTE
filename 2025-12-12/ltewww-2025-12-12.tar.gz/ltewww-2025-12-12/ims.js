/*
 * Copyright (C) 2017-2025 Amarisoft
 */

Ext.define("lte.ims.tab", {

    extend: 'lte.client.tab',

    _chartList: [{
        title:        'Messages',
        fieldType:    ['messages'],
        serieWidth: 400,
        unit: ''
    }, {
        title:        'Errors',
        fieldType:    ['errors'],
        serieWidth: 400,
        unit: ''
    }],

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var usersUpdate = function (list, noRemove) {
            var bindings = {};
            var dialogs = {};

            list.forEach(function (user) {

                if (user.bindings) {
                    user.bindings.forEach(function (binding) {
                        bindings[binding.uri] = binding;
                        binding.impi = user.impi;
                    });
                }

                if (user.dialogs) {
                    user.dialogs.forEach(function (dialog) {
                        if (dialog.state !== 'stop')
                            dialogs[dialog.session_id] = dialog;
                    });
                }
            });

            // Add bindings
            for (var i = bindingsStore.getCount(); i--;) {

                var rec = bindingsStore.getAt(i);
                var uri = rec.get('uri');
                if (bindings[uri]) {
                    rec.set(bindings[uri]);
                    delete bindings[uri];
                } else if (!noRemove) {
                    bindingsStore.remove(rec);
                }
            }
            bindingsStore.add(Object.keys(bindings).map(function (uri) { return bindings[uri]; }));

            // Add dialogs
            for (var i = dialogsStore.getCount(); i--;) {

                var rec = dialogsStore.getAt(i);
                var sid = rec.get('session_id');
                if (dialogs[sid]) {
                    rec.set(dialogs[sid]);
                    delete dialogs[sid];
                } else if (!noRemove) {
                    dialogsStore.remove(rec);
                }
            }
            dialogsStore.add(Object.keys(dialogs).map(function (sid) { return dialogs[sid]; }));

            sumPanel.update('Bindings: ' + bindingsStore.getCount() + ', dialogs: ' + dialogsStore.getCount());
        };

        // Catch update events
        this.client.setMessageHandler('users_update', (function (msg) {
            usersUpdate(msg.users, true);
        }).bind(this));

        this.client.setMessageHandler('sms', (function (msg) {
        }).bind(this));

        this.client.setMessageHandler('invite', (function (msg) {
        }).bind(this));

        // Update UE list
        this._updater = Ext.create("lte.updater", {
            scope:          this,
            updateDelay:    1000,
            dirty:          true,
            lock:           1,
            autoDelay:      1000,
            handler:        function () {
                this.client.sendMessage({message: 'users'}, function (msg) {
                    usersUpdate(msg.users);
                });
            }
        });

        var sumPanel = Ext.create('Ext.panel.Panel', {
            border: 0,
            html: 'Bindings: 0, dialogs: 0'
        });

        var bindingsStore = Ext.create('Ext.data.Store', {
            fields: ['uri', 'imeisv', 'sms', 'impi', 'impu']
        });

        var bindingsGrid = Ext.create('Ext.grid.Panel', {
            store: bindingsStore,
            tbar: [ sumPanel ],
            selModel: {
                mode: "MULTI"
            },
            viewConfig:{
                markDirty: false
            },
            columns: [{
                xtype: 'actioncolumn',
                width: 60,
                text: '',
                dataIndex: 'uri',
                items: [{
                    scope: this,
                    iconCls: 'icon-file',
                    tooltip: lteLogs.tooltip('Send SMS'),
                    handler: function(view, rowIndex, colIndex, item, e, record) {
                        Ext.Msg.prompt('Send SMS', 'Please enter SMS:', function(btn, text) {
                            if (btn == 'ok') {
                                this.client.sendMessage({message: 'sms', text: text, impu: record.get('impu')[0]}, (function (r) {
                                }).bind(this));
                            }
                        }, this);
                    }
                }, {
                    scope: this,
                    iconCls: 'icon-ue',
                    tooltip: lteLogs.tooltip('MT Call'),
                    handler: function(view, rowIndex, colIndex, item, e, record) {
                        this.client.sendMessage({message: 'mt_call', contact: record.get('uri'), impu: record.get('impu')[0]}, (function (r) {
                            this._updater.update(true);
                        }).bind(this));
                    }
                }],
            }, {
                text: "Bindings",
                dataIndex: 'uri',
                flex: 1,
                renderer: function(uri, metaData, record, rowIndex, colIndex, store, view) {
                    return uri.replace(/</, "&lt;").replace(/>/, "&gt;");
                },
            }, {
                text: "IMPI",
                dataIndex: "impi",
                flex: 1,
            }, {
                text: "IMEISV",
                dataIndex: "imeisv",
                flex: 1,
            }],
            listeners: {
                scope: this,
                cellcontextmenu: function(myGrid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                }
            }
        });

        var dialogsStore = Ext.create('Ext.data.Store', {
            fields: ['state', 'type', 'from', 'to', 'session_id', 'remote_state']
        });

        var dialogsGrid = Ext.create('Ext.grid.Panel', {
            store: dialogsStore,
            selModel: {
                mode: "MULTI"
            },
            viewConfig:{
                markDirty: false
            },
            columns: [{
                xtype: 'actioncolumn',
                width: 30,
                text: '',
                dataIndex: 'state',
                items: [{
                    scope: this,
                    getClass: function (state, meta, rec, rowIndex, colIndex, store) {
                        switch (state) {
                        case 'start':
                            return 'icon-off';
                        case 'ringing':
                            return 'icon-dial';
                        }
                    },
                    getTip: function (state) {
                        switch (state) {
                        case 'start':
                            return 'Stop call';
                        case 'ringing':
                            return 'Answer call';
                        }
                        return '&nbsp;';
                    },
                    handler: function(view, rowIndex, colIndex, item, e, record) {
                        var sid = record.get('session_id');
                        var state = record.get('state');
                        switch (state) {
                        case 'start':
                            this.client.sendMessage({
                                message: 'dialog_stop',
                                session_id: sid,
                            }, (function (resp) {
                                this._updater.update(true);
                            }).bind(this));
                            break;
                        case 'ringing':
                            var from = record.get('from');
                            var to = record.get('from');
                            Ext.Msg.prompt('Answer call on ' + this.client.getName(), ['From ' + from, 'To: ' + to, 'Enter response code:'].join('<br/>'), function (btn, text) {
                                if (btn !== 'ok') return;

                                var code = text - 0;
                                if (isNaN(code)) {
                                    Ext.Msg.alert('Error', 'Invalid code');
                                    return;
                                }

                                this.client.sendMessage({
                                    message: 'dialog_set',
                                    action: 'answer',
                                    code: code,
                                    session_id: sid,
                                }, function (resp) {
                                }, (function (error) {
                                    Ext.Msg.alert('Error', '' + error);
                                }).bind(this));
                            }, this, false, '200');
                            break;
                        }
                    }
                }]
            },{
                text: 'ID',
                dataIndex: 'session_id',
                flex: 1,
            }, {
                text: 'Type',
                dataIndex: 'type',
                flex: 1,
            }, {
                text: 'State',
                dataIndex: 'state',
                flex: 1,
            }, {
                text: 'From',
                dataIndex: 'from',
                flex: 1,
            }, {
                text: 'To',
                dataIndex: 'to',
                flex: 1,
            }],
        });

        this.add({
            region: 'west',
            layout: 'border',
            width: 700,
            items: [{
                region: 'center',
                layout: 'fit',
                flex: 1,
                items: [bindingsGrid]
            }, {
                region: 'south',
                layout: 'fit',
                flex: 1,
                items: [dialogsGrid]
            }]
        });
        this.add({
            split: true,
            layout: 'fit',
            region: 'center',
            items: [this.getChartPanel()],
        });
    },

    _eventListener: function (event) {
        switch (event.type) {
        case 'stats':
            var now = new Date() * 1;
            this._updateCounters(now, event.data.counters);
            this._updater.update(true);
            break;
        }
    },
});



