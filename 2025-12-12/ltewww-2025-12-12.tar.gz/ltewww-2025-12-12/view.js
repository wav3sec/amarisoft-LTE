const fNAN = -300;

Ext.define("lte.view.tab", {

    extend: 'lte.client.tab',
    layout: 'fit',
    activated: false,
    topToolbarCount: 0,
    drawCount: 0,

    _forceDemod: false,
    _chartList: [],

    constructor: function (config) {
        this._fps = {
            max: config.fps ? config.fps : 20,
            count: 0,
            debug: 0,
        };

        this.callParent(arguments);
    },

    _eventListener: function (event) {
        switch (event.type) {
        case 'deactivate':
            this.activated = false;
            this.animSet(false);
            break;
        case 'activate':
            this.activated = true;
            this.animSet(true);
            break;
        case 'stats':
            var msg = event.data;
            var demod = msg.demod;

            var data = [];

            msg.samples.forEach( (s, i) => {
                if (s.power) {
                    data.push({
                        title: 'Power #' + i,
                        text: s.power + ' dB',
                    }, {
                        title: 'Power max #' + i,
                        text: s.max_power + ' dBFS',
                        type: 'sat',
                        value: s.max_power,
                    });
                }
            });

            data.push({
                title: 'CenterFreq',
                text: (Math.round(this.frequency / 1e4) / 100).toFixed(2) + ' MHz',
            });
            data.push({
                title: 'SampleRate',
                text: (Math.round(this.sample_rate / 1e4) / 100).toFixed(2) + ' MHz',
            });

            if (msg.fft_len) {
                data.push({
                    title: 'RBW',
                    text: Math.round(this.sample_rate / (msg.fft_len * 1000)).toFixed(0) + ' kHz',
                });
            }
            if (demod) {
                this.demod_channel = demod.demod_channel;
                if (this.demod_channel >= 0)
                    this.channelButton.setDisabled(false);
                else
                    this.channelButton.setDisabled(true);
            } else {
                this.demod_channel = -1;
                this.channelButton.setDisabled(true);
            }
                 
            if (demod.locked) {
                var title = 'Locked on ' + demod.type.toUpperCase() + ' cell ' + demod.n_id_cell;
                if (this.demod_channel >= 0)
                    title = title + ' (Ch' + this.demod_channel + ')';
                this.demodGrid.setTitle(title);

                var dataAdd = (type, title, unit) => {
                    var sd;
                    var value;
                    var text;
                        
                    if (type === 'evm') {
                        value = demod['mer'];
                        sd = undefined;
                        if (value != undefined) {
                            value = this.mer_to_evm(demod['mer'], 'mean');
                        }
                    }
                    else {
                        value = demod[type];
                        sd = demod[type + '_sd'];
                    }
                    if (value !== undefined) {
                        text = '<b>' + value.toFixed(1) + '</b> ' + unit;
                        if (sd !== undefined)
                            text += ' ± ' + sd.toFixed(1);
                        data.push({
                            title: title,
                            text: text,
                            type: type,
                            value: value,
                        });
                    }
                };

                dataAdd('freq_shift', 'Frequency shift', 'Hz');
                dataAdd('sr_offset', 'Sample rate offset', 'ppm');
                switch (demod.type) {
                case 'lte':
                    dataAdd('snr', 'RS-SNR', 'dB');
                    dataAdd('rsrp', 'RSRP', 'dBm');
                    break;
                case 'nr':
                    dataAdd('snr', 'SS-SNR', 'dB');
                    dataAdd('rsrp', 'SS-EPRE', 'dBm');
                    break;
                case 'nb':
                    dataAdd('snr', 'NRS-SNR', 'dB');
                    dataAdd('rsrp', 'RSRP', 'dBm');
                    dataAdd('operation_mode', 'Mode', '');
                    break;
                }
                dataAdd('mer', 'PDSCH MER', 'dB');
                dataAdd('evm', 'PDSCH EVM', '%');

            } else {
                var title = 'Unlocked';
                if (this.demod_channel >= 0)
                    title = title + ' (Ch' + this.demod_channel + ')';
                this.demodGrid.setTitle(title);
            }
            this.demodStore.loadData(data);
            break;
        default:
            //this.callParent(arguments);
            break;
        }
    },

    statsPrepare: function (msg) {
        if (this.activated) {
            msg.demod = this._forceDemod;
            var plots = this.getVisiblePlots();
            for (var i = 0; i < plots.length; i++) {
                if (plots[i].demod) {
                    msg.demod = true;
                    break;
                }
            }
            msg.samples = true;
        }
    },

    initComponent: function () {

        this.myTbar = Ext.create({
            xtype: 'toolbar',
            dock: 'top',
            items: []
        });

        this.callParent(arguments);

        this.addRFConfig();

        this.frameDuration = Math.ceil(1000 / this._fps.max);

        var canvasPanel = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            region: 'center',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {
                    var canvas = canvasPanel.el.down("canvas").dom;
                    if (this._canvas !== canvas) {
                        this._canvas = canvas;
                        canvas.addEventListener('mouseout', this._mouseOutEvent.bind(this), false);
                        canvas.addEventListener('mousedown', this._mouseDownEvent.bind(this), false);
                        canvas.addEventListener('mousemove', this._mouseMoveEventFree.bind(this), false);
                        canvas.addEventListener('contextmenu', this._mouseContextMenuEvent.bind(this), false);
                    }
                    lteLogs.setCanvasSize(canvas, width, height);
                    this.redraw();
                }
            }
        });

        this._fps.time = new Date() * 1;

        this._mouse = { mode: 'select' };
        this._mouseReset();

        this._curPlot = null;
        this._fsPlot = null;

        this.screenshotButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-screenshot',
            tooltip: lteLogs.tooltip("Save to image..."),
            disabled: true,
            scope: this,
            handler: () => {

                Ext.Msg.prompt('Save image', 'Filename:', (btn, text) => {
                    if (btn !== 'ok')
                        return;

                    this._canvas.toBlob( (blob) => {
                        var a = document.createElement('a');
                        var url = URL.createObjectURL(blob);
                        a.setAttribute('href', url);
                        a.setAttribute("download", lteLogs.fixFilename(text));
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                    });
                }, this, false, 'lteview-' + lteLogs.fixFilename(this.client.getName()) + '.png');
            }
        });

        this.rescaleAllButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-rescale',
            disabled: true,
            tooltip: lteLogs.tooltip("Rescale all views"),
            scope: this,
            handler: () => {
                this._plots.forEach( (p) => { this.plotRescale(p); });
            }
        });

        this._plots = [];

        // View (plots)
        this.createButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-plus',
            tooltip: lteLogs.tooltip("Add view"),
            scope: this,
            handler: () => {
                lteLogs.popup('lte.view.plot.create', {
                    callback: (plot) => {
                        if (plot)
                            this.plotCreate(plot);
                            this.plotSave();
                        },
                    rxChannelCount: this.rxChannels.length,
                });
            }
        });

        this.deleteButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-minus',
            tooltip: lteLogs.tooltip("Remove view"),
            scope: this,
            disabled: true,
            handler: () => {
                var rec = this.viewGrid.getSelection();
                if (rec.length) {
                    rec = rec.shift();
                    var plot = rec.get('plot');
                    this.viewStore.remove(rec);
                    this.plotDelete(plot);
                }
            }
        });

        this.channelButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-air',
            tooltip: lteLogs.tooltip("Switch Demod Channel"),
            scope: this,
            disabled: true,
            handler: () => {
                this.client.sendMessage({ message: 'switch_channel'});
            }
        });

        this.forceDemodButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-unlock',
            tooltip: lteLogs.tooltip("Lock demod"),
            scope: this,
            hidden: true,
            handler: () => {
                if (this._forceDemod) {
                    this._forceDemod = false;
                    this.forceDemodButton.setIconCls('icon-unlock');
                    this.forceDemodButton.setTooltip('Lock demod');
                } else {
                    this._forceDemod = true;
                    this.forceDemodButton.setIconCls('icon-lock');
                    this.forceDemodButton.setTooltip('Unlock demod');
                }
            }
        });

        this.viewStore = Ext.create('Ext.data.Store', {
            fields: ['title', 'plot', 'enabled'],
            sortOnLoad: true,
            sorters: [{
                scope: this,
                sorterFn: (rec1, rec2) => {
                    var p1 = rec1.get('plot');
                    var i1 = this._plots.indexOf(p1);
                    var p2 = rec2.get('plot');
                    var i2 = this._plots.indexOf(p2);
                    return i1 - i2;
                },
            }],
            listeners: {
                scope: this,
                update: function (me, record) {
                    var enabled = record.get('enabled');
                    var plot = record.get('plot');
                    if (plot.enabled !== enabled) {
                        plot.enabled = enabled;
                        this.redraw();
                    }
                }
            }
        });

        this.viewGrid = Ext.create('Ext.grid.Panel', {
            store: this.viewStore,
            title: 'Views',
            hideHeaders: true,
            viewConfig: { markDirty: false },
            layout: 'fit',
            width: '100%',
            allowDeselect: true,
            tbar: {
                items: [
                    this.createButton, this.deleteButton, this.channelButton, this.forceDemodButton,
                ],
            },
            columns: {
                items: [{
                    dataIndex: 'title',
                    flex: 1,
                }, {
                    dataIndex: 'enabled',
                    xtype: 'checkcolumn',
                    width: 40,
                }]
            },
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {
                    var plot = selected.length ? selected[0].get('plot') : null;
                    this.setCurPlot1(plot);
                },
                cellclick: function (view, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                },
            },
        });

        // Demod
        this.demodStore = Ext.create('Ext.data.Store', {
            fields: ['param', 'value', 'type', 'value']
        });

        this.demodGrid = Ext.create('Ext.grid.Panel', {
            store: this.demodStore,
            title: 'Demod',
            hideHeaders: true,
            viewConfig: { markDirty: false },
            layout: 'fit',
            width: '100%',
            columns: {
                items: [{
                    dataIndex: 'title',
                    flex: 1,
                }, {
                    dataIndex: 'text',
                    flex: 1,
                    scope: this,
                    renderer: function (text, metaData, record) {
                        var color;

                        switch (record.get('type')) {
                        case 'sat':
                            var value = record.get('value');
                            if (value >= 0)     color = 'red';
                            else if (value >= -4) color = 'orange';
                            break;
                        case 'freq_shift':
                            var value = record.get('value');
                            var ppm = Math.abs(value / this.frequency * 1e6);
                            if (ppm >= 1)     color = 'red';
                            else if (ppm >= 0.5) color = 'orange';
                            break;
                        case 'sr_offset':
                            var ppm = Math.abs(record.get('value'));
                            if (ppm >= 1)     color = 'red';
                            else if (ppm >= 0.5) color = 'orange';
                            break;
                        default:
                            break;
                        }
                        if (color)
                            metaData.style = 'background-color: ' + color + '; font-weight: bold;';
                        return text;
                    },
                }],
            },
        });


        this.rescaleButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-rescale',
            disabled: true,
            tooltip: lteLogs.tooltip("Rescale"),
            scope: this,
            handler: () => {
                this.plotRescale(this._curPlot);
            }
        });

        this.fullscreenButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-fullscreen',
            disabled: true,
            tooltip: lteLogs.tooltip("Extend"),
            scope: this,
            handler: () => {
                if (this._fsPlot)
                    this._fsPlot = null;
                else
                    this._fsPlot = this._curPlot;
                this.redraw();
            }
        });

        this.pauseButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-play',
            tooltip: lteLogs.tooltip("Play/Pause"),
            disabled: true,
            scope: this,
            handler: () => {
                var plot = this._curPlot;
                if (plot.pause) {
                    var data = plot.pause;
                    plot.pause = false;
                    if (data !== true)
                        this.plotSetData(plot, data);
                } else {
                    plot.pause = true;
                }
                this._updateButtons();
            }
        });

        this.markerButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-pen',
            tooltip: lteLogs.tooltip("Add Marker"),
            disabled:  true,
            scope: this,
            enableToggle: true,
            toggleGroup: 'mode',
            toggleHandler: (b, state) => {
                if (state) {
                    this._mouseSetMode('marker');
                }
            }            
        });        

        this.clearButton = new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-refresh',
            tooltip: lteLogs.tooltip("Clear Markers"),
            disabled: true,
            scope: this,
            handler: () => {
                this.clearMarkers(this._curPlot);
            }
        });

        this.moveButton = this._createMouseModeButton('move', 'Move');
        this.selectButton = this._createMouseModeButton('select', 'Select plot');
        this.areaButton = this._createMouseModeButton('area', 'Select area');

        this.myTbar.add(
            this.screenshotButton, this.rescaleAllButton,
        );

        this.leftPanel = Ext.create('Ext.panel.Panel', {
            region: 'west',
            width: 240,
            split: true,
            collapsible: true,
            collapsed: false,
            header: false,
            layout: 'vbox',
            border: false,
            tbar: this.myTbar,
            items: [this.viewGrid, this.demodGrid]
        });

        this.bbarPanel = Ext.create('Ext.panel.Panel', {
            region: 'north',
            tbar: [
                this.pauseButton,
                this.rescaleButton,
                this.fullscreenButton,
                this.selectButton,
                this.areaButton,
                this.moveButton,
                this.markerButton,
                this.clearButton,
            ],
            collapsible: false,
        });

        this.rightPanel = Ext.create('Ext.panel.Panel', {
            layout: 'border',
            region: 'center',
            border: 0,
            items: [this.bbarPanel, canvasPanel]
        });

        this.add({
            layout: 'border',
            items: [this.leftPanel, this.rightPanel],
        });
    },

    setClientConfig: function (config) {

        this.setClientConfigRF(config);
        this.sample_rate = config.sample_rate;
        this.frequency = config.frequency;
        this.mod = config.codeword[0].mod;

        this.plotLoad();
        this._updateButtons();
    },

    _createMouseModeButton: function (mode, tooltip) {

        return new Ext.create('Ext.Button', {
            scope: this,
            iconCls: 'icon-' + mode,
            tooltip: lteLogs.tooltip(tooltip),
            scope: this,
            enableToggle: true,
            toggleGroup: 'mode',
            pressed: this._mouse.mode === mode,
            toggleHandler: (b, state) => {
                if (state) this._mouseSetMode(mode);
            }
        });
    },

    _animUpdating: false,
    _animCount: 0,
    _animTimer: 0,
    _animStarted: false,

    animSet: function (start) {
        this._animStarted = start;
        this._animPoll();
    },

    _animPoll: function () {
        
        if (this._animUpdating || this._closed)
            return;

        // Requested plots from remote lteview
        var plots = [];
        var plots0 = [];
        if (this._animStarted) {
            this._plots.forEach( (p, i) => {
                if (!p.enabled) return;

                switch (p.type) {
                case 'spectrum':
                    plots.push({ type: 'spectrum', mode: 'frequency', channel: p.channel });
                    break;
                case 'power':
                    plots.push({ type: 'spectrum', mode: 'time', channel: p.channel });
                    break;
                case 'waterfall':
                    plots.push({ type: 'waterfall', channel: p.channel });
                    break;
                case 'mer':
                case 'evm':
                    plots.push({ type: 'mer', mode: p.mode });
                    break;
                default:
                    plots.push({ type: p.type });
                    break;
                }
                plots0.push(p);
            });
        }

        
        // Send message ?
        if (plots.length || this._animCount > 0) {
            this._animUpdating = true;
            this.client.sendMessage({ message: 'plots', plots: plots }, (msg) => {

                (msg.plots || []).forEach( (p, i) => {
                    var plot = plots0[i];
                    if (p.error) {
                        plot.error = p.error;
                        return;
                    }
                    plot.error = null;
                    if (p.size === 0)
                        return;
                        
                    try {
                        this.plotSetData(plot, msg.__binary__.slice(p.offset, p.offset + p.size));
                    } catch (e) {
                        console.log('???', msg.__binary__, p.offset, p.size, e);
                        console.log(msg);
                    }
                });
                this.redraw();
                this._animUpdating = false;
                
                if (!this._animTimer)
                    this._animPoll();

                if (this._fps.debug) {
                    this._fps.count++;
                    var now = new Date() * 1;
                    var diff = now - this._fps.time;
                    if (diff >= this._fps.debug) {
                        console.log('FPS', Math.round(this._fps.count * 1000 / diff));
                        this._fps.count = 0;
                        this._fps.time = now;
                    }
                }

            }, (error) => {
                console.error('View error', error);
            });
        }
        this._animCount = plots.length;

        // Next
        this._animTimer = setTimeout( () => {
            this._animTimer = 0;
            this._animPoll();

        }, this.frameDuration);
    },

    _redrawPending: false,
    redraw: function () {
        if (!this._redrawPending) {
            this._redrawPending = true;
            window.requestAnimationFrame(this.drawFrame.bind(this));
        }
    },

    drawMargin: 12,
    rescaleCount: 20,
    qamDef: {
        'QPSK': { step: 1 / Math.sqrt(2), nb: 2, papr: 0 },
        '16QAM': { step: 1 / Math.sqrt(10), nb: 4, papr: 2.55 },
        '64QAM': { step: 1 / Math.sqrt(42), nb: 8, papr: 3.68 },
        '256QAM': { step: 1 / Math.sqrt(170), nb: 16, papr: 4.23 },
        '1024QAM': { step: 1 / Math.sqrt(682), nb: 32, papr: 4.51 },
    },

    getQamMax: function (mod) {

        var step = this.qamDef[mod].step;
        var nb = this.qamDef[mod].nb;
        return nb * step;
    },

    getQamPlot: function (p) {

        var step = this.qamDef[this.mod].step;
        var nb = this.qamDef[this.mod].nb;

        var coord = [];
        var h = nb / 2;
        for (var i = 0, d = 0; i <= h; i++, d += 2 * step) {
            coord[h - i] = {
                x: p.getX(-d) >> 0,
                y: p.getY(-d) >> 0,
            }
            if (i) {
                coord[h + i] = {
                    x: p.getX(d) >> 0,
                    y: p.getY(d) >> 0,
                }
            }
        }
        return coord;
    },

    getVisiblePlots: function () {

        if (this._fsPlot)
            return [this._fsPlot];

        return this._plots.filter( (p) => { return p.enabled && p.data; });
    },

    plotSetData: function (p, data) {

        if (p.pause) {
            p.pause = data;
            return;
        }

        switch (p.type) {
        case 'waterfall':
            var idata = new Uint32Array(data.slice(0,8));
            var slice_nb = idata[0];
            var fft_len = idata[1];

            var slice_len = 4 * fft_len;  /* data are float32 */
            /* skip two int32 at beginning */
            var pdata = new Float32Array(data.slice(8, 8 + (slice_nb * slice_len)));

            if (p.rescale === this.rescaleCount) {
                p.rect = Object.assign({}, p.rect0);
                p.ymin = Infinity;
                p.ymax = -Infinity;
            }
            
            var xmin = p.rect0.x0;
            var xmax = p.rect0.x1;
            var ymin = p.ymin;
            var ymax = p.ymax;

            var n = 0;
            for (var j = 0; j < slice_nb; j++) {
                for (var i = 0; i < fft_len; i++) {
                    var y = pdata[j*fft_len + i];
                    if (y <= fNAN)
                        pdata[j*fft_len + i] = NaN;
                    else {
                        n++;
                        if ((y+5) > ymax) ymax = y + 5;
                        if ((y-2) < ymin) ymin = y - 2;
                    }
                }
            }
            if (p.rescale > 0 && n > 0) {
                p.ymin = Math.floor(ymin / 10) * 10;
                p.ymax = Math.ceil(ymax / 10) * 10;
                p.rescale--;
            }
            
            p.slice_nb = slice_nb;
            p.fft_len = fft_len;
            p.data = pdata;
            break;
            
        case 'spectrum':
        case 'power':
        case 'mer':
        case 'evm':
            data = new Float32Array(data);

            if ((p.type === 'mer' || p.type === 'evm') && p.rect.x1 === 0) {
                p.n_carrier = data.length / 2;
                p.rect.x1 = p.rect0.x1 = p.n_carrier;
                p.bounds.x0 = 0;
                p.bounds.x1 = p.rect.x1;
            }

            if (p.rescale === this.rescaleCount) {
                p.rect = Object.assign({}, p.rect0);
            }

            var xmin = p.rect0.x0;
            var xmax = p.rect0.x1;
            var ymin = p.rect.y0;
            var ymax = p.rect.y1;

            var count = data.length;
            var n = 0;
            if (p.type === 'evm') {
                for (var i = 0; i < count; i++) {
                    var y = data[i];
                    if (y <= fNAN) {
                        data[i] = NaN;
                    } else {
                        data[i] = y = this.mer_to_evm(y, p.ref);
                        n++;
                        if (y > ymax) ymax = y;
                        if (y < ymin) ymin = y;
                    }
                }
            }
            else {
                for (var i = 0; i < count; i++) {
                    var y = data[i];
                    if (y <= fNAN) {
                        data[i] = NaN;
                    } else {
                        n++;
                        if (y > ymax) ymax = y;
                        if (y < ymin) ymin = y;
                    }
                }
            }
            if (p.rescale > 0 && n > 0) {
                if (p.type == 'evm') {
                    p.rect.y0 = Math.floor(ymin / 5) * 5;
                    p.rect.y1 = Math.ceil(ymax / 5) * 5;
                }
                else {
                    p.rect.y0 = Math.floor(ymin / 10) * 10;
                    p.rect.y1 = Math.ceil(ymax / 10) * 10;
                }
                p.rescale--;
            }
            p.data = data;
            break;
        case 'qam':
            data = new Float32Array(data);

            if (p.rescale > 0) {
                var rect = p.rescale === this.rescaleCount ? p.rect0 : p.rect;

                var xmin = rect.x0;
                var xmax = rect.x1;
                var ymin = rect.y0;
                var ymax = rect.y1;

                var count = data.length;
                for (var i = 0; i < count;) {
                    var x = data[i++];
                    if (x > xmax) xmax = x;
                    if (x < xmin) xmin = x;
                    var y = data[i++];
                    if (y > ymax) ymax = y;
                    if (y < ymin) ymin = y;
                }
                xmin = Math.max(xmin, p.bounds.x0);
                xmax = Math.min(xmax, p.bounds.x1);
                ymin = Math.max(ymin, p.bounds.y0);
                ymax = Math.min(ymax, p.bounds.y1);

                // XXX rounding
                p.rect.x0 = xmin;
                p.rect.x1 = xmax;
                p.rect.y0 = ymin;
                p.rect.y1 = ymax;
                p.rescale--;
            }
            p.data = data;
            break;
        }


    },

    plotSave: function () {
        this.client.setConfig('plots', this._plots.map( (p) => { return p.config; }), true);
    },

    plotLoad: function () {
        var plots = this.client.getConfig('plots');
        if (plots && plots instanceof Array) {
            plots.forEach( (p) => {
                this.plotCreate(p);
            });
        }
    },

    plotCreate: function (p) {
        
        p = Object.assign({}, p, {
            rect: {
                x0: 0,
                x1: 0,
                y0: Infinity,
                y1: -Infinity,
            },
            bounds: {
                x0: -Infinity,
                x1: Infinity,
                y0: -Infinity,
                y1: Infinity,
            },
            data: [],
            rescale: this.rescaleCount,
            getValueX: function (v) { return v; },
            getValueY: function (v) { return v; },
            config: p,
            ymain: Infinity,
            ymax: -Infinity,
            markers: [],
        });

        switch (p.type) {
        case 'spectrum':
            p.rect.x0 = this.frequency - this.sample_rate / 2;
            p.rect.x1 = this.frequency + this.sample_rate / 2;
            p.bounds.x0 = p.rect.x0;
            p.bounds.x1 = p.rect.x1;
            p.xscale = this.sample_rate;
            p.xorg = p.rect.x0;
            p.unit = 'MHz';

            p.getValueY = function (v) {
                if (isNaN(v))
                    return '?';
                return v.toFixed(1);
            };
            p.over = 'line';
            break;
        case 'power':
            p.rect.x0 = 0;
            p.rect.x1 = 10e3;
            p.bounds.x0 = p.rect.x0;
            p.bounds.x1 = p.rect.x1;
            p.xscale = p.rect.x1;
            p.xorg = p.rect.x0;
            p.getValueX = function (v) { return Math.round(v) / 1000; };
            p.unit = 'ms';

            p.getValueY = function (v) {
                if (isNaN(v))
                    return '?';
                return v.toFixed(1);
            };
            p.over = 'line';
            break;
        case 'waterfall':
            p.rect.x0 = this.frequency - this.sample_rate / 2;
            p.rect.x1 = this.frequency + this.sample_rate / 2;
            p.bounds.x0 = p.rect.x0;
            p.bounds.x1 = p.rect.x1;
            p.xscale = this.sample_rate;
            p.xorg = p.rect.x0;
            p.unit = 'MHz';
            
            p.rect.y0 = 0;
            p.rect.y1 = 10e3;
            p.bounds.y0 = p.rect.y0;
            p.bounds.x1 = p.rect.y1;
            
            p.getValueY = function (v) { return Math.round(v) / 1000; };
            p.vunit = 'ms';

            p.getValueX = function (v) {
                if (isNaN(v))
                    return '?';
                return v.toFixed(1);
            };
            p.over = 'line';
            break;
        case 'qam':
            var n = this.getQamMax(this.mod);

            p.rect.x0 = -n;
            p.rect.x1 = n;
            p.rect.y0 = -n;
            p.rect.y1 = n;
            p.bounds.x0 = -5;
            p.bounds.x1 = 5;
            p.bounds.y0 = -5;
            p.bounds.y1 = 5;
            p.getValueX = p.getValueY = function (v) { return v.toFixed(2); };
            p.demod = true;
            break;
        case 'mer':
            p.over = 'line';
            p.n_carrier = 0;
            p.rect.y0 = 0;
            p.getValueY = function (v) { return v.toFixed(1); };
            p.demod = true;
            break;
        case 'evm':
            p.over = 'line';
            p.n_carrier = 0;
            p.getValueY = function (v) { return v.toFixed(1); };
            p.demod = true;
            break;
        }
        p.rect0 = Object.assign({}, p.rect); // Copy

        this._plots.push(p);

        this.viewStore.add({ plot: p, title: p.config.title, enabled: p.enabled });
        this.setCurPlot1(p);

        this._updateForceDemodButton();
    },

    plotDelete: function (plot) {

        var index = this._plots.indexOf(plot);
        if (index >= 0) {
            this._plots.splice(index, 1);
            this.plotSave();

            if (plot === this._fsPlot) {
                this._fsPlot = null;
                this.redraw();
            }
            if (plot === this._curPlot) {
                this._mouseReset();
                this.setCurPlot(null);
            }
            this._updateForceDemodButton();
        }
    },

    setCurPlot: function (p) {
        if (this.setCurPlot1(p)) {
            var idx = this._plots.indexOf(p);
            this.viewGrid.setSelection(idx >= 0 ? idx : null);
        }
    },

    setCurPlot1: function (p) {
        if (p !== this._curPlot) {
            if (this._curPlot === this._fsPlot && this._fsPlot)
                this._fsPlot = p;
            this._curPlot = p;
            this._updateButtons();
            this.redraw();
            return true;
        }
        return false;
    },

    plotRescale: function (plot) {
        var rect = this._mouse.area;
        if (rect) {
            plot.rect = rect;
            this._mouse.area = null;
        } else {
            plot.rescale = this.rescaleCount;
        }
    },

    min_max: function (x, a, b) {
        if (x < a)
            return a;
        if (x > b)
            return b;
        return x;
    },
    
    build_colortab: function (p, color_bits) {
        var bits = color_bits & 0x0F;
        var mask = (0xFF >> (8 - bits)) << (8 - bits);
        var addend = 1 << (8 - bits);
        var res = 0;
        var last_im = -1;
        var val = 0;
        var xc = 0;

        var xc_tab = [];
        for (var i = 0; i < 256; i++) {
            if ((i & mask) != last_im) {
                last_im = i & mask;
                res++;
                val = last_im + ((addend - 1) * i  / mask);
                xc = val.toFixed(0);
            }
            xc_tab[i] = xc;
        }
        return xc_tab;
    },

    set_ctx_fillStyle: function (ctx, p, db, xc_tab) {

        var db_min = p.ymin;
        var db_max = p.ymax;
        var db_mid = (db_min + db_max) / 2;

        db = this.min_max(db, db_min, db_max);
        
        var alpha = (255 * (db - db_min) / (db_max - db_min));
        alpha = this.min_max(alpha, 0, 255);

        var r = 0;
        var g = 0;
        var b = 0;
        if (alpha < 64)    /* from Dark blue to Blue */
            b = 3 * (alpha + 21);
        else if (alpha < 96) {  /* from Blue to Cyan */
            b = 255;
            g = 8 * (alpha - 64);
        }
        else if (alpha < 128) {  /* from Cyan to White */
            b = 255;
            g = 255;
            r = 8 * (alpha - 96);
        }
        else if (alpha < 160) {  /* from White to Yellow */
            r = 255;
            g = 255;
            b = 8 * (160 - alpha);
        }
        else if (alpha < 192) {  /* from Yellow to Red */
            r = 255;
            b = 0;
            g = 8 * (192 - alpha);
        }
        else {    /* from Red to Dark Red */
            b = 0;
            g = 0;
            r = 3 * (277 - alpha);
        }
        r = this.min_max(r, 0, 255);
        g = this.min_max(g, 0, 255);
        b = this.min_max(b, 0, 255);

        r = Math.floor(r);
        g = Math.floor(g);
        b = Math.floor(b);
        
        r = p.xc_tab[r];
        g = p.xc_tab[g];
        b = p.xc_tab[b];

        ctx.fillStyle = "rgb(" + r + " " + g + " " + b + ")";
    },

    mer_to_evm: function (mer, ref) {
        if (ref == 'max')
            mer += this.qamDef[this.mod].papr;
        var evm = 100 * Math.pow(10, -(mer / 20));
        return this.min_max(evm, 0, 100);
    },
    
    addMarker: function (plot, x) {
        var mk = {
            _plot: plot,
            _x: x,
            _drag: this._mouse.drag,
            _y: 0,
        };
        plot.markers.push(mk);
        plot.last_marker_time = new Date() * 1;
        this.redraw();        
    },

    clearMarkers: function (plot) {
        plot.markers = [];
        this.redraw();
    },

    drawPlot: function (ctx, p, rect) {

        var width = rect.w;
        var height = rect.h;

        ctx.save(); // Main
        ctx.translate(rect.x, rect.y);
        ctx.beginPath();
        ctx.rect(0, 0, width, height);
        ctx.clip();

        p.x0 = rect.x;
        p.x1 = rect.x + width;
        p.y0 = rect.y;
        p.y1 = rect.y + height;
        p.drawCount = this.drawCount;

        // Error
        if (p.error) {
            p.px = p.py = p.pw = p.ph = 0;
            ctx.strokeStyle = '#00FF00';
            ctx.stroke();

            var fontSize = 20;
            ctx.font = 'bold ' + fontSize + 'px helvetica';
            ctx.fillStyle = '#FFFFFF';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(p.title, width / 2, height / 2 - fontSize);
            ctx.fillText(p.error, width / 2, height / 2 + fontSize);
            ctx.restore(); // Main
            p.ctx_lock = false;
            return;
        }

        ctx.translate(this.drawMargin, this.drawMargin);
        width -= this.drawMargin * 2;
        height -= this.drawMargin * 2;

        var rect = p.rect;

        // Axis dimensions
        switch (p.type) {
        case 'qam':
            var yw = 0;
            var sw = 0;
            var xh = 0;
            var th = 15;
            break;
        case 'waterfall':
            var yw = 20;
            var sw = 50;
            var xh = 20;
            var th = 0;
            break;
        default:
            var yw = 20;
            var xh = 20;
            var sw = 0;
            var th = 0;
            break;
        }
        width -= yw + sw;
        height -= xh + th;
        ctx.translate(yw, th);

        // Plot area
        p.px = yw + this.drawMargin;
        p.py = this.drawMargin;
        p.pw = width;
        p.ph = height;

        // Value to coordinate
        var getY = p.getY = function (y) { return height - (y - rect.y0) * height / (rect.y1 - rect.y0); };
        var getX = p.getX = function (x) { return (x - rect.x0) * width / (rect.x1 - rect.x0); };

        ctx.font = "bold 12px helvetica";
        
        if (p.type == 'waterfall') {
            /* draw color scale on right side */
            p.xc_tab = this.build_colortab(p, 6);   /* 6 bits => 64 different colors */

            var nstep = 64;
            var x0 = width + 5;
            var cw = 20;
            var ch = ((height + 32) / nstep) + 1;
            for (var i = 0; i < nstep; i++) {
                var y0 = (i * height) / nstep;
                var data = Math.round(p.ymax - i * (p.ymax - p.ymin) / nstep);
                this.set_ctx_fillStyle(ctx, p, data);
                ctx.fillRect(x0, y0, cw, ch);
            }
            
            // Frame color bar
            ctx.strokeStyle = '#00FF00';
            ctx.fillStyle = '#00FF00';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.beginPath();
            ctx.moveTo(x0, 0);
            ctx.lineTo(x0+cw, 0);
            ctx.lineTo(x0+cw, height);
            ctx.lineTo(x0, height);
            ctx.lineTo(x0, 0);
            ctx.stroke();
            
            // Draw Color Scale Values
            ctx.beginPath();
            var x0 = width + 5;
            var x1 = width + sw;
            var pstep = 10;
            var p0 = Math.ceil(p.ymin / pstep) * pstep;
            for (var pw = p0; pw <= p.ymax; pw += pstep) {
                var y0 = height - (pw - p.ymin) * height / (p.ymax - p.ymin);

                ctx.fillText(pw, x1, y0);
                ctx.moveTo(x0, y0);
                ctx.lineTo(x0+5, y0);
                ctx.moveTo(x0+15, y0);
                ctx.lineTo(x0+20, y0);
            }
            ctx.stroke();
        }
        
        // Draw Axis
        ctx.fillStyle = '#00FF00';
        ctx.strokeStyle = '#004000';

        switch (p.type) {
        case 'waterfall':
        case 'spectrum':
        case 'power':
        case 'mer':
        case 'evm':
            var ystep = 10;
            if (p.type === 'evm')
                ystep = 2;

            var nb = Math.ceil(width / 100); // Every 100px
            var xstep = (rect.x1 - rect.x0) / nb;
            var k = Math.floor(Math.log10(xstep));
            var n = Math.ceil(xstep / Math.pow(10, k));
            if (n > 5)
                n = 5;
            else if (n > 2)
                n = 2;
            xstep = n * Math.pow(10, k);
            p.fix = Math.max(1, 6 - k);
            
            if (p.type === 'spectrum' || p.type === 'waterfall') {
                p.getValueX = function (v) { return (v / 1e6).toFixed(p.fix); }
            }

            // Y axis
            nb = Math.ceil(height / 150);
            var ystep = (rect.y1 - rect.y0) / nb;
            k = Math.floor(Math.log10(ystep));
            n = Math.round(ystep / Math.pow(10, k));
            if (n > 5)
                n = 5;
            else if (n > 2)
                n = 2;
            ystep = n * Math.pow(10, k);
            
            ctx.beginPath();
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            if (p.type === 'waterfall')
                ystep = 1000;
            var y0 = Math.ceil(rect.y0 / ystep) * ystep;
            for (var y = y0; y <= rect.y1; y += ystep) {
                var y1 = getY(y);
                ctx.fillText(p.getValueY(y), -2, y1);
                ctx.moveTo(0, y1);
                ctx.lineTo(width, y1);
            }
            ctx.stroke();

            // X axis
            ctx.beginPath();
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            var x0 = Math.ceil(rect.x0 / xstep) * xstep;
            for (var x = x0; x <= rect.x1; x += xstep) {
                var X = getX(x);
                ctx.fillText(p.getValueX(x), X, height + (xh >> 1));
                ctx.moveTo(X, 0);
                ctx.lineTo(X, height);
            }
            ctx.stroke();

            ctx.strokeStyle = '#00FF00';
            ctx.beginPath();
            ctx.rect(0, 0, width, height);
            ctx.stroke();
            ctx.clip();
            break;

        case 'qam':
            ctx.strokeStyle = '#004000';

            var coord = this.getQamPlot(p);
            var x0 = coord[0].x;
            var y0 = coord[0].y;
            var x1 = coord[coord.length - 1].x;
            var y1 = coord[coord.length - 1].y;

            coord.forEach( (point) => {

                ctx.beginPath();
                ctx.moveTo(x0, point.y);
                ctx.lineTo(x1, point.y);
                ctx.stroke();

                ctx.beginPath();
                ctx.moveTo(point.x, y0);
                ctx.lineTo(point.x, y1);
                ctx.stroke();
            });
            break;
        }

        // Draw Data
        
        var data = p.data;
        switch (p.type) {
        case 'waterfall':
            var count = p.fft_len; 
            var slice_height = (rect.y1 - rect.y0) / p.slice_nb;
            var slot_width = p.xscale / count;


            var y0 = Math.floor(getY(0));
            for (var sl = 0; sl < p.slice_nb; sl++) {
                /* fillrect takes top y coord */
                var sdata = p.data.slice(sl * count, (sl + 1) * count);
                var y1 = getY(((sl+1) * slice_height));
                y1 = Math.floor(y1);
                var sh = y0 - y1 + 1;
                for (var i = 0; i < count; i++) {
                    var x0 = getX(p.xorg + (i * p.xscale) / count);

                    this.set_ctx_fillStyle(ctx, p, sdata[i]);
                    ctx.fillRect(x0, y1, slot_width, sh);
                }
                y0 = y1;
            }
            break;
        case 'spectrum':
        case 'power':
            var count = data.length / 2;

            /* draw Max */
            ctx.beginPath();
            ctx.strokeStyle = '#808000';
            for (var i = 0; i < count; i++) {
                var x = getX(p.xorg + i * p.xscale / count);
                var y = getY(data[i * 2 + 1]);
                if (i == 0)
                    ctx.moveTo(x, y);
                else
                    ctx.lineTo(x, y);
            }
            ctx.stroke();

            /* draw Val */
            ctx.beginPath();
            ctx.strokeStyle = 'yellow';
            for (var i = 0; i < count; i++) {
                var x = getX(p.xorg + i * p.xscale / count);
                var y = data[i * 2];
                if (!isNaN(y)) {
                    y = getY(y);
                } else {
                    y = height;
                }
                if (i == 0)
                    ctx.moveTo(x, y);
                else
                    ctx.lineTo(x, y);
            }
            ctx.stroke();
            break;
        case 'qam':
            var count = data.length;
            ctx.beginPath();
            ctx.strokeStyle = 'yellow';
            for (var i = 0; i < count;) {
                var x = getX(data[i++]);
                var y = getY(data[i++]);
                ctx.moveTo(x, y);
                ctx.lineTo(x + 1, y + 1);
            }
            ctx.stroke();
            break;
        case 'mer':
        case 'evm':
            var count = data.length / 2;
            /* Max MER => min EVM */
            ctx.beginPath();
            ctx.strokeStyle = '#808000';
            for (var i = 0; i < count; i++) {
                var x = i * width / count;
                var y = data[i * 2 + 1];
                if (!isNaN(y)) {
                    y = getY(y);
                    ctx.moveTo(x, y);
                    ctx.lineTo(x + 1, y + 1);
                }
            }
            ctx.stroke();

            ctx.beginPath();
            ctx.strokeStyle = 'yellow';
            for (var i = 0; i < count; i++) {
                var x = i * width / count;
                var y = data[i * 2];
                if (!isNaN(y)) {
                    y = getY(y);
                    ctx.moveTo(x, y);
                    ctx.lineTo(x + 1, y + 1);
                }
            }
            ctx.stroke();
            break;
        }

        //draw markers

        var fontSize = 10;
        ctx.font = 'bold ' + fontSize + 'px helvetica';
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';

        /* Update markers every 200ms */
        var now = new Date() * 1;
        var check_markers = ((now - p.last_marker_time) > 200)? true: false;
        if (check_markers)
            p.last_marker_time = now;

        switch (p.type) {
        case 'spectrum':
            var ty = 15;
            var last_mk = null;
            var count = data.length / 2;
            var rect0 = p.rect0;
            p.markers.forEach((mk, i) => {
                var vx = mk._x * 1e6;
                if (check_markers) {
                    /* recompute Value */
                    if (vx >= p.rect.x0 && vx <= p.rect.x1) {
                        var j = (vx - rect0.x0) * (count - 1) / (rect0.x1 - rect0.x0);
                        var j0 = Math.floor(j);
                        var j1 = Math.ceil(j);
                        var vy = (j - j0) * (data[j1 * 2] - data[j0 * 2]) + data[j0 * 2];
                        mk._y = vy;
                    }
                }
                /* Show Marker value */
                ctx.fillText('Mk' + (i + 1) + ': ' + p.getValueY(mk._y) + 'dB @ '+ mk._x + 'MHz' , width - 150, ty);
                ty += 15;
                if (mk._drag && last_mk) {
                    /* Show differential markers */
                    ctx.fillText('Mk' + (i + 1) + '-Mk' + i + ': ' +
                                 p.getValueY(mk._y - last_mk._y) + 'dB @ '+
                                 (mk._x - last_mk._x).toFixed(p.k) + 'MHz' ,
                                 width - 170, ty);
                    ty += 15;
                }
                last_mk = mk;

                if (vx >= p.rect.x0 && vx <= p.rect.x1
                    && mk._y >= p.rect.y0 && mk._y <= p.rect.y1) {
                    /* Show Arrow */
                    var mx = getX(vx);
                    var my = getY(mk._y);

                    ctx.fillStyle = '#FFFFFF';                    
                    ctx.beginPath();
                    ctx.moveTo(mx, my);
                    ctx.lineTo(mx-8, my - 8);
                    ctx.lineTo(mx+8, my - 8);
                    ctx.fill();
                    
                    ctx.fillText('Mk' + (i + 1), mx + 10, my - 15);
                }
                
                });
            break;
        case 'power':
            var ty = 15;
            var last_mk = null;
            var count = data.length / 2;
            var rect0 = p.rect0;
            p.markers.forEach((mk, i) => {
                var vx = mk._x * 1000;
                if (check_markers) {
                    /* recompute Value */
                    var j = (vx - rect0.x0) * (count - 1) / (rect0.x1 - rect0.x0);                    
                    var j0 = Math.floor(j);
                    var j1 = Math.ceil(j);
                    var vy = (j - j0) * (data[j1 * 2] - data[j0 * 2]) + data[j0 * 2];
                    mk._y = vy;
                }
                /* Show Marker value */
                ctx.fillText('Mk' + (i + 1) + ': ' + p.getValueY(mk._y) + 'dB @ '+ mk._x + 'ms' , width - 150, ty);
                ty += 15;
                if (mk._drag && last_mk) {
                    /* Show differential markers */
                    ctx.fillText('Mk' + (i + 1) + '-Mk' + i + ': ' +
                                 p.getValueY(mk._y - last_mk._y) + 'dB @ '+
                                 (mk._x - last_mk._x).toFixed(3) + 'ms' ,
                                 width - 170, ty);
                    ty += 15;
                }

                /* Show Arrow */
                var mx = getX(mk._x * 1000);
                var my = getY(mk._y);

                ctx.fillStyle = '#FFFFFF';                    
                ctx.beginPath();
                ctx.moveTo(mx, my);
                ctx.lineTo(mx-8, my - 8);
                ctx.lineTo(mx+8, my - 8);
                ctx.fill();
                    
                ctx.fillText('Mk' + (i + 1), mx + 10, my - 15);                

                last_mk = mk;
                });
            break;
            
            break;
        }

        /* draw title / units */
        var fontSize = 10;
        ctx.font = 'bold ' + fontSize + 'px helvetica';
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        if (p.type == 'qam') {
            ctx.fillText(p.config.title + " " + this.mod, 10, 5 - th);
        }
        else {
            ctx.fillText(p.config.title, 10, 10);
        }
        var units = '';
        switch (p.type) {
        case 'spectrum':
            units = 'dBm versus MHz';
            break;
        case 'power':
            units = 'dBm versus ms';
            break;
        case 'waterfall':
            units = 'dBm (color) ms versus MHz';
            break;
        case 'mer':
            units = 'dB versus MHz';
            break;            
        case 'evm':
            units = '% versus MHz';
            break;
        }
        ctx.fillText(units, 10, 25);
        
        ctx.restore(); // Main
    },

    drawFrame: function () {

        this._redrawPending = false;

        if (this._closed || !this._canvas)
            return;

        this.drawCount++;

        var canvas = this._canvas;
        var width = canvas.width;
        var height = canvas.height;
        var ctx = canvas.getContext("2d");
        ctx.save(); // Main

        ctx.lineWidth = 1;
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, width, height);
        ctx.translate(0.5, 0.5);
        width--;
        height--;

        var plots = this.getVisiblePlots();

        var rect = this._computeArea(plots.length, width, height)
        plots.forEach( (p, i) => {
            this.drawPlot(ctx, p, rect[i]);
        });

        var plot = this._curPlot;
        if (plot && plot.enabled) {
            ctx.save(); // Cur plot
            ctx.translate(0.5, 0.5);
            ctx.strokeStyle = 'white';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.rect(plot.x0, plot.y0, plot.x1 - plot.x0 - 4, plot.y1 - plot.y0 - 4);
            ctx.stroke();
            ctx.restore(); // Cur plot
        }

        // Mouse handling
        var mouse = this._mouse;
        switch (mouse.mode) {
        case 'select':
            var pos1 = mouse.pos1;
            if (!pos1)
                break;

            var plot1 = pos1.plot;
            if (!plot1)
                break;

            ctx.save(); // Select
            if (mouse.select) {
                var plot0 = mouse.pos0.plot;

                var sw = plot0.x1 - plot0.x0;
                var sh = plot0.y1 - plot0.y0;
                var dw = 300;
                var dh = Math.round(dw * sh / sw) & ~1;
                var dx = plot1.x0 + plot1.px + pos1.px - dw / 2;
                var dy = plot1.y0 + plot1.py + pos1.py - dh / 2

                if (plot1 !== plot0) {
                    ctx.save();
                    ctx.beginPath();
                    ctx.fillStyle = 'white';
                    ctx.globalAlpha = 0.2;
                    ctx.rect(plot1.x0, plot1.y0, plot1.x1 - plot1.x0, plot1.y1 - plot1.y0);
                    ctx.fill();
                    ctx.restore();
                }

                ctx.drawImage(canvas, plot0.x0, plot0.y0, sw, sh, dx, dy, dw, dh);
                ctx.strokeStyle = 'white';
                ctx.beginPath();
                ctx.rect(dx , dy, dw, dh);
                ctx.stroke();

            } else if (plot1.over === 'line') {
                ctx.translate(plot1.x0 + plot1.px, plot1.y0 + plot1.py);
                ctx.beginPath();
                ctx.strokeStyle = '#808080';
                ctx.moveTo(pos1.px >> 0, 0);
                ctx.lineTo(pos1.px >> 0, plot1.ph);
                ctx.stroke();
            }
            ctx.restore(); // Select
            break;
        case 'marker':
            var pos1 = mouse.pos1;
            if (!pos1)
                break;

            var plot1 = pos1.plot;
            if (!plot1)
                break;

            ctx.save(); // Select
            if (plot1.over === 'line') {
                ctx.translate(plot1.x0 + plot1.px, plot1.y0 + plot1.py);
                ctx.beginPath();
                ctx.strokeStyle = '#FF4040';
                ctx.moveTo(pos1.px >> 0, 0);
                ctx.lineTo(pos1.px >> 0, plot1.ph);
                ctx.stroke();
            }
            ctx.restore(); // Select
            break;
        case 'area':
            var area = mouse.area;
            if (area) {
                ctx.strokeStyle = '#808080';
                ctx.fillStyle = '#C0C0C0';
                ctx.beginPath();
                ctx.rect(area.x, area.y, area.w, area.h);
                ctx.globalAlpha = 0.5;
                ctx.fill();
                ctx.globalAlpha = 1;
                ctx.stroke();
            }
            break;
        }

        ctx.restore(); // Main
    },

    _computeArea: function (n, w, h) {

        switch (n) {
        case 0:
            return [];
        case 1:
            return [{ x: 0, y: 0, w: w, h: h }];
        case 2:
            var h2 = h >> 1;
            return [{
                x: 0, y: 0, w: w, h: h2,
            }, {
                x: 0, y: h2, w: w, h: h2,
            }];
        case 3:
            var h2 = h >> 1;
            var w2 = w >> 1;
            return [{
                x: 0, y: 0, w: w, h: h2,
            }, {
                x: 0, y: h2, w: w2, h: h2,
            }, {
                x: w2, y: h2, w: w2, h: h2,
            }];
        case 4:
            var h2 = h >> 1;
            var w2 = w >> 1;
            return [{
                x: 0, y: 0, w: w2, h: h2,
            }, {
                x: w2, y: 0, w: w2, h: h2,
            }, {
                x: 0, y: h2, w: w2, h: h2,
            }, {
                x: w2, y: h2, w: w2, h: h2,
            }];
            break;
        default:
            var h3 = (h / 3) >> 0;
            var w3 = (w / 3) >> 0;
            var areas = [{
                x: 0, y: 0, w: w3, h: h3,
            }, {
                x: 0, y: h3, w: w3, h: h3,
            }, {
                x: 0, y: h3 * 2, w: w3, h: h3,
            }];

            var sub = this._computeArea(n - 3, w3 * 2, h);
            sub.forEach( (a) => { a.x += w3; });
            areas.push.apply(areas, sub);
            return areas;
        }
    },

    // Pixel to value
    _plotGetY: function (p, Y) {
        return p.rect.y1 - (Y - p.py) * (p.rect.y1 - p.rect.y0) / p.ph;
    },
    _plotGetX: function (p, X) {
        return p.rect.x0 + (X - p.px) * (p.rect.x1 - p.rect.x0) / p.pw;
    },

    _eventToPosition: function (event) {

        if (this._canvas) {
            var rect = this._canvas.getBoundingClientRect();
            var x = event.clientX - rect.left;
            var y = event.clientY - rect.top;

            for (var i = 0; i < this._plots.length; i++) {
                var p = this._plots[i];
                if (p.drawCount !== this.drawCount) continue;

                if (x < p.x0 || x >= p.x1 || y < p.y0 || y >= p.y1) continue;

                x -= p.x0;
                y -= p.y0;

                var px = x - p.px;
                var py = y - p.py;

                return {
                    plot: p,
                    // Canvas position
                    cx: event.clientX - rect.left,
                    cy: event.clientY - rect.top,
                    // Position in full area
                    x: x,
                    y: y,
                    // Position in plot area (no axis)
                    in: px >= 0 && px < p.pw && py >= 0 && py < p.ph,
                    px: px,
                    py: py,
                    ctrl: event.ctrlKey,
                    shift: event.shiftKey,
                    buttons: event.buttons,
                };
            }
        }
        return {
            plot: null,
            cx: event.clientX - rect.left,
            cy: event.clientY - rect.top,
            in: false,
            ctrl: event.ctrlKey,
            shift: event.shiftKey,
            buttons: event.buttons,
        };
    },


    _setTooltip: function (text, event) {
        if (text) {
            if (text instanceof Array)
                text = text.join('<br/>');

            if (!this._tooltip) {
                this._tooltip = Ext.create('Ext.tip.ToolTip', {
                    target: this._canvas,
                    trackMouse: false,
                    autoHide: false,
                    html: text,
                });
            } else {
                this._tooltip.update(text);
            }
            this._tooltip.show([event.clientX + 10, event.clientY + 10]);
        } else if (this._tooltip) {
            this._tooltip.hide();
        }
    },

    _mouseSetMode: function (mode) {

        var mouse = this._mouse;
        mouse.mode = mode;
        this._mouseReset();
    },

    _mouseReset: function () {

        var mouse = this._mouse;
        mouse.area = null;
        mouse.select = false;
        mouse.pos0 = null;
        mouse.pos1 = null;
        mouse.click = false;
    },

    _mouseOutEvent: function (event) {
        this._setTooltip(null, event);
    },

    _mouseDownEvent: function (event) {

        if (event.buttons === 2)
            return;

        var mouse = this._mouse;
        var pos = this._eventToPosition(event);
        if (pos.in) {
            mouse.rect0 = Object.assign({},  pos.plot.rect); // Store area
            mouse.click = true;
        }
        this._mouseReset();
        mouse.pos0 = pos;
        this.setCurPlot(pos.plot);

        event.preventDefault();

        if (mouse.mode === 'marker' && ! mouse.drag) {
            mouse.down_x = mouse.marker_x;
        }

        lteLogs.registerMouseMove( (event1) => {
            switch (event1.type) {
            case 'mouseup':
                if (mouse.mode === 'marker') {
                    this.addMarker(mouse.marker_plot, mouse.marker_x);
                }
                mouse.drag = false;
                this._setTooltip(null, event);                
                this._mouseUpEvent(event1);
                break;
            case 'mousemove':
                if (mouse.mode === 'marker') {
                    if (! mouse.drag) {
                        /* Store first marker and wait for mouse up */
                        this.addMarker(mouse.marker_plot, mouse.down_x);
                        mouse.drag = true;
                    }
                } else
                    this._mouseMoveEvent(event1);
                //event1.stopPropgation();
                break;
            }
        });
        this.redraw();
    },

    _mouseMoveEventFree: function (event) {

        var cursor = '';
        var ttip = null;
        var mouse = this._mouse;

        switch(event.buttons) {
        case 0:
            break;
        case 1:
            if (mouse.mode != 'marker')
                return;
            break;
        default:
            return;
        }
        
        mouse.pos1 = null;
        var pos1 = this._eventToPosition(event);
        var plot = pos1.plot;
        if (pos1.in) {
            var x = this._plotGetX(plot, pos1.x);
            var y = this._plotGetY(plot, pos1.y);

            var data = plot.data;
            var count = data.length;

            var rect = plot.rect;
            var rect0 = plot.rect0;

            switch (plot.type) {
            case 'waterfall':
                if (x < rect.x0 || x > rect.x1)
                    break;

                count = plot.fft_len;
                var slice_height = (rect.y1 - rect.y0) / plot.slice_nb;
                
                switch (mouse.mode) {
                case 'select':
                    var i = (x - rect0.x0) * (count - 1) / (rect0.x1 - rect0.x0);
                    var i0 = Math.ceil(i);   /* Freq position on X axis */
                    var slice = Math.floor(y / slice_height);  /* Time position on vert axis */

                    var db = data[(slice * count) + i0];
                    ttip = [
                        '<b>' + plot.config.title + '</b>',
                        "At " + plot.getValueX(x) + plot.unit + ":",
                        "Time: " + plot.getValueY(y) + plot.vunit,
                        "Power: " + db.toFixed(1) + "dB"
                    ];
                    mouse.pos1 = pos1;
                    this.redraw();
                    break;
                case 'move':
                    cursor = 'move';
                    break;
                case 'area':
                    cursor = 'crosshair';
                    ttip = plot.getValueX(x) + plot.unit + ":<br/>" + plot.getValueY(y) + "dB";
                    break;
                }
                break;
                
            case 'spectrum':
            case 'power':
                if (x < rect.x0 || x > rect.x1)
                    break;

                switch (mouse.mode) {
                case 'select':
                    count >>= 1;

                    /* compute data index from x position relative to plot full area rect0 */
                    var i = (x - rect0.x0) * (count - 1) / (rect0.x1 - rect0.x0);
                    var i0 = Math.floor(i);
                    var i1 = Math.ceil(i);

                    var y0 = (i - i0) * (data[i1 * 2] - data[i0 * 2]) + data[i0 * 2];
                    var y1 = (i - i0) * (data[i1 * 2 + 1] - data[i0 * 2 + 1]) + data[i0 * 2 + 1];
                    ttip = [
                        '<b>' + plot.config.title + '</b>',
                        "At " + plot.getValueX(x) + plot.unit + ":",
                        "Power: " + plot.getValueY(y0) + "dB",
                        "Max: " + plot.getValueY(y1) + "dB",
                    ];
                    mouse.pos1 = pos1;
                    this.redraw();
                    break;
                case 'marker':
                    count >>= 1;

                    var i = (x - rect0.x0) * (count - 1) / (rect0.x1 - rect0.x0);
                    var i0 = Math.floor(i);
                    var i1 = Math.ceil(i);

                    var y0 = (i - i0) * (data[i1 * 2] - data[i0 * 2]) + data[i0 * 2];
                    var y1 = (i - i0) * (data[i1 * 2 + 1] - data[i0 * 2 + 1]) + data[i0 * 2 + 1];
                    ttip = [
                        '<b>' + (event.buttons? 'Add Diff Marker': 'Add Marker') + '</b>',
                        "At " + plot.getValueX(x) + plot.unit + ":",
                        "Power: " + plot.getValueY(y0) + "dB",
                        "Max: " + plot.getValueY(y1) + "dB",
                    ];
                    mouse.pos1 = pos1;
                    mouse.marker_plot = plot;
                    mouse.marker_x = plot.getValueX(x);
                    this.redraw();
                    break;
                case 'move':
                    cursor = 'move';
                    break;
                case 'area':
                    cursor = 'crosshair';
                    var ttip = plot.getValueX(x) + plot.unit + ":<br/>" + plot.getValueY(y) + "dB";
                    break;
                }
                break;

            case 'mer':
            case 'evm':
                if (x < rect.x0 || x > rect.x1)
                    break;

                switch (mouse.mode) {
                case 'select':
                    count >>= 1;
                    var i = Math.round((x - rect0.x0) * (count - 1) / (rect0.x1 - rect0.x0));

                    var x = i * rect0.x1 / count;
                    var y0 = data[i * 2];
                    var y1 = data[i * 2 + 1];
                    if (isNaN(y0) || isNaN(y1))
                        break;
                    pos1.px = Math.round(plot.getX(x));

                    var nc = plot.getValueX(x);

                    if (plot.type == 'evm') {
                        ttip = [
                            '<b>' + plot.config.title + '</b>',
                            plot.config.mode + ' ' + nc + ":",
                            "EVM: " + plot.getValueY(y0) + "%",
                            "Max: " + plot.getValueY(y1) + "%",
                        ];
                    }
                    else {
                        ttip = [
                            '<b>' + plot.config.title + '</b>',
                            plot.config.mode + ' ' + nc + ":",
                            "MER: " + plot.getValueY(y0) + "dB",
                            "Min: " + plot.getValueY(y1) + "dB",
                        ];
                    }
                    mouse.pos1 = pos1;
                    this.redraw();
                    break;
                case 'area':
                    cursor = 'crosshair';
                    //var ttip = "Carrier " + plot.getValueX(x) ": " + plot.getValueY(y) + "dB";
                    break;
                case 'move':
                    cursor = 'move';
                    break;
                }
                break;
            case 'qam':
                if (x < rect.x0 || x > rect.x1)
                    break;

                var x = pos1.px / plot.pw * (rect.x1 - rect.x0) + rect.x0;
                var y = (plot.ph - pos1.py) / plot.ph * (rect.y1 - rect.y0) + rect.y0;

                cursor = 'crosshair';
                ttip = [
                    '<b>' + plot.config.title + '</b>',
                    plot.getValueX(x) + ' / ' + plot.getValueY(y),
                ];
                break;
            }
        } else if (plot) {
            if (plot.error) {
                ttip = ['<b>' + plot.config.title + '</b>'];
            }
        }
        this._canvas.style.cursor = cursor;
        this._setTooltip(ttip, event);
    },

    _mouseMoveEvent: function (event) {

        var mouse = this._mouse;
        var pos1 = this._eventToPosition(event);
        var plot = pos1.plot;
        var ttip = null;
        var pos0 = mouse.pos0;

        if (mouse.click) {
            var d2 = Math.pow(pos0.cx - pos1.cx, 2) + Math.pow(pos0.cy - pos1.cy, 2);
            if (d2 < 4)
                return;
            mouse.click = false;
        }

        switch (mouse.mode) {
        case 'area':
            if (pos1.in && pos0.plot === plot) {
                var x = [this._plotGetX(plot, pos0.x), this._plotGetX(plot, pos1.x)].sort((a, b) => a - b);
                var y = [this._plotGetY(plot, pos0.y), this._plotGetY(plot, pos1.y)].sort((a, b) => a - b);
                var rect = mouse.area = {
                    x: pos0.cx,
                    y: pos0.cy,
                    w: pos1.cx - pos0.cx,
                    h: pos1.cy - pos0.cy,
                    x0: x[0],
                    x1: x[1],
                    y0: y[0],
                    y1: y[1],

                };
                ttip = ['x: ' + plot.getValueX(rect.x0) + ' to ' + plot.getValueX(rect.x1), 'y: ' + plot.getValueY(rect.y0) + ' to ' + plot.getValueY(rect.y1)];
                this.redraw();
            }
            break;

        case 'move':
            var plot = pos0.plot;
            var dx = (pos1.cx - pos0.cx) * (plot.rect.x1 - plot.rect.x0) / plot.pw;
            var dy = (pos1.cy - pos0.cy) * (plot.rect.y1 - plot.rect.y0) / plot.ph;

            var rect = plot.rect;
            var w = plot.rect.x1 - plot.rect.x0;
            rect.x0 = mouse.rect0.x0 - dx;
            rect.x1 = mouse.rect0.x1 - dx;
            rect.y0 = mouse.rect0.y0 + dy;
            rect.y1 = mouse.rect0.y1 + dy;

            if (rect.x0 < plot.bounds.x0) {
                rect.x0 = plot.bounds.x0;
                rect.x1 = rect.x0 + w;
            } else if (rect.x1 > plot.bounds.x1) {
                rect.x1 = plot.bounds.x1;
                rect.x0 = rect.x1 - w;
            }
            this.redraw();
            break;

        case 'select':
            mouse.pos1 = pos1;
            mouse.select = true;
            this.redraw();
            break;

        default:
            break;
        }

        this._setTooltip(ttip, event);
    },

    _mouseContextMenuEvent: function (event) {
        event.preventDefault();
    },

    _mouseUpEvent: function (event) {

        var mouse = this._mouse;
        if (mouse.click) {
            mouse.click = false;
        }
        if (mouse.select) {
            mouse.select = false;
            var pos1 = this._eventToPosition(event);
            var plot1 = pos1.plot;
            var plot0 = mouse.pos0.plot;

            var i0 = this._plots.indexOf(plot0);
            var i1 = this._plots.indexOf(plot1);
            if (i1 >= 0 && i0 >= 0 && i1 !== i0) {
                this._plots[i0] = plot1;
                this._plots[i1] = plot0;
                this.redraw();
                this.plotSave();
                this.viewStore.sort();
            }
        }
        event.preventDefault();
    },

    _updateButtons: function () {
        var plot = this._curPlot;
        if (plot) {
            this.pauseButton.setIconCls(plot.pause ? 'icon-pause' : 'icon-play');
            this.pauseButton.setDisabled(false);
            this.rescaleButton.setDisabled(false);
            this.screenshotButton.setDisabled(false);
            this.deleteButton.setDisabled(false);
            this.fullscreenButton.setDisabled(this._plots.length <= 1);

            switch (plot.type) {
            case 'spectrum':
            case 'power':
                this.markerButton.setDisabled(false);
                this.clearButton.setDisabled(false);
                break;
            default:
                this.markerButton.setDisabled(true);
                this.clearButton.setDisabled(true);
                this.selectButton.setPressed(true);
                this._mouseSetMode('select');
                break;
            }
        } else {
            this.pauseButton.setDisabled(true);
            this.rescaleButton.setDisabled(true);
            this.fullscreenButton.setDisabled(true);
            this.screenshotButton.setDisabled(true);
            this.deleteButton.setDisabled(true);
            
            this.markerButton.setDisabled(true);
            this.clearButton.setDisabled(true);
            this.selectButton.setPressed(true);
            this._mouseSetMode('select');
        }
        
        if (this._plots.length) {
            this.rescaleAllButton.setDisabled(false);
            this.screenshotButton.setDisabled(false);
        } else {
            this.rescaleAllButton.setDisabled(true);
            this.screenshotButton.setDisabled(true);
        }
    },

    _updateForceDemodButton: function () {
        this.forceDemodButton.setVisible(!this._plots.find( (plot) => { return plot.demod; }));
    },
});


Ext.define('lte.view.plot.create', {

    title: 'Create view',
    extend: 'lte.popup',
    width: 400,
    iconCls: 'icon-view',

    constructor: function (options) {
        this.callParent(arguments);
    },

    initComponent: function () {

        var title = this.titleField = Ext.create({
            xtype: 'textfield',
            value: '',
            fieldLabel: 'Title',
            name: 'title',
            width: '100%',
            allowBlank: true,
            minLength: 0,
            maxLength: 30,
            emptyText: '',
            listeners: { scope: this, change: () => { updateTitle(); } },
        });
        var updateTitle = () => {
            p = this.form.getForm().getFieldValues();
            
            switch (p.type) {
            case 'spectrum':
                title.emptyText = 'Spectrum #' + p.channel;
                break;
            case 'power':
                title.emptyText = 'Power #' + p.channel;
                break;
            case 'waterfall':
                title.emptyText = 'Waterfall #' + p.channel;
                break;
            case 'qam':
                title.emptyText = 'Constellation';
                break;
            case 'mer':
                switch (p['mode.mer']) {
                case 'carrier':
                    title.emptyText = 'MER per carrier';
                    break;
                case 'symbol':
                    title.emptyText = 'MER per symbol';
                    break;
                }
                break;
            case 'evm':
                switch (p['mode.evm']) {
                case 'carrier':
                    title.emptyText = 'EVM per carrier';
                    break;
                case 'symbol':
                    title.emptyText = 'EVM per symbol';
                    break;
                }
                switch (p['ref.evm']) {
                case 'mean':
                    title.emptyText += ' (Mean Ref)';
                    break;
                case 'max':
                    title.emptyText += ' (Max Ref)';
                    break;
                }
                break;
            }
            if (!title.value)
                title.reset();
        };

        var channel = Ext.create({
            fieldLabel: 'Channel',
            xtype: 'numberfield',
            name: 'channel',
            width: '100%',
            value: 0,
            minValue: 0,
            maxValue: this.rxChannelCount - 1,
            listeners: { scope: this, change: () => { updateTitle(); } },
        });
        var merMode = Ext.create({
            fieldLabel: 'Mode',
            xtype: 'radiogroup',
            layout: {
                type: 'hbox',
            },
            items: [
                {boxLabel: 'Carrier', name: 'mode.mer', inputValue: 'carrier', checked: true, flex: 1},
                {boxLabel: 'Symbol', name: 'mode.mer', inputValue: 'symbol', checked: false, flex: 1},
            ],
            hidden: true,
            listeners: { scope: this, change: () => { updateTitle(); } },
        });
        var evmMode = Ext.create({
            fieldLabel: 'Mode',
            xtype: 'radiogroup',
            layout: {
                type: 'hbox',
            },
            items: [
                {boxLabel: 'Carrier', name: 'mode.evm', inputValue: 'carrier', checked: true, flex: 1},
                {boxLabel: 'Symbol', name: 'mode.evm', inputValue: 'symbol', checked: false, flex: 1},
            ],
            hidden: true,
            listeners: { scope: this, change: () => { updateTitle(); } },
        });
        var evmRef = Ext.create({
            fieldLabel: 'Ref power',
            xtype: 'radiogroup',
            layout: {
                type: 'hbox',
            },
            items: [
                {boxLabel: 'Mean  (3GPP)', name: 'ref.evm', inputValue: 'mean', checked: true, flex: 1},
                {boxLabel: 'Max', name: 'ref.evm', inputValue: 'max', checked: false, flex: 1},
            ],
            hidden: true,
            listeners: { scope: this, change: () => { updateTitle(); } },
        });

        var types = Ext.create({
            fieldLabel: 'Type',
            xtype: 'radiogroup',
            name: 'type',
            vertical: true,
            columns: 2,
            width: '100%',
            items: [
                {boxLabel: 'Spectrum', name: 'type', inputValue: 'spectrum', checked: true, flex: 1},
                {boxLabel: 'Power', name: 'type', inputValue: 'power', checked: false, flex: 1},
                {boxLabel: 'Waterfall', name: 'type', inputValue: 'waterfall', checked: false, flex: 1},
                {boxLabel: 'Constellation', name: 'type', inputValue: 'qam', checked: false, flex: 1},
                {boxLabel: 'MER', name: 'type', inputValue: 'mer', checked: false, flex: 1},
                {boxLabel: 'EVM', name: 'type', inputValue: 'evm', checked: false, flex: 1},
            ],
            listeners: {
                scope: this,
                change: function (field, newValue, oldValue, eOpts) {
                    switch (newValue.type) {
                    case 'spectrum':
                        channel.setVisible(true);
                        merMode.setVisible(false);
                        evmMode.setVisible(false);
                        evmRef.setVisible(false);
                        break;
                    case 'power':
                        channel.setVisible(true);
                        merMode.setVisible(false);
                        evmMode.setVisible(false);
                        evmRef.setVisible(false);
                        break;
                    case 'waterfall':
                        channel.setVisible(true);
                        merMode.setVisible(false);
                        evmMode.setVisible(false);
                        evmRef.setVisible(false);
                        break;
                    case 'qam':
                        channel.setVisible(false);
                        merMode.setVisible(false);
                        evmMode.setVisible(false);
                        evmRef.setVisible(false);
                        break;
                    case 'mer':
                        channel.setVisible(false);
                        merMode.setVisible(true);
                        evmMode.setVisible(false);
                        evmRef.setVisible(false);
                        break;
                    case 'evm':
                        channel.setVisible(false);
                        merMode.setVisible(false);
                        evmMode.setVisible(true);
                        evmRef.setVisible(true);
                        break;
                    }
                    updateTitle();
                }
            }
        });

        this.fields.push(types, title, channel, merMode, evmMode, evmRef);
        this.callParent(arguments);
        updateTitle();
    },

    onData: function (data) {
        if (data) {
            this.data = { type: data.type, enabled: true };

            this.data.title = data.title || this.titleField.emptyText;

            switch (data.type) {
            case 'spectrum':
                this.data.channel = data.channel;
                break;
            case 'power':
                this.data.channel = data.channel;
                break;
            case 'waterfall':
                this.data.channel = data.channel;
                break;
            case 'qam':
                break;
            case 'mer':
                this.data.mode = data['mode.mer'];
                break;
            case 'evm':
                this.data.mode = data['mode.evm'];
                this.data.ref = data['ref.evm'];
                break;
            }
        }
    },
});



