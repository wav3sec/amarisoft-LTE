#!/bin/node
/*
 * Copyright (C) 2015-2025 Amarisoft
 * UE simulator scenario player version 2025-12-12
 */

const fs = require('fs');


// Logs
var startTime = new Date() * 1;
var getHeader = function () {
    return '[' + ((new Date() - startTime) / 1000).toFixed(3) + ']';
};
var Log = function ()
{
    process.stdout.write(getHeader() + ' ');
    console.log.apply(console, arguments);
}

// Stubs
var lteLogs = global.lteLogs = {
    setLogger: function () {
    },
    load: function () {
    },
    clone: function (o) {
        if (typeof o !== 'object' || o === null) return o;
        var clone = o instanceof Array ? [] : {};
        for (var i in o) {
            clone[i] = this.clone(o[i]);
        }
        return clone;
    },
    merge: function (dst, src, override) {
        for (var i in src) {
            if (override || !dst.hasOwnProperty(i))
                dst[i] = src[i];
        }
        return dst;
    },
    hash: function (str) {
        var h = 5381;

        for (var i = 0; i < str.length; i++) {
            var c = str[i] >>> 0;
            h = ((h << 5) + h) ^ c;
        }
        return (h >>> 0);
    },
    exportFile: function (data, filename, options) {
        client.exportFile(data, filename, options);
    },
    htmlText: function (text) {
        if (text instanceof Array) text = text.join("\n");
        text = text.replace(/<\/?[biu]>\n?/g, '');
        return text;
    },
};
var Ext = global.Ext = {
    define: function () {
    },
    Msg: {
        alert: function (title, msg) {
            Log('Error "' + title + '"', msg);
        },
    },
};

try {
    var WebSocket = require('nodejs-websocket');
} catch (e) {
    console.error("Missing nodejs WebSocket module", e);
    console.error("Please install it:");
    console.error("  Copy node_modules from Amarisoft OTS package (ex: /root/ots/node_modules)");
    console.error("  Or install it:");
    console.error("    npm required:");
    console.error("      > dnf install -y npm");
    console.error("    module installation:");
    console.error("      > npm install -g nodejs-websocket");
    console.error("      or");
    console.error("      > npm install nodejs-websocket");
    process.exit(1);
}

var Help = function (error)
{
    if (error) {
        console.error(error);
        var log = console.error.bind(console);
    } else {
        var log = console.log.bind(console);
    }
    log("ue-sim.js version 2025-12-12, Copyright (C) 2012-2025 Amarisoft");
    log("Usage");
    log("./ue-sim.js <host> <scenario file> [<csv report filename>]");

    process.exit(error ? 1 : 0);
}

var client = {
    config: {
        address: null,
    },
    info: function () {},
    csvFile: null,
    filename: null,
    _sim: null,
    _msgId: 0,
    _msgBatchSize: 100,
    _msgHandlers: {},
    _msgFifo: [],

    sendMessage: function (msg, cb, error) {

        var id = msg.message_id = ++this._msgId;
        if (cb)
            this._msgHandlers[id] = {cb: cb, error: error};

        if (this._msgDeferTimer) {
            clearTimeout(this._msgDeferTimer);
            this._msgDeferTimer = 0;
        }

        if (this._msgFifo.push(msg) < this._msgBatchSize) {
            this._msgDeferTimer = setTimeout(this._sendMessageNow.bind(this), 1);
        } else {
            this._sendMessageNow();
        }
    },

    _sendMessageNow: function () {

        if (this._msgFifo.length === 1) {
            var msg = JSON.stringify(this._msgFifo.shift());
        } else {
            var msg = JSON.stringify(this._msgFifo);
            this._msgFifo.length = 0;
        }
        ws.send(msg);
        this._msgDeferTimer = 0;
    },

    sendMessageList: function (msg, cb, error) {

        var length = msg.length;
        var recv   = [];

        var cbs = function (index, resp, id) {
            recv[index] = resp;
            if (!resp.notification)
                length--;

            cb(recv, resp, index, !length);
        }

        for (var i = 0; i < length; i++) {
            recv[i] = null;
            this.sendMessage(msg[i], cbs.bind(this, i), error);
        }
    },

    recvMessage: function (msg) {

        switch (msg.message) {
        case 'ready':
            Log("Ready");

            this.sendMessage({message: 'config_get'}, (cfg) => {

                this.cells = cfg.cells;
                this.player = libSim.createPlayer(this.sim, null, client, this.playerEvent.bind(this));

                this.player.start();
                this.statsUpdate();
            });
            return;
        default:
            break;
        }

        // Check message handler by id
        var id = msg.message_id;
        var handler = this._msgHandlers[id];
        if (handler) {
            // Delete if not progress message
            if (!msg.notification)
                delete this._msgHandlers[id];

            if (msg.error) {
                if (!handler.error)
                    Log('Error:', msg.error);
                else if (typeof handler.error === 'function')
                    handler.error(msg.error);
                else if (handler.error === true)
                    handler.cb.call(this, msg, id);
                return;
            }
            return handler.cb.call(this, msg, id);
        }
        Log("Receive message", msg.message);
    },

    playerEvent: function (event) {
        switch (event.type) {
        case 'end':
            if (!event.restart) {
                Log('End');
                this.player.exportReport([]); // XXX: cells
                process.exit(0);
            }
            Log('Restart');
            break;
        case 'started':
            Log('Started');
            break;
        case 'script':
            var script = event.script;
            if (script.status === 'done') {
                Log(script.category, script.name, ((script.ratio * 100) >> 0) + '%');
                if (script.log)
                    console.log(script.log);
                if (script.error)
                    console.log(script.error);
            } else {
                Log(script.category, script.name, script.status);
            }
            break;
        case 'none':
            Log('Nothing to do');
            process.exit(0);
            break;
        case 'error':
            Log('Error: ' + event.error);
            process.exit(1);
            break;
        }
    },

    statsUpdate: function () {
        this.sendMessage({ message: 'stats' }, (resp) => {
            this.player.eventListener({ type: 'stats', data: resp });
        });
        this.sendMessage({message: 'ue_get', max: 256}, (resp) => {
            this.player.eventListener({type: 'ue', data: lteSim.ueGetUpdate(resp.ue_list), time: resp.time});
        });
        setTimeout(this.statsUpdate.bind(this), 1000);
    },

    getParams: function (param) {
        switch (param) {
        case 'cells':
            return this.cells;
        }
        return null;
    },

    exportFile: function (data, filename, options) {
        if (this.csvFile)
            filename = this.csvFile;
        Log('Save to "' +  filename + '"');
        fs.writeFileSync(filename, data);
    },

    // Stubs
    profileReset: function () {
    },
    profileDump: function () {
    },


    init: function () {

        for (var i = 2; i < process.argv.length; i++) {
            var arg = process.argv[i];
            switch (arg) {
            case '-h':
            case '--help':
                Help();
                break;
            default:
                if (!this.config.address) {
                    this.config.address = 'ws://' + arg + '/';
                } else if (!this.filename) {
                    try {
                        this.filename = arg;
                        var data = fs.readFileSync(arg);
                        var config = JSON.parse(data);
                        Log('Loading scenario', config.name);
                        this.sim = lteSim.updateSimConfig(config.scenario[0]);
                    } catch (e) {
                        console.error(e);
                        process.exit(1);
                    }
                } else if (!this.csvFile) {
                    this.csvFile = arg;
                } else {
                    Help('Bad argument: ' + arg);
                }
                break;
            }
        }
        if (!this.config.address)
            Help('host parameter is missing');
        if (!this.filename)
            Help('Scenario config file is missing');
    },
};


var libSim = require('./libsim.js');
const UEConfig = libSim.ueConfig;
const lteSim = libSim.lteSim;

client.init();

Log("Connecting to", client.config.address);

// WebSocket
var options = {extraHeaders: {"origin": "UE-Sim"}};
var ws = WebSocket.connect(client.config.address, options);

// Callbacks
ws.on('connect', function () {
    Log("Connected to", client.config.address);
});
ws.on('error', function (err) {
    console.error(getHeader(), "!!! Error", err);
    process.exit(1);
});

ws.on('close', function () {
    Log("!!! Disconnected");
    process.exit(0);
});
ws.on('text', function (msg0) {
    var msg = JSON.parse(msg0);
    client.recvMessage(msg);
});

