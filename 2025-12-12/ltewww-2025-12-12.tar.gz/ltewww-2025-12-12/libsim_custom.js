/*
 * Place your code here to handle your application results
 */
var SimCustomHandler = function (tag, output, error)
{
    var ratio = 0;        /* Between 0 and 1 */
    var log   = output; /* Array of string */

    switch (tag) {
    case 'iperf':
        ratio = 1; // XXX: parse logs
        if (error) {
            var errors = error.split(/\n/);
            for (var i = 0; i < errors.length; i++) {
                var e = errors[i].replace(/^\s+$/, '');
                if (e && !e.match(/the client has terminated/)) {
                    ratio = 0;
                    break;
                }
            };
        }
        break;

    case 'ping':
        output.forEach(function (l) {
            var info = l.match(/(\d+)% packet loss/);
            if (info) {
                ratio = (100 - info[1]) / 100;
            }
        });
        break;
    }

    if (error)
        log.push('<b>', error, '</b>');

    return {
        ratio: ratio,
        log:   log,
    };
}

// Export for nodejs command line mode
if (process && module) {
    module.exports = {
        handler: SimCustomHandler,
    };
}
