Ext.define("lte.logsgrid", {

    extend: 'Ext.panel.Panel',

    html: '<canvas></canvas>',
    border: false,
    layout: 'fit',

    _sliderLock: 0,
    _lastMouseX: -1,
    _lastMouseY: -1,

    _highlightPattern: null,
    _timeOrigin: 0,
    _logList: [],
    _logIndex: 0,
    _headerHeight: 20,
    _lineHeight: 25,
    _colMargin: 4,

    constructor: function (config) {

        this._slider = lteLogs.slider = config.slider;
        this._rowList = [];
        this._imgList = {
            right: new Image(),
            left: new Image(),
            error: new Image(),
            warn: new Image(),
            no: new Image(),
            ok: new Image(),
            info: new Image(),
            star: new Image(),
        };
        for (var i in this._imgList) {
            this._imgList[i].src = 'resources/images/' + i + '.png';
        }

        for (var i = 0; i < modelList.length; i++) {
            var type = modelList[i];

            this._columns.splice(2 + i * 2, 0, {
                text: modelConfig[type].title || type,
                width: 60,
                hidden: true,
                align: 'center',
                renderer: (function(type1, col, row, ctx, log) { return this._colRenderSrc(col, ctx, log, type1); }).bind(this, type)
            }, {
                text: '',
                width: 11,
                hidden: true,
                renderer: (function(col, row, ctx, log) { return this._dirRenderer(col, ctx, log); }).bind(this)
            });
        }

        this._columns.forEach(function (col) { col.minWidth = col.width; });

        this.callParent(arguments);

        this._slider.on('change', (function (slider, newValue, thumb, eOpts) {

            if (this._sliderLock)
                return;

            var index = this._getNotFilteredLogIndex(-newValue);
            if (index >= 0) {
                row = this._createRow(index); // Filtered ?
                row.index = 0;

                // Fill
                this._fillFromRow(row);

                this._sliderLock++;
                this._invalidateRows();
                this._sliderLock--;
            }

        }).bind(this));
    },

    listeners: {
        afterlayout: function(slider, newValue, thumb, eOpts) {
        },
        resize: function(me, width, height) {
            var canvas = me.el.down("canvas").dom;
            lteLogs.setCanvasSize(canvas, width, height);
            me._setCanvas(canvas);
        }
    },

    getSelectedLog: function () {
        return this._selectedLog;
    },

    selectLog: function (log) {

        if (log) {
            this._selectedLog = log;
            this._selectedIndex = this._getLogIndexFromId(log.id);
            this._subSelectionUpdate();
            this._gotoLog(this._selectedIndex, true);
        } else {
            this._selectedLog = null;
            this._selectedIndex = -1;
            this._subSelectionUpdate();
        }
        lteLogs.sendEvent({type: 'selectLog', log: this._selectedLog});
    },

    _subSelectionList: [],

    _subSelectionUpdate: function () {

        var log = this._selectedLog;
        this._subSelectionList.length = 0;
        if (log) {
            switch (log.layer) {
            case 'PHY':
                for (var l = log.retx_prev; l; l = l.retx_prev) {
                    this._subSelectionList.push(l);
                }
                for (var l = log.retx_next; l; l = l.retx_next) {
                    this._subSelectionList.push(l);
                }
                break;
            }
            var alogs = log.getAssociatedLogs(this._logList);
            if (alogs.length)
                this._subSelectionList.push.apply(this._subSelectionList, alogs);
        }
    },

    _gotoLog: function (index, selected) {

        row = this._createRow(index); // Filtered ?
        if (this._selectedRow)
            row.index = this._selectedRow.index;
        else
            row.index = (this._maxRowCount / 3) >>> 0;
        row.adjust = true;

        this._fillFromRow(row);

        this._invalidateRows();
    },

    scrollTo: function (log) {
        if (log) {
            this._gotoLog(this._getLogIndexFromId(log.id));
        }
    },

    scrollStep: function (step, mode) {

        switch (mode) {
        case 'page':
            step *= this._rowList.length;
            break;
        }

        if (step < 0) {
            var count = this._fillRowUp(-step);
            if (count > 0) {
                for (var i = 0; i < count; i++)
                    this._rowList.pop();
            }
            this._invalidateRows();

        } else if (step > 0) {
            var count = this._fillRowDown(step);
            if (!count && this._isLastRowPartial())
                count = 1;

            for (var i = 0; i < count; i++)
                this._rowList.shift();
            this._invalidateRows();
        }
    },

    moveSel: function (step) {
        var logList = this._logList;

        var selRow = this._selectedRow;
        if (!selRow) {
            var log = this._selectedLog;
            if (!log)
                return this.scrollStep(step);

            var logIndex = this._getLogIndexFromId(log.id);
        } else {
            var logIndex = selRow.logIndex;
        }

        for (var i = logIndex + step; i >= 0 && i < logList.length; i += step) {
            var log = logList[i];
            if (!log.filtered) {
                if (selRow)
                    selRow.index = Math.min(Math.max(0, selRow.index + step), this._rowList.length - 1);
                this.selectLog(log);
                break;
            }
        }
    },

    gotoTime: function (ts) {

        if (ts !== false) {
            var log0 = null;
            var logList = this._logList;
            for (i = 0; i < logList.length; i++) {
                var log = logList[i];
                if (log.filtered) continue;

                var diff = log.timestamp - ts;
                if (diff < 0) {
                    log0 = log;
                } else {
                    if (log0 && ts - log0.timestamp < diff)
                        log = log0;
                    break;
                }
            }
            this.selectLog(log);
        }
    },

    _getLogIndexFromId: function (id) {

        // XXX: could be much faster using timestamp as logs are sorted
        var logs = this._logList;
        for (var i = 0; i < logs.length; i++) {
            var log = logs[i];
            if (!log.filtered && log.id === id)
                return i;
        }
        return -1;
    },

    _getNotFilteredLogIndex: function (index) {

        var logList = this._logList;
        index = Math.min(index, logList.length - 1);
        for (var a = b = index;; a--, b++) {
            if (a >= 0) {
                var log = logList[a];
                if (!log.filtered)
                    return a;
            }
            if (b < logList.length && b > a) {
                var log = logList[b];
                if (!log.filtered)
                    return b;
            } else if (a < 0) {
                break;
            }

        }
        return -1;
    },

    _getPrevLog: function (row) {
        for (var i = Math.min(this._logList.length, row.logIndex); i--;) {
            if (!this._logList[i].filtered)
                return this._logList[i];
        }
        return null;
    },

    _fillFromRow: function (row) {
        if (row) {
            // Fill from row
            var rowList = this._rowList = [row];
            this._fillRowUp(row.index - rowList.length + 1);
            this._fillRowDown(this._maxRowCount - rowList.length);
            this._fillRowUp(this._maxRowCount - rowList.length - 1);

        } else {
            this._rowList.length = 0;
        }
    },

    hasLogs: function () {
        return this._rowList.length > 0;
    },

    setLogs: function (logs, follow) {

        var t0 = new Date() - 0;

        /* Follow ? */
        if (follow && this._rowList.length) {
            var row = this._rowList[this._rowList.length - 1]
            for (var i = row.logIndex + 1;; i++) {
                var log = this._logList[i];
                if (!log)
                    break;
                if (!log.filtered) {
                    follow = false;
                    break;
                }
            }
        }

        this._logIndexes = [];

        if (logs !== this._logList) {
            this._logList = logs;
        }
        var length = logs.length;

        //console.log('Set logs', length, this._selectedRow, follow);

        var row = null;
        if (follow) {
            for (var i = length; i--;) {
                var log = logs[i];
                if (!log.filtered) {
                    var row = this._createRow(i);
                    row.index = Math.min(i, this._maxRowCount - 1);
                    this._rowList = [row];
                    break;
                }
            }
        } else if (length) {
            // Try to recover from selected or middle of grid
            var rowList = this._rowList;
            while (rowList.length > 0) {
                if (this._selectedRow) {
                    var index = this._selectedRow.index;
                    this._selectedRow = null;
                } else{
                    var index = rowList.length >>> 1;
                }
                var id = rowList[index].log.id;

                var i = this._getLogIndexFromId(id);
                if (i >= 0) {
                    var row = rowList[index];
                    row.logIndex = i;
                    break;
                }
                rowList.splice(index, 1);
            }
        }

        if (!row) {
            // Use timestamp ???
            var index = this._getNotFilteredLogIndex(this._getSliderValue());
            if (index >= 0) {
                row = this._createRow(index);
                row.index = 0;
            }
        }

        this._fillFromRow(row);

        // Update selected log
        if (this._selectedLog) {
            var id = this._selectedLog.id;
            this._selectedLog = null;
            for (var i = 0; i < logs.length; i++) {
                var log = logs[i];
                if (log.id === id) {
                    this._selectedLog = log;
                    this._selectedIndex = i;
                    this._subSelectionUpdate();
                    break;
                }
            }
            if (!this._selectedLog)
                this.selectLog(null);
        }

        this._invalidateRows();

        lteLogs.prof("Set logs in", (new Date() - t0), "ms");
    },

    setColumnState: function (idx, state) {
        if (this._columns[idx].hidden === state) {
            this._columns[idx].hidden = !state;
            this.refresh(true);
        }
    },

    setColumnSize: function (idx, size) {
        if (this._columns[idx].width !== size) {
            this._columns[idx].width = size;
            this.refresh(true);
        }
    },

    setDirColumnState: function (idx, state, prevModel, nextModel) {
        var col = this._columns[idx];
        col.prevModel = prevModel;
        col.nextModel = nextModel;
        this.setColumnState(idx, state);
    },

    _refreshRow: function (row) {
        row.dirty = true;
        this.refresh();
    },

    _getSliderValue: function () {
        return Math.min(-this._slider.getValue(), this._getSliderMaxValue());
    },

    _getSliderMaxValue: function () {
        var max = Math.max(this._logList.length - this._maxRowCount, 0);
        if (this._isLastRowPartial())
            max++;
        return max;
    },

    _invalidateRows: function () {

        this._selectedRow = null;

        // Try to complete
        this._fillRowDown(this._maxRowCount - this._rowList.length);

        var rowList = this._rowList;
        var y0 = this._headerHeight;
        for (var i = 0; i < rowList.length; i++) {
            var row = this._rowList[i];
            row.x0 = 0;
            row.x1 = this._canvas.width;
            row.y0 = y0;
            row.y1 = y0 + this._lineHeight;
            row.index = i;
            row.dirty = true;
            row.partial = row.y1 > this._canvas.height;
            row.selected = this._selectedLog === row.log;
            if (row.selected) {
                this._selectedRow = row;
                if (row.partial && row.adjust) {
                    // Avoid partial drawn selected row
                    this._fillRowDown(1);
                    this._rowList.shift();
                    return this._invalidateRows();
                }
            } else {
                row.subselected = this._subSelectionList.indexOf(row.log) >= 0;
            }
            row.adjust = false;
            row.highlighted = this._checkRowIsHighlighted(row);
            if (row.highlighted)
                this._highlightedRow = row;

            y0 = row.y1;
        }

        // Slider
        this._sliderLock++;
        this._sliderMaxValue = this._getSliderMaxValue();
        this._slider.setMinValue(-this._sliderMaxValue);
        if (rowList.length && this._sliderLock < 2) {
            this._slider.setValue(Math.max(-rowList[0].logIndex, -this._sliderMaxValue));
        }
        this._sliderLock--;

        this.refresh(true);
    },

    refresh: function (full) {
        if (!this._refreshFull)
            this._refreshFull = full;

        if (!this._drawTimer)
            this._drawTimer = setTimeout(this._draw.bind(this), 10);
    },

    _setCanvas: function (canvas) {

        var ctx = canvas.getContext('2d');

        if (canvas !== this._canvas) {
            this._canvas = canvas;
            canvas.addEventListener(lteLogs.getMouseWheelEvent(), this._mouseWheelEvent.bind(this), {passive: true});
            canvas.addEventListener("mousedown", this._mouseDownEvent.bind(this), false);
            canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this), false);
            canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this), false);
            //canvas.addEventListener("mouseup", this._mouseUpEvent.bind(this), false);
            canvas.addEventListener("contextmenu", this._contextMenu.bind(this), false);
        }

        this._maxRowCount = Math.ceil((canvas.height - this._headerHeight) / this._lineHeight);

        // Remove
        var rowList = this._rowList;
        while (rowList.length > this._maxRowCount)
            rowList.pop();
        this._fillRowDown(this._maxRowCount - rowList.length);

        this._invalidateRows(true);
    },

    _mouseGetRow: function (event) {
        var rect = event.target.getBoundingClientRect();

        this._lastMouseX = event.clientX - rect.left;
        this._lastMouseY = event.clientY - rect.top;

        for (var i = 0; i < this._rowList.length; i++) {
            var row = this._rowList[i];
            if (this._checkRowIsHighlighted(row))
                return row;
        }
        return null;
    },

    _mouseGetCol: function (event) {

        var rect = event.target.getBoundingClientRect();
        var x = event.clientX - rect.left;
        var y = event.clientY - rect.top;
        if (y >= 0 && y <= this._headerHeight) {
            for (var i = 0; i < this._columns.length; i++) {
                var col = this._columns[i];
                if (!col.hidden && x >= col.x0 && x <= col.x1)
                    return col;
            }
        }
        return null;
    },

    _checkRowIsHighlighted: function (row) {
        return this._lastMouseX >= row.x0 &&
                this._lastMouseX <= row.x1 &&
                this._lastMouseY >= row.y0 &&
                this._lastMouseY <= row.y1;
    },

    _changeRowProperty: function (row0, row1, propname, v0, v1) {

        if (row0) {
            row0[propname] = v0;
            this._refreshRow(row0);
        }
        row1[propname] = v1;
        this._refreshRow(row1);
    },

    _isLastRowPartial: function () {
        return this._rowList.length > 0 ? this._rowList[this._rowList.length - 1].partial : false;
    },

    _getRowInfo: function (row) {

        if (!row)
            return null;

        var log = row.log;
        var lines = [];
        switch (log.layer) {
        case 'PHY':
            if (log.frame) lines.push('Frame: ' + log.getFrameString(true));
            lines.push('Cell: ' + log.getCell().getName());
            break;

        case 'MAC':
            var phr = false, ul_buffer_size = false, count = 2;
            for (i = row.logIndex; i && count > 0; i--) {
                var l = this._logList[i];
                if (l.layer === 'MAC') {
                    if (!phr && l.phr !== undefined) {
                        lines.push('Last PHR: ' + l.phr);
                        phr = true;
                        count--;
                    }
                    if (!ul_buffer_size && l.ul_buffer_size !== undefined) {
                        lines.push('UL buffer size: ' + lteLogs.formatBytes(l.ul_buffer_size));
                        ul_buffer_size = true;
                        count--;
                    }
                }
            }
            break;
        case 'IP':
            lines.push('Size: ' + log.ip_len + ' bytes');
            break;

        default:
            var imeisv = log.imeisv;
            if (imeisv) {
                lines.push('IMEISV: ' + imeisv);
                break;
            }
            return null;
        }
        return lines.join('</br>');
    },

    _mouseDownEvent: function (event) {
        var row = this._mouseGetRow(event);
        if (row) {
            if (event.button === 0) {
                if (row.log !== this._selectedLog) {
                    // XXX: unselect
                    this._changeRowProperty(this._selectedRow, row, 'selected', false, true);
                    this._selectedRow = row;
                    this.selectLog(row.log);
                }
            }
            return;
        }

        var col = this._mouseGetCol(event);
        if (col) {
            switch (event.button) {
            case 0:
                if (col.click && col.click.call(this, col))
                    this.refresh(true);
                break;
            }
        }
    },

    _mouseMoveEvent: function (event) {
        var row = this._mouseGetRow(event);
        if (row && row !== this._highlightedRow) {
            this._changeRowProperty(this._highlightedRow, row, 'highlighted', false, true);
            this._highlightedRow = row;
        }

        var text = this._getRowInfo(row);
        if (text) {
            this._toolTipShow(text, event.clientX + 5, event.clientY + 5);
        } else {
            this._toolTipHide();
        }
    },

    _mouseOutEvent: function (event) {
        this._toolTipHide();
    },

    _mouseWheelEvent: function (event) {

        var delta = lteLogs.getMouseWheelDelta(event);

        if (delta > 0) {
            if (this._fillRowUp(1)) {
                this._rowList.pop();
                this._invalidateRows();
                this._mouseMoveEvent(event);
            }
        } else if (delta < 0) {
            if (this._fillRowDown(1) || this._isLastRowPartial()) {
                this._rowList.shift();
                this._invalidateRows();
                this._mouseMoveEvent(event);
            }
        }
    },

    _createRow: function (logIndex) {
        return {
            log: this._logList[logIndex],
            logIndex: logIndex,
            selected: false,
            highlighted: false,
            dirty: true
        };
    },

    _fillRowUp: function (max) {
        max >>= 0;
        for (var i = 0; i < max; i++) {
            var row = this._getRowStep(this._rowList[0], -1);
            if (!row)
                break;

            this._rowList.unshift(row);
        }
        return i;
    },

    _fillRowDown: function (max) {
        max >>= 0;
        for (var i = 0; i < max; i++) {
            var row = this._getRowStep(this._rowList[this._rowList.length - 1], +1);
            if (!row)
                break;

            this._rowList.push(row);
        }
        return i;
    },

    _getRowStep: function (row, step) {

        if (!row)
            return;

        for (var i = row.logIndex + step;; i += step) {
            var log = this._logList[i];
            if (!log)
                break;

            if (!log.filtered) {
                return this._createRow(i);
            }
        }
        return null;
    },

    setHighlightPattern: function (pattern) {
        this._highlightPattern = pattern;
        this.refresh(true);
    },

    setTimeOrigin: function (ts) {
        this._timeOrigin = ts;
        this.refresh(true);
    },

    getTimeOrigin: function (ts) {
        return this._timeOrigin;
    },

    _microseconds: false,

    setUs: function (us) {
        this._microseconds = us;
    },

    _timeColumn: [
        { text: 'Time', width: 90 },
        { text: 'Full time', width: 160 },
        { text: 'Log ID', width: 60 },
        { text: 'Log index', width: 60 },
    ],

    // Columns definition
    _columns: [{
        text: 'Time',
        mode: 0,
        width: 90,
        align: 'right',
        renderer: function(col, row, ctx, log) {
            switch (col.mode) {
            case 0:
            case 1:
                var ts = log.getTimestamp(this._microseconds);
                var prevLog = this._getPrevLog(row);
                if (prevLog) {
                    var diff = ts - prevLog.getTimestamp(this._microseconds);
                    if (!diff)
                        return '-';
                }
                if (this._microseconds)
                    return lteLogs.ts2timeUs(ts - this._timeOrigin * 1000, col.mode === 1);
                return lteLogs.ts2time(ts - this._timeOrigin, col.mode === 1);
            case 2:
                var idx = this._logIndexes[row.logIndex];
                if (idx === undefined) {
                    idx = '';
                    var logs = this._logList;
                    for (var i = n = 0; i < logs.length; i++) {
                        var log = logs[i];
                        if (log.id === row.log.id) {
                            idx = this._logIndexes[row.logIndex] = n;
                            break;
                        }
                        if (!log.filtered) n++;
                    }
                }
                return idx;
            case 3:
                return log.index;
            }
        },
        menuContext: function (col, event) {
            var items = [];
            for (i = 0; i < this._timeColumn.length; i++) {
                if (col.mode === i) continue;

                items.push({
                    text: this._timeColumn[i].text,
                    scope: this,
                    modeIndex: i,
                    handler: function (item) {
                        col.mode = item.modeIndex;
                        col.text = this._timeColumn[item.modeIndex].text;
                        col.width = this._timeColumn[item.modeIndex].width;
                        this.refresh(true);
                    }
                });
            }

            var menu = new Ext.menu.Menu({items: items});
            menu.showAt([event.clientX, event.clientY]);
            return true;
        }
    }, {
        text: 'Time diff',
        width: 80,
        align: 'right',
        renderer: function(col, row, ctx, log) {
            var prevLog = this._getPrevLog(row);
            var us = this._microseconds;
            var diff = prevLog ? log.getTimestamp(us) - prevLog.getTimestamp(us) : 0;
            if (diff) {
                var sign = '+';
                if (diff < 0) {
                    sign = '-';
                    diff = -diff;
                }
                if (us)
                    return sign + (diff / 1000000).toFixed(6);
                return sign + (diff / 1000).toFixed(3);
            }
            return;
        }
    }, {
        text: 'UE ID',
        width: 60,
        align: 'center',
        renderer: function(col, row, ctx, log) {
            var ue_id = log.global_ue_id;
            var global_ue_id = log.getGlobalUEID();
            if (ue_id === global_ue_id) return ue_id;
            if (typeof global_ue_id === 'number') global_ue_id = '(' + global_ue_id + ')';
            return [ue_id, {text: ' ' + global_ue_id, color: '#c0c0c0'}];
        }
    }, {
        text: 'IMSI',
        width: 120,
        hidden: true,
        align: 'center',
        highlight: true,
        renderer: function(col, row, ctx, log) {
            return log.imsi;
        }
    }, {
        text: 'IMEI',
        width: 120,
        hidden: true,
        align: 'center',
        highlight: true,
        renderer: function(col, row, ctx, log) {
            return log.imei;
        }
    }, {
        text: 'Cell',
        width: 35,
        hidden: true,
        align: 'center',
        renderer: function(col, row, ctx, log) {
            return log.cell;
        }
    }, {
        text: 'SFN',
        width: 55,
        hidden: true,
        align: 'center',
        highlight: true,
        renderer: function(col, row, ctx, log) {
            if (log.frame === undefined)
                return undefined;
            if (log.hfn)
                return [{text: log.hfn + '.', color: '#c0c0c0'}, log.getFrameString()];
            return  log.getFrameString();
        }
    }, {
        text: 'RNTI',
        width: 50,
        hidden: true,
        align: 'center',
        highlight: true,
        renderer: function(col, row, ctx, log) {
            if (log.rnti === undefined)
                return;

            return [{text: '0x', color: '#c0c0c0'}, log.rnti.toString(16)];
        }
    }, {
        text: 'Info',
        width: 82,
        align: 'center',
        highlight: true,
        renderer: function(col, row, ctx, log) {
            return lteLogs.id2string(log.info);
        }
    }, {
        text: 'Message',
        align: 'left',
        highlight: true,
        flex: 1,
        renderer: function(col, row, ctx, log) {
            var msg = [];

            var cliCol = log.client.getColor();
            if (cliCol) {
                msg.push({ square: cliCol, width: 12, size: 16 });
            }

            // Display icons
            if (log.level === 1 || log.layer === 'ERROR')
                msg.push({img: 'error', width: 12, size: 16});
            else if (log.level === 2)
                msg.push({img: 'warn', width: 12, size: 16});

            // TB
            if (log.tb) {
                for (var i = 0; i < log.tb.length; i++) {
                    var tb = log.tb[i];
                    if (!tb) continue;
                    if (tb.crc === false)
                        msg.push({img: 'no', width: 12, size: 16});
                    else if (tb.crc === true)
                        msg.push({img: 'ok', width: 12, size: 16});
                    else if (tb.error)
                        msg.push({img: 'no', width: 12, size: 16});
                    else if (tb.acked)
                        msg.push({img: 'ok', width: 12, size: 16});
                }
            }

            // Data
            if (log.data && log.data.length)
                msg.push({img: 'info', width: 12, size: 16});
            if (log.signalRecord)
                msg.push({img: 'star', width: 12, size: 16});

            if (!(log.msg instanceof Array))
                msg.push(log.msg);
            else
                msg = msg.push.apply(msg, msg.log);

            return msg;
        }
    }
    ],

    _drawText: function (ctx, text, x0, y0, x1, y1, align) {

        // Layout
        var sizes = [];
        var width = 0;
        this._textIterate(text, function (t, i) {
            if (t.size !== undefined) {
                var w = t.size >>> 0;
            } else if (t.text !== undefined) {
                ctx.save();
                if (t.font) ctx.font = t.font;
                var w = ctx.measureText(t.text).width;
                ctx.restore();
            } else {
                var w = 0;
            }

            sizes.push(w);
            width += w;
        });

        // Position
        switch (align) {
        case 'right':
            var x = x1 - width;
            break;
        case 'center':
            var x = (x1 + x0 - width) / 2;
            break;
        default:
            var x = x0;
            break;
        }

        // Draw
        this._textIterate(text, (function (t, i) {

            var bgColor = t.background;
            if (bgColor) {
                ctx.save();
                ctx.fillStyle = bgColor;
                ctx.fillRect(x, y0 - 7, sizes[i], 14);
                ctx.restore();
            } else {
                bgColor = this._bgColor;
            }
            if (t.img) {
                var img = this._imgList[t.img];
                if (img) {
                    var h = t.height;
                    var w = t.width;
                    if (!h) {
                        if (!w) w = sizes[i];
                        h = img.height / img.width * w;
                    } else if (!w) {
                        w = img.width / img.height * h;
                    }
                    // Compensate 0.5 offset of canvas (that was for line precision)
                    ctx.drawImage(img, x + ((sizes[i] - w) >> 1) - 0.5, y0 - (h >> 1) - 0.5, w, h);
                }
            }
            if (t.square) {
                var w = t.width;
                var left =  x + ((sizes[i] - w) >> 1) - 0.5
                var top = y0 - (w >> 1) - 0.5

                ctx.fillStyle = t.square;
                ctx.fillRect(left, top, w, w);
                ctx.strokeStyle = 'block';
                ctx.lineWidth = 1;
                ctx.strokeRect(left + 0.5, top + 0.5, w - 1, w - 1);
            }
            if (t.text !== undefined) {
                ctx.save();
                if (t.font) ctx.font = t.font;
                if (t.color) {
                    ctx.fillStyle = t.color;
                } else if (this._textColor) {
                    ctx.fillStyle = this._textColor;
                } else if (bgColor) {
                    ctx.fillStyle = lteLogs.getTextColor(bgColor);
                }
                if (Ext.isFirefox) {
                    ctx.fillText(t.text, Math.floor(x) + 0.5, y0);
                } else {
                    ctx.fillText(t.text, x, y0);
                }
                ctx.restore();
            }

            x += sizes[i];
        }).bind(this));

        return width;
    },

    _textIterate: function (text, cb) {

        if (text === undefined || text === null)
            return;

        if (!(text instanceof Array))
            text = [text];

        for (var i = 0; i < text.length; i++) {
            var t = text[i];
            switch (typeof t) {
            case 'object':
                cb(t, i);
                break;
            default:
                cb({text: '' + t}, i);
                break;
            }
        }
    },

    _drawColText: function (col, ctx, text, row) {

        if (col.highlight && row && this._highlightPattern) {
            var text1 = [];
            this._textIterate(text, (function (t, i) {
                if (t.text) {
                    var list = t.text.split(this._highlightPattern);
                    for (var i = 0; i < list.length; i++) {
                        var t1 = {};
                        for (var id in t)
                            t1[id] = t[id];
                        t1.text = list[i];
                        if (i % 2) {
                            t1.font = 'bold ' + ctx.font;
                            t1.background = '#c0ffc0';
                        }
                        text1.push(t1);
                    }
                } else {
                    text1.push(t);
                }
            }).bind(this));
            text = text1;
        }
        if (row && row.selected) {
            var text1 = [];
            this._textIterate(text, function (t, i) {
                t.font = 'bold ' + ctx.font;
                text1.push(t);
            });
            text = text1;
        }

        var width = this._drawText(ctx, text, this._colMargin, col.height >>> 1, col.width - this._colMargin, 0, col.align);
        if (!col.flex) {
            width = Math.ceil(width);
            if (width > col.width) {
                col.width = width;
                this._refreshFull = true;
            }
            // Reduce...
        }
    },

    _rowBgColor: [
        ['white',   '#fafafa'],     // Normal
        ['#e2eff8', '#e2eff8'],     // Highlighted
        ['#C0C0FF', '#C0C0FF'],     // Selected
        ['#e8e8FF', '#d8d8FF'],     // Sub selected
    ],

    _drawInit: function (textColor, bgColor, ctx, x, y, w, h) {

        this._bgColor = bgColor;
        this._textColor = textColor;
        if (ctx && bgColor) {
            ctx.fillStyle = bgColor;
            ctx.beginPath();
            ctx.rect(x, y, w, h);
            ctx.clip();
            ctx.fill();
        }
    },

    _drawRow: function (row, ctx) {

        if (!row.log) return; // Protect

        ctx.save();
        ctx.font = lteLogs.fontDef;
        ctx.translate(row.x0, row.y0);
        ctx.textBaseline = 'middle';

        var height = row.y1 - row.y0;
        var width = row.x1 - row.x0;
        var bgIndex = 0;

        if (row.selected) {
            var bgIndex = 2;
            var sepColor = '#A0A0FF';
        } else {
            if (row.log.marker)
                var bgColor = row.log.marker;
            else if (row.subselected)
                var bgIndex = 3;
            else if (row.highlighted)
                var bgIndex = 1;

            var sepColor = '#c1c1c1';
        }

        this._drawInit(null, bgColor || this._rowBgColor[bgIndex][row.index % 2], ctx, 0, 0, width, height);

        // Columns
        for (var i = 0; i < this._columns.length; i++) {
            var col = this._columns[i];
            if (col.hidden) continue;

            ctx.save();
            ctx.translate(col.x0, 0);
            ctx.beginPath();
            ctx.rect(0, 0, col.width, height);
            ctx.clip();

            var text = col.renderer.call(this, col, row, ctx, row.log, null);
            if (text !== undefined)
                col.drawText(ctx, text, row);
            ctx.restore();
        }

        // Separator
        ctx.strokeStyle = sepColor;
        ctx.beginPath();
        ctx.moveTo(0, height);
        ctx.lineTo(width, height);
        ctx.stroke();

        ctx.restore();
    },

    _colRenderSrc: function(col, ctx, log, model) {

        if (log.client.getModel() !== model)
            return;

        ctx.save();
        var cfg = layerConfig[log.layer];
        if (cfg !== undefined) {
            var bgColor = cfg.color;
            var fontColor = cfg.fontColor;
        }
        if (!bgColor)
            bgColor = '#404040';
        if (!fontColor)
            fontColor = lteLogs.getTextColor(bgColor);
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, col.width, this._lineHeight);
        ctx.restore();

        return { text: log.layer, color: fontColor };
    },

    _getDir: function (log, model) {
        var d = layerConfig[log.layer].dir;
        return d[model] || d['*'];
    },

    _dirRenderer: function (col, ctx, log) {

        var dir = log.dir;
        if (!dir) return;

        var model = log.client.getModel();

        /* Left */
        if (col.prevModel === model) {
            var img = this._getDir(log, model) & 0x2;

        /* Right */
        } else if (col.nextModel === model) {
            var img = this._getDir(log, model) & 0x1;
        }

        if (img) {
            if (typeof img !== 'string')
                img = dir === DIR_UL ? this._imgList.right : this._imgList.left;

            if (img) {
                var y = (col.height - 12) >> 1;
                ctx.drawImage(img, 1, y, col.width - 2, 12);
            }
        }
    },

    _draw: function () {
        this._drawTimer = 0;

        var canvas = this._canvas;
        var width = canvas.width;
        var height = canvas.height;
        var lineHeight = this._lineHeight;
        var columns = this._columns;

        var ctx = this._canvas.getContext('2d');

        ctx.save();
        ctx.translate(0.5, 0.5);
        var full = this._refreshFull;
        if (full) {
            this._refreshFull = false;

            ctx.clearRect(0, 0, width, height);

            // Headers
            ctx.save();
            ctx.textBaseline = 'middle';
            ctx.font = lteLogs.fontDef;
            var x0 = 0;
            for (var i = 0; i < columns.length; i++) {
                var col = columns[i];
                if (col.hidden) continue;

                // Init column
                if (col.flex) col.width = width - x0;
                var x1 = x0 + col.width;
                col.x0 = x0;
                col.x1 = x1;
                col.height = this._headerHeight;
                col.drawText = this._drawColText.bind(this, col);

                ctx.save();
                this._drawInit('#666666', '#e0e0e0', ctx, 0, 0, col.width, this._headerHeight);

                col.drawText(ctx, col.text, null);

                ctx.strokeStyle = '#c0c0c0';
                ctx.strokeRect(0, 0, col.width, this._headerHeight);
                ctx.restore();

                col.height = lineHeight; // For row

                // Next column
                ctx.translate(col.width, 0);
                x0 = x1;
            }
            ctx.restore();
        }

        // Rows
        for (var i = 0; i < this._rowList.length; i++) {
            var row = this._rowList[i];
            if (row.dirty || full) {
                this._drawRow(this._rowList[i], ctx);
                row.dirty = false;
            }
        }

        ctx.restore();

        if (this._refreshFull)
            this._draw();
    },

    _contextMenu: function (event) {

        var row = this._mouseGetRow(event);
        if (!row) {
            var col = this._mouseGetCol(event);
            if (col) {
                if (col.menuContext && col.menuContext.call(this, col, event)) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            }
            return;
        }

        var items = [];

        var log = row.log;
        var ue_id = log.global_ue_id;

        items.push({
            text: 'Copy first line to clipboard',
            scope: this,
            iconCls: 'icon-copy',
            handler: function () {
                log.clipboardCopy('short');
            }
        });

        if (ue_id !== undefined) {
            items.push({
                text: 'Show stats...',
                scope: this,
                iconCls: 'icon-chart',
                handler: function() {
                    var win = Ext.create('lte.analytics.win');
                    win.open(lteLogs.getLogs(), ue_id);
                }
            });
        }

        if (log.isBrowsable()) {
            items.push({
                text: 'Navigate',
                scope: this,
                iconCls: 'icon-folder',
                handler: function () {
                    log.browse();
                },
            });
        }

        items.push({xtype: 'menuseparator'});

        lteLogs.contextMenu(items, log);

        items.push({xtype: 'menuseparator'});

        var alogs = log.getAssociatedLogs(this._logList);
        if (log.marker === undefined) {
            items.push({
                text: 'Add marker',
                menu: {
                    xtype: 'colormenu',
                    scope: this,
                    handler: function (cp, value) {
                        log.marker = '#' + value;
                        this._refreshRow(row);
                    }
                }
            });
        } else {
            items.push({
                text: 'Remove marker',
                scope: this,
                icon: lteLogs.createColorIcon(log.marker),
                handler: function () {
                    log.marker = undefined;
                    this._refreshRow(row);
                }
            });
            if (alogs.length) {
                items.push({
                    text: 'Add marker to associated logs',
                    scope: this,
                    icon: lteLogs.createColorIcon(log.marker),
                    handler: function () {
                        alogs.forEach( (l) => { l.marker = log.marker; });
                        this._invalidateRows();
                    }
                });
                if (alogs.find( (l) => { return l.marker === log.marker; })) {
                    items.push({
                        text: 'Remove marker from associated logs',
                        scope: this,
                        icon: lteLogs.createColorIcon(log.marker),
                        handler: function () {
                            alogs.forEach( (l) => { l.marker = undefined; });
                            this._invalidateRows();
                        }
                    });
                }
            }
        }

        var markers = this._logList.filter(function (log) { return !log.filtered && log.marker; });
        if (markers.length) {
            items.push({
                text: 'Goto log',
                menu: {
                    xtype: 'menu',
                    items: markers.map( (log) => {
                        return {
                            text: this._log2String(log, 80),
                            icon: lteLogs.createColorIcon(log.marker),
                            scope: this,
                            handler: (function (log) {
                                this.scrollTo(log);
                            }).bind(this, log)
                        };
                    })
                }
            });
        }

        var menu = new Ext.menu.Menu({items: items});
        menu.showAt([event.clientX, event.clientY]);
        event.preventDefault();
        event.stopPropagation();
        return false;
    },

    _log2String: function (log, max) {

        var str = [lteLogs.ts2time(log.timestamp - this._timeOrigin), log.layer]
        str.push(log.msg);
        str = str.join(' ');
        if (max && str.length > max)
            str = str.substr(0, max) + '...';
        return str;
    },


    _toolTipShow: function (text, x, y) {

        if (!this._toolTipWidget) {
            this._toolTipWidget = Ext.create('Ext.tip.ToolTip', {
                target: this._canvas,
                trackMouse: true,
                //autoHide: true,
            });
        }

        this._toolTipWidget.update(text);
        this._toolTipWidget.show([x, y]);
        //event.clientX, event.clientY]);
    },

    _toolTipHide: function () {
        if (this._toolTipWidget) {
            this._toolTipWidget.hide();
        }
    },

    drawLog: function (log, ctx, x, y, width) {

        var logIndex = this._getLogIndexFromId(log.id);
        if (logIndex >= 0) {
            var row = this._createRow(logIndex);
            row.x0 = x;
            row.y0 = y;
            row.x1 = x + width;
            row.y1 = y + this._lineHeight;
            row.index = 0;
            this._drawRow(row, ctx);
        }
    },
});

