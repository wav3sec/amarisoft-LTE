/*
 * Copyright (C) 2017-2025 Amarisoft
 */

Ext.define("lte.mme.tab", {

    extend: 'lte.client.tab',

    _chartList: [{
        title:        'Messages',
        fieldType:    ['messages'],
        serieWidth: 400,
        unit: ''
    }, {
        title:        'Errors',
        fieldType:    ['errors'],
        serieWidth: 400,
        unit: ''
    }],

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var store = Ext.create('Ext.data.Store', {
            fields: ["imsi", "imeisv", "m_tmsi", '5g_tmsi', 'rat', "registered"]
        });

        var sumPanel = Ext.create('Ext.panel.Panel', {
            border: 0,
            html: 'Total: 0'
        });

        var grid = Ext.create('Ext.grid.Panel', {
            store: store,
            tbar: [sumPanel],
            columns: [{
                text: "IMSI",
                dataIndex: "imsi",
                width: 150
            }, {
                text: 'IMEISV',
                dataIndex: 'imeisv',
                width: 150,
            }, {
                text: 'RAT',
                dataIndex: 'rat',
                width: 40
            }, {
                text: 'M-TMSI',
                dataIndex: 'imsi',
                renderer: function (imsi, metadata, record) {
                    var tmsi = record.get('m_tmsi');
                    if (!tmsi) tmsi = record.get('5g_tmsi');
                    if (!tmsi) return '-';
                    return '0x' + tmsi.toString(16);
                },
                flex: 1,
            }, {
                text: 'Reg.',
                dataIndex: 'registered',
                type: 'boolean',
                width: 50
            }],
        });

        var ueCache = {};

        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            dirty:            true,
            lock:            1,
            handler:        function () {
                this.client.sendMessage({message: 'ue_get'}, function (msg) {

                    var reg = 0;
                    var lte = 0;
                    var nr  = 0;
                    msg.ue_list.forEach(function (ue) {
                        if (ue.registered) reg++;
                        if (ue.m_tmsi) {
                            lte++;
                            ue.rat = 'LTE';
                        } else if (ue['5g_tmsi']) {
                            nr++;
                            ue.m_tmsi = ue['5g_tmsi'];
                            ue.rat = 'NR';
                        } else {
                            ue.m_tmsi = '-';
                            ue.rat = '?';
                        }
                    });

                    var sum = ['Total: ' + msg.ue_list.length];
                    if (reg) sum.push('registered: ' + reg);
                    if (lte) sum.push('LTE: ' + lte);
                    if (nr) sum.push('NR: ' + nr);
                    sumPanel.update(sum.join(', '));

                    lteLogs.storeUpdate(ueCache, store, msg.ue_list, 'm_tmsi');
                });
            }
        });

        this.add({
            region: 'west',
            layout: 'fit',
            width: 520,
            items: [grid]
        });
        this.add({
            split: true,
            layout: 'fit',
            region: 'center',
            items: [this.getChartPanel()],
        });
    },

    _eventListener: function (event) {
        switch (event.type) {
        case 'stats':
            var now = new Date() * 1;
            this._updateCounters(now, event.data.counters);
            this._updater.update(true);
            break;
        }
    },
});



