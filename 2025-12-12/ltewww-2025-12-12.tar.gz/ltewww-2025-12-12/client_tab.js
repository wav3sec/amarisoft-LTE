/*
 * Copyright (C) 2017-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-12-12
 */

Ext.define("lte.client.tab", {

    extend: 'Ext.panel.Panel',
    layout: 'border',

    useRefresh: false,
    topToolbarCount: 1,

    _duration: 60000,

    _statsPolldelay: 1000,

    constructor: function (config) {

        this._minTime  = this._startTime = new Date() - 0;
        this._maxTime  = this._minTime + this._duration;

        this._chartList = lteLogs.clone(this._chartList); // Clone to move from parent class as array may be modified

        // Fast access to chart from field type
        var field2chart = this._field2chart = {};
        this._chartList.forEach(function (chart) {
            chart.fieldType.forEach(function (f) {
                field2chart[f] = chart;
            });
        });

        // Listen events
        this._listenerId = config.client.registerEventListener('*', this._eventListener.bind(this));

        this.callParent(arguments);
    },

    getToolbar: function (id) {
        return this.dockedItems.items[id >>> 0];
    },

    initComponent: function () {

        this.dockedItems = [];
        for (var i = 0; i < this.topToolbarCount; i++) {
            this.dockedItems.push({
                xtype: 'toolbar',
                dock: 'top',
                items: []
            });
        }
        this.callParent(arguments);

        this.tbar = this.myTbar || this.getToolbar(0);

        if (!this.noMonitor) {
            this.tbar.add({
                tooltip: lteLogs.tooltip("Monitor"),
                iconCls: "icon-monitor",
                scope: this,
                handler: function() {
                    if (!this.client._monitorWindow) {
                        this.client._monitorWindow = Ext.create('lte.client.monitor', {
                            client: this.client,
                            title: this.client.getName() + ' monitor',
                            listeners: {
                                scope: this,
                                close: function () {
                                    this.client._monitorWindow = null;
                                }
                            }
                        });
                    }
                    this.client._monitorWindow.show();
                }
            });
        }

        if (this._updater) {
            this.tbar.add({
                text: 'Refresh',
                scope: this,
                iconCls: 'icon-refresh',
                tooltip: lteLogs.tooltip("Force refresh"),
                scope: this,
                handler: function() { this.lteUpdate(); }
            });
        }

        if (this.useRefresh) {
            this.tbar.add({
                xtype: 'numberfield',
                width: 60,
                value: this.client.getRefreshDelay() / 1000,
                step: 1,
                maxValue: 3600,
                minValue: 0.1,
                allowDecimals: true,
                decimalPrecision: 1,
                tooltip: lteLogs.tooltip("Refresh rate in seconds"),
                listeners: {
                    scope: this,
                    change: function(num, newValue, oldValue, eOpts) {
                        if (newValue && num.isValid())
                            this.client.setRefreshDelay(newValue * 1000);
                    }
                }
            });
        }
    },

    listeners: {
        activate: function () {
            this._eventListener({ type: 'activate' });
            if (this._updater) {
                this._updater.update(true);
                this._updater.unlock();
            }
            this._chartList.forEach(function (chart) { chart.comp.unlock(); });
        },

        deactivate: function() {
            this._eventListener({ type: 'deactivate' });
            if (this._updater)
                this._updater.lock();
            this._chartList.forEach(function (chart) { chart.comp.lock(); });
        },

        close: function () {
            this._closed = true;
            this._eventListener({ type: 'true' });
            if (this._updater)
                this._updater.destroy();
            this.client.unregisterEventListener(this._listenerId);
        },
    },

    lteUpdate: function() {
        this._updater.update(true);
    },

    getChartPanel: function () {

        this._chartList.forEach( (chart, index) => {
            chart.comp = Ext.create("lte.graph", {
                title: chart.title,
                graph: {
                    debug: chart.debug,
                    axis: {
                        x: {
                            unit: 'date',
                            auto: 'max',
                            min: this._minTime,
                            max: this._maxTime,
                        },
                        y: {
                            unit: chart.unit || '',
                            unitPrecision: chart.unitPrecision,
                            index: 0,
                            min: 0,
                        },
                        z: {
                            unit: '',
                            index: 1,
                        },
                        bler: {
                            unit: '%',
                            min: 0,
                            max: 1,
                            unitPrecision: 2,
                        },
                    },
                    series: chart.series,
                    overMode: 'time',
                },
                showValue: true,
                serieWidth: chart.serieWidth,
                serieStyle: chart.serieStyle,
                tabConfig: {
                    //hidden: true,
                }
            });
        });

        for (var i = 0; i < arguments.length; i++) {
            this._chartList.push({
                comp: arguments[i]
            });
        }

        this._chartPanel = Ext.create('Ext.tab.Panel', {
            xtype: 'tabpanel',
            items: this._chartList.map(function (chart, index) {
                chart.comp.lock();
                chart.index = index;
                return chart.comp;
            })
        });
        return this._chartPanel;
    },

    updateChartTabs: function () {
        var atab = this._chartPanel.getActiveTab();
        var visibles = [];

        this._chartList.forEach( (chart) => {
            if (chart.autoHide) {
                if (chart.comp.hasSerie()) {
                    chart.comp.tab.show();
                    visibles.push(chart.comp);
                } else {
                    chart.comp.tab.hide();
                    if (chart.comp === atab)
                        atab = null;
                }
            } else {
                visibles.push(chart.comp);
            }
        });
        if (!atab && visibles.length) {
            this._chartPanel.setActiveTab(visibles[0]);
        }
    },

    _updateCounters: function (now, counters) {
        if (!counters)
            return;

        var up = false;
        ['messages', 'errors'].forEach( (name) => {
            var chart = this._field2chart[name];
            for (var id in counters[name]) {
                up = chart.comp.addSerie(id, {
                    title: id.replace(/_/g, ' '),
                    enabled: false,
                    values: [{x: now, y: counters[name][id]}]
                }) || up;
            }
            chart.comp.update();
        });
    },

    _updateConfig: function (config) {
    },

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var now = new Date() * 1;
            this._updateCounters(now, event.data.counters);
            break;
        case 'config':
            this._updateConfig(event.data.config);
            break;
        }
    },

    statsRFSamplesInit: function() {

        var statsSamples = Ext.create('Ext.form.field.Checkbox', {
            name: 'samples',
            fieldLabel: 'Samples',
            labelWidth: 55,
            checked: false,
        });
        this.statsdBm = Ext.create('Ext.form.field.Checkbox', {
            name: 'dbm',
            boxLabel: '(dBm)',
            labelWidth: 35,
            checked: false,
        });
        var statsRF = Ext.create('Ext.form.field.Checkbox', {
            name: 'rf',
            fieldLabel: 'RF',
            labelWidth: 25,
            checked: false,
        });

        this._startTime = new Date() / 1000;
        this._statsChart = Ext.create("lte.graph", {
            title: 'Samples/RF',
            tbar: { items: [statsSamples, this.statsdBm, '|', statsRF]},
            graph: {
                columns: 4,
                margin: {
                    top: 20,
                    bottom: 20,
                    left: 50,
                    right: 5,
                },
                axis: {
                    x: {
                        unit: 's',
                        auto: 'max',
                        min: 0,
                        max: this._duration / 1000,
                        maxSize: this._duration / 1000,
                    },
                    rms:    {index: 0, title: 'RMS'},
                    max:    {index: 1, title: 'MAX', max: 0},
                    sat:    {index: 3, title: 'Saturation', unit: '', min: 0},
                    sr:     {index: 4, title: 'Sample rate', unit: 'sr', min: 0},
                    cpu:    {index: 5, title: 'CPU usage', unit: '100%', min: 0},
                    rxtx:   {index: 6, title: 'RX/TX delay', unit: 'ms'},
                },
                series: {},
                showValue: true,
                overMode: 'time',
            }
        });
        this._statsSamplesStarted = false;
        this._statsRFStarted = false;

        this.statsPrepare = function (msg) {
            msg.samples = statsSamples.getValue();
            msg.rf = statsRF.getValue();
        };
    },

    statsRFSamplesFeed: function(event) {

        var data = event.data;

        var now = (new Date() / 1000) - this._startTime;
        var dbm = this.statsdBm.getValue();

        var samples = data.samples;
        var chart = this._statsChart;
        if (samples) {
            if (!this._statsSamplesStarted) {
                for (var i = 0; i < this.rxChannels.length; i++) {
                    chart.addSerie('rx' + i, {title: 'RX Channel ' + i, y: ['rms', 'max', 'sat']});
                }
                for (var i = 0; i < this.txChannels.length; i++) {
                    chart.addSerie('tx' + i, { title: 'TX Channel ' + i, y: ['rms', 'max', 'sat']});
                }
                this._statsSamplesStarted = true;
            }

            samples.rx.forEach(function (chan, idx) {
                chan.x = now;
                chan.sat = chan.sat / chan.count;
                if (dbm)
                    chan.rms = chan.rms_dbm;
                chart.addValues('rx' + idx, [chan]);
            });
            samples.tx.forEach(function (chan, idx) {
                chan.x = now;
                chan.sat = chan.sat / chan.count;
                if (dbm)
                    chan.rms = chan.rms_dbm;
                chart.addValues('tx' + idx, [chan]);
            });
            chart.update();
        }
        var rf = data.rf;
        if (rf) {
            var obj = data.rf_ports || data.cells;

            if (!this._statsRFStarted) {
                chart.addSerie('rf_rx_cpu_time', { title: 'RX', y: ['cpu']});
                chart.addSerie('rf_tx_cpu_time', { title: 'TX', y: ['cpu']});
                for (var id in obj) {
                    chart.addSerie('rf_rxtx_delay_min' + id, { title: 'Min delay #' + id, y: ['rxtx']});
                    chart.addSerie('rf_rxtx_delay_avg' + id, { title: 'Average delay #' + id, y: ['rxtx']});
                    chart.addSerie('rf_rxtx_delay_max' + id, { title: 'Max delay #' + id, y: ['rxtx']});
                    chart.addSerie('rf_rxtx_delay_sd' + id, { title: 'Standard deviation #' + id, y: ['rxtx']});
                    chart.addSerie('rf_rx_sample_rate' + id, { title: 'RX Sample rate #' + id, y: ['sr']});
                    chart.addSerie('rf_tx_sample_rate' + id, { title: 'TX Sample rate #' + id, y: ['sr']});
                }
                this._statsRFStarted = true;
            }

            rf.x = now;
            chart.addValues('rf_rx_cpu_time', [{x: now, cpu: rf.rx_cpu_time}]);
            chart.addValues('rf_tx_cpu_time', [{x: now, cpu: rf.tx_cpu_time}]);

            for (var id in obj) {
                var o = obj[id];
                if (o.rxtx_delay && o.rxtx_delay.min !== undefined) {
                    chart.addValues('rf_rxtx_delay_min' + id, [{x: now, rxtx: o.rxtx_delay.min}]);
                    chart.addValues('rf_rxtx_delay_avg' + id, [{x: now, rxtx: o.rxtx_delay.avg}]);
                    chart.addValues('rf_rxtx_delay_max' + id, [{x: now, rxtx: o.rxtx_delay.max}]);
                    chart.addValues('rf_rxtx_delay_sd' + id, [{x: now, rxtx: o.rxtx_delay.sd}]);
                }
                chart.addValues('rf_rx_sample_rate' + id, [{x: now, sr: rf.rx_sample_rate}]);
                chart.addValues('rf_tx_sample_rate' + id, [{x: now, sr: rf.tx_sample_rate}]);
            }
            chart.update();
        }
    },

    addRFConfig: function (signals, power) {

        this.tbar.add(Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip("RF configuration"),
            iconCls: "icon-air",
            text: 'RF',
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    var rfConfigWindow = this.client.getComponent('rfConfig');
                    if (!rfConfigWindow) {
                        rfConfigWindow = Ext.create('lte.client.config.rf', {
                            title: 'RF Configuration',
                            client: this.client,
                            txChannels: this.txChannels,
                            rxChannels: this.rxChannels,
                            configurePower: !!power,
                            listeners: {
                                scope: this,
                                close: function () {
                                    this.client.removeComponent('rfConfig', true);
                                }
                            }
                        });
                        this.client.addComponent('rfConfig', rfConfigWindow);
                    }
                    rfConfigWindow.show();
                }
            }
        }));

        if (signals) {
            this.tbar.add({
                text: 'Constellations',
                scope: this,
                iconCls: 'icon-star',
                tooltip: lteLogs.tooltip("Show real time constellations"),
                handler: function() {
                    var constWin = this.client.getComponent('const');
                    if (!constWin) {
                        constWin = Ext.create('lte.constellation.win', {
                            title: this.client.getName() + ' constellations',
                            client: this.client,
                            signals: signals,
                            listeners: {
                                close: function () {
                                    this.client.removeComponent('const', true);
                                }
                            }
                        });
                        this.client.addComponent('const', constWin);
                    }
                    constWin.show();
                }
            });
        }
    },

    setClientConfigRF: function (config) {
        this.rxChannels = config.rx_channels;
        this.txChannels = config.tx_channels;
    },
});



Ext.define("lte.client.config.rf", {

    extend: 'Ext.window.Window',
    layout: {
        type: 'vbox',
        align: 'stretch'
    },
    width: 400,
    height: 500,

    constructor: function (config) {

        var list = this._list = [];
        config.txChannels.forEach(function (chan, idx) {
            list.push({
                freq: chan.freq,
                gain: chan.gain,
                chan: chan,
                title: 'TX' + idx
            });
        });
        config.rxChannels.forEach(function (chan, idx) {
            list.push({
                freq: chan.freq,
                gain: chan.gain,
                chan: chan,
                title: 'RX' + idx
            });
        });

        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        if (this.configurePower)
            this._addRefPower();
        this._addGains();

    },

    _addGains: function () {

        var ports = [];


        var addChan = (dir, chan, index) => {
            var port = ports[chan.port];
            if (!port) {
                port = ports[chan.port] = {
                    name: 'Port ' + chan.port,
                    chan: '',
                    expanded: true,
                    expandable: false,
                    iconCls: 'icon-comp',
                    children: [{
                        expanded: true,
                        expandable: false,
                        name: 'RX',
                        chan: 'rx',
                        children: []
                    }, {
                        expanded: true,
                        name: 'TX',
                        chan: 'tx',
                        expandable: false,
                        children: []
                    }]
                };
            }

            port.children[dir].children.push({
                name: '' + index,
                chan: [dir, index],
                gain: chan.gain,
                iconCls: 'icon-air',
                leaf: true
            });
            return {
                gain: chan.gain,
                chan: chan
            };
        };

        var allChannels = [
            this.rxChannels.map(addChan.bind(this, 0)),
            this.txChannels.map(addChan.bind(this, 1))
        ];
        var getChannel = (chan) => {
            if (chan instanceof Array)
                return allChannels[chan[0]][chan[1]];
            return null;
        };

        var edit = null;
        var grid = Ext.create('Ext.tree.Panel', {
            store: {
                fields: ['name', 'chan', 'gain'],
                root: {name: 'Ports', expanded: true, children: ports}
            },
            layout: 'fit',
            flex: 1,
            rootVisible: false,
            viewConfig:{markDirty: false},
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1,
                    listeners: {
                        scope: this,
                        beforeedit: function (a, b, c, d, e) {
                            edit = grid.getStore().getAt(b.rowIdx);
                            return typeof edit.get('chan') === 'object';
                        },
                        afteredit: function (a, b, c, d, e) {
                            edit = null;
                        }
                    }
                })
            ],
            columns: {
                defaults: {
                    menuDisabled: true,
                },
                items: [{
                    xtype: 'treecolumn',
                    text: 'Channel',
                    dataIndex: 'name',
                    width: 150,
                }, {
                    text: 'Frequency',
                    dataIndex: 'chan',
                    flex: 1,
                    renderer: function (chan, metaData, record, rowIndex, colIndex, store, view) {
                        chan = getChannel(chan);
                        if (chan)
                            return chan.chan.freq;
                    }
                }, {
                    text: 'Gain',
                    dataIndex: 'gain',
                    width: 65,
                    editor: {
                        xtype: 'numberfield',
                        maxValue: 100,
                        minValue: -100,
                        listeners: {
                            change: (me, gain) => {
                                if (gain !== null) {
                                    var chan = getChannel(edit.get('chan'));
                                    if (chan) {
                                        chan.gain = gain;
                                        update();
                                    }
                                }
                            }
                        }
                    },
                    renderer: function (gain, metaData, record, rowIndex, colIndex, store, view) {
                        var chan = record.get('chan');
                        switch (chan) {
                        case 'tx':
                            return "<div style=''>" +
                                "<span style='float: left; background-size: 10px;' data-action='minus' class='x-btn x-tree-icon icon-minus' title='Decrease'></span>" +
                                "<span style='float: left; background-size: 10px;' data-action='plus' class='x-btn x-tree-icon icon-plus' title='Increase'></span>" +
                                "</div>";
                        case 'rx':
                            return "<div style=''>" +
                                "<span style='float: left; background-size: 10px;' data-action='minus' class='x-btn x-tree-icon icon-minus' title='Decrease'></span>" +
                                "<span style='float: left; background-size: 10px;' data-action='plus' class='x-btn x-tree-icon icon-plus' title='Increase'></span>" +
                                "<span style='float: left; background-size: 10px;' data-action='auto' class='x-btn x-tree-icon icon-question' title='Auto'></span>" +
                                "</div>";
                        default:
                            chan = getChannel(chan);
                            if (chan) {
                                if (chan.auto)
                                    return 'AGC ' + ' (' + chan.gain + ')';
                                if (chan.gain !== chan.chan.gain)
                                    return chan.gain + ' (' + chan.chan.gain + ')';
                                return chan.gain;
                            }
                            break;
                        }
                    },
                }],
            },
            listeners: {
                scope: this,
                cellclick: function (view, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    switch (e.getTarget().getAttribute('data-action')) {
                    case 'plus':
                        record.childNodes.forEach(function (c) {
                            var ch = getChannel(c.get('chan'));
                            ch.auto = 0;
                            ch.gain++;
                        });
                        break;
                    case 'minus':
                        record.childNodes.forEach(function (c) {
                            var ch = getChannel(c.get('chan'));
                            ch.auto = 0;
                            if (ch.gain > 0) ch.gain--;
                        });
                        break;
                    case 'auto':
                        record.childNodes.forEach(function (c) {
                            var ch = getChannel(c.get('chan'));
                            ch.auto = 1;
                            ch.gain = -1;
                        });
                        break;
                    }
                    update();
                    view.refresh();
                },
            },
        });

        var update = () => {
            this.client.sendMessage({
                message: "rf_gain",
                rx_gain: allChannels[0].map( (chan) => { return chan.gain; }),
                tx_gain: allChannels[1].map( (chan) => { return chan.gain; }),
            }, updateCb);
        };
        var updateGet = () => {
            this.client.sendMessage({
                message: "rf_gain",
            }, updateCb);
        };
        var updateCb = (resp) => {
            if (resp.rx_gain) {
                for (var i = 0; i < resp.rx_gain.length; i++) {
                    this.rxChannels[i].gain = resp.rx_gain[i];
                }
            }
            if (resp.tx_gain) {
                for (var i = 0; i < resp.tx_gain.length; i++) {
                    this.txChannels[i].gain = resp.tx_gain[i];
                }
            }
            grid.view.refresh();
            if (this.powerUpdate)
                this.powerUpdate();
        };

        this.add(grid);
    },

    _addRefPower: function () {

        var store = Ext.create('Ext.data.Store', {
            fields: ['cell', 'type', 'power', 'curPower', 'manual'],
        });

        var edit = null;
        var grid = Ext.create('Ext.grid.Panel', {
            store: store,
            viewConfig: {markDirty: false},
            layout: 'fit',
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1,
                    listeners: {
                        scope: this,
                        beforeedit: function (a, b, c, d, e) {
                            edit = grid.getStore().getAt(b.rowIdx);
                            return true;
                        },
                        afteredit: function (a, b, c, d, e) {
                        }
                    }
                })
            ],
            columns: {
                items: [{
                    text: 'Cell',
                    dataIndex: 'cell',
                    flex: 1,
                }, {
                    text: 'Type',
                    dataIndex: 'type',
                    flex: 1,
                }, {
                    text: 'Reference power',
                    dataIndex: 'power',
                    flex: 2,
                    renderer: function (value, metaData, record, rowIndex, colIndex, store, view) {
                        var curPower = record.get('curPower');
                        if (record.get('manual')) {
                            if (value != curPower)
                                return value + ' (' + curPower + ')';
                            return value;
                        }
                        return curPower;
                    },
                    editor: {
                        xtype: 'numberfield',
                        maxValue: 100,
                        minValue: -100,
                        allowBlank: false,
                        listeners: {
                            change: (me, power) => {
                                if (power !== null)
                                    setPower(edit, power);
                            }
                        }
                    },
                }, {
                    text: 'Manual',
                    dataIndex: 'manual',
                    xtype: 'checkcolumn',
                    flex: 1,
                    listeners: {
                        scope: this,
                        checkchange: function(cc, index, ischecked, eOpts) {
                            var rec = store.getAt(index);
                            if (ischecked) {
                                setPower(rec, rec.get('power'));
                            } else {
                                setPower(rec, 'auto');
                            }
                        }
                    },
                }],
            },
            listeners: {
                scope: this,
            },
        });

        var cellCache = {};

        var setPower = (rec, power) => {
            rec.set('power', power);
            switch (rec.get('type')) {
            case 'LTE':
                var cell = { sib2: { reference_signal_power: power } };
                break;
            case 'NB-IoT':
                var cell = { sib2: { nrs_power_r13: power } };
                break;
            case 'NR':
                var cell = { sib1: { ss_pbch_block_power: power } };
                break;
            }
            var cells = {};
            cells[rec.get('cell')] = cell;
            this.client.sendMessage({
                message: 'sib_set',
                cells: cells,
            }, (resp) => {
                update();
            });
        };

        var updatePending = 0;
        var update = (retry) => {
            if (!updatePending)
                updateNow();
            updatePending = 15; // Poll for 15s
        };
        var updateNow = () => {
            this.client.sendMessage({ message: 'config_get' }, updateCb);
        };
        var updateCb = (resp) => {
            if (this._closed) return; // Fail safe

            var cells = [];
            if (resp.cells) {
                for (var id in resp.cells) {
                    var cell = resp.cells[id];
                    cells.push({
                        cell: id,
                        type: 'LTE',
                        curPower: cell.ref_signal_power,
                        manual: !!cell.manual_ref_signal_power,
                    });
                }
            }
            if (resp.nb_cells) {
                for (var id in resp.nb_cells) {
                    var cell = resp.nb_cells[id];
                    cells.push({
                        cell: id,
                        type: 'NB-IoT',
                        curPower: cell.nrs_power_r13,
                        manual: !!cell.manual_ref_signal_power,
                    });
                }
            }
            if (resp.nr_cells) {
                for (var id in resp.nr_cells) {
                    var cell = resp.nr_cells[id];
                    cells.push({
                        cell: id,
                        type: 'NR',
                        curPower: cell.ss_pbch_block_power,
                        manual: !!cell.manual_ref_signal_power,
                    });
                }
            }

            lteLogs.storeUpdate(cellCache, store, cells, 'cell', true, (cell, prev) => {
                if (prev && cell.manual) {
                    cell.power = prev.get('power');
                } else {
                    cell.power = cell.curPower;
                }
            });
            if (--updatePending > 0)
                setTimeout(updateNow, 1000);
        };
        this.powerUpdate = () => { update(); };
        update();

        this.add(grid);
    },

    listeners: {
        close: function () {
            this._closed = true;
        },
    },
});


Ext.define("lte.client.monitor", {

    extend: 'Ext.window.Window',
    layout: 'fit',
    width: 500,
    height: 500,

    constructor: function (config) {

        var client = config.client;

        this.globalConfig = lteLogs.localStorageGet('monitor');
        if (this.globalConfig) {
            Object.assign(config, this.globalConfig);
        } else {
            this.globalConfig = {};
        }

        this.callParent(arguments);
    },

    listeners: {
        activate: function () {
            this._term.setFocus();
        },
        deactivate: function () {
            this._term.unsetFocus();
        },
        close: function () {
            this._term.unsetFocus();
        },
        resize: function (me, w, h) {
            this.globalConfig.width =  w;
            this.globalConfig.height = h;
            this.saveConfig();
        }
    },

    saveConfig: function () {
        lteLogs.localStorageSet('monitor', this.globalConfig);
    },

    fontSizeMod: function (size, rel) {

        if (!size)
            return;

        if (rel)
            size += this._body.getStyle('font-size').replace('px', '') - 0;

        this._body.setStyle('font-size', size + 'px');
        this._body.setStyle('line-height', ((size * 1.25) >> 0) + 'px');
        this.globalConfig.fontSize = size;
        this.saveConfig();
        this._term.resize();
    },

    initComponent: function () {
        this.callParent(arguments);

        var client = this.client;
        var init = false;
        var body = null;

        this.add({
            layout: 'fit',
            bodyCls: 'term',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {
                    if (!init) {
                        init = true;
                        term.setParent(cont.body.el.dom);
                        term.resize(width, height);
                        term.show();
                        this._term = term;
                        this._body = cont.body;

                        this.fontSizeMod(this.globalConfig.fontSize);

                        this._body.el.dom.addEventListener('contextmenu', (function (event) {
                            var items = [{
                                text: 'Increase font',
                                scope: this,
                                iconCls: 'icon-plus',
                                handler: this.fontSizeMod.bind(this, 1, true),
                            }];
                            if (this.globalConfig.fontSize && this.globalConfig.fontSize > 5)
                                items.push({
                                    text: 'Decrease font',
                                    scope: this,
                                    iconCls: 'icon-minus',
                                    handler: this.fontSizeMod.bind(this, -1, true),
                                });

                            var menu = new Ext.menu.Menu({items: items});
                            menu.showAt([event.clientX, event.clientY]);
                            event.stopPropagation();
                            event.preventDefault();
                        }).bind(this));
                    } else {
                        term.resize(width, height);
                    }
                },
            }
        });

        var term = this._term = lteLogs.term = new Term({
            buffer_size: 1000,
            handler: function (str) {
                client.sendMessage({message: 'monitor', data: str});
            }
        });

        // Listen to incoming data
        client.setMessageHandler('monitor', function (msg) {
            if (msg.data) {
                term.write(msg.data);
            }
        });

        // Register
        this.clientStart = function () {
            term.write("***** Connected *****\n");
            client.sendMessage({message: 'register', register: 'monitor'});
        },
        this.clientStop = function () {
            term.write("\n***** Disconnected *****\n");
        },
        this.clientStart();
        lteLogs.setWindowAutoHeight(this);
    },
});

