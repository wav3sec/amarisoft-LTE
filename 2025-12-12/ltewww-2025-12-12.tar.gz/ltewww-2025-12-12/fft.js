/* FFT/IFFT over n elements (n must be power of two) */
function FFT(n, inverse)
{
    var i, n, tabw, alpha, n2;

    alpha = 2 * Math.PI / n;
    if (!inverse)
        alpha = -alpha;
    n2 = n >> 1;
    tabw = new Float32Array(n2 * 2);
    for(i = 0; i < n2; i++) {
        tabw[2 * i] = Math.cos(alpha * i);
        tabw[2 * i + 1] = Math.sin(alpha * i);
    }
    this.n = n;
    this.tabw = tabw;
}

/* tab is a Float32Array of n*2 elements. even elements are real parts,
   odd elements are imaginary parts. */
FFT.prototype.calc = function(tab)
{
    var tab_tmp, tab_in, tab_out, i, j, k, l, p, n, n2, tabw, tmp, k1, p1;
    var a0_re, a0_im, a1_re, a1_im;
    var b0_re, b0_im, b1_re, b1_im, w_re, w_im, c_re, c_im;
    
    tabw = this.tabw;
    n = this.n;
    n2 = n >> 1;

    tab_tmp = new Float32Array(n * 2);
    tab_out = tab_tmp;
    tab_in = tab;
    nb_blocks = n;
    fft_per_block = 1;
    while (nb_blocks != 1) {
        nb_blocks >>= 1;
        p = 0;
        k = 0;
        for(i = 0; i < nb_blocks; i++) {
            w_re = tabw[(i * fft_per_block) * 2];
            w_im = tabw[(i * fft_per_block) * 2 + 1];
            for(j = 0; j < fft_per_block; j++) {
                a0_re = tab_in[(k) * 2];
                a0_im = tab_in[(k) * 2 + 1];
                a1_re = tab_in[(k + n2) * 2];
                a1_im = tab_in[(k + n2) * 2 + 1];
                /* FFT of size 2 */
                b0_re = a0_re + a1_re;
                b0_im = a0_im + a1_im;
                b1_re = a0_re - a1_re;
                b1_im = a0_im - a1_im;
                /* multiply by W */
                c_re = b1_re * w_re - b1_im * w_im;
                c_im = b1_re * w_im + b1_im * w_re;
                tab_out[(p) * 2] = b0_re;
                tab_out[(p) * 2 + 1] = b0_im;
                tab_out[(p + fft_per_block) * 2] = c_re;
                tab_out[(p + fft_per_block) * 2 + 1] = c_im;
                k++;
                p++;
            }
            p += fft_per_block;
        }
        fft_per_block <<= 1;
        tmp = tab_in;
        tab_in = tab_out;
        tab_out = tmp;
    }

    if (tab_in != tab) {
        j = n * 2;
        for(i = 0; i < j; i++)
            tab[i] = tab_in[i];
    }
};

/* cache the FFT state */
var CachedFFT = function(tab, n, inverse)
{
    var index;
    index = 2 * n + inverse;
    if (!CachedFFT.fft_state[index]) {
        CachedFFT.fft_state[index] = new FFT(n, inverse);
    }
    CachedFFT.fft_state[index].calc(tab);
}

CachedFFT.fft_state={};
