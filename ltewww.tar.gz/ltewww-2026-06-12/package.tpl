{
    "name": "<NAME>",
    "version": "1.0.0",
    "main": "index.html",
    "single-instance": false,
    "window": {
        "title": "Amarisoft LTE",
        "icon": "amarisoft.png",
        "width": 1200,
        "height": 800
    },
    "chromium-args": "--enable-node-worker --disable-devtools"
}
