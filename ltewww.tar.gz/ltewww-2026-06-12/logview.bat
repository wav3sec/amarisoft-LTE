REM Modify nw.exe path according to your system
"C:\Program Files\nwjs\nw.exe" . app %~dp0 %*
