/*
 * Copyright (C) 2017-2026 Amarisoft
 */

Ext.define("lte.enb.tab", {

    extend: 'lte.client.tab',

    _chartList: [{
        title:        'Bitrate',
        fieldType:    ['dl_bitrate', 'ul_bitrate', 'mbms_bitrate'],
        unit:         'brate',
        serieStyle:   'font-size: 10px;',
    }, {
        title:        'TX/RETX',
        fieldType:    ['dl_tx', 'dl_retx', 'dl_bler', 'dl_per', 'ul_tx', 'ul_retx', 'ul_bler', 'ul_per'],
        unit:         ' pkt(s)',
        serieWidth:   300,
        serieStyle:   'font-size: 10px;',
    }, {
        title:        'UE',
        fieldType:    ['ue.dl_bitrate', 'ue.ul_bitrate', 'dl_mcs', 'ul_mcs', 'cqi', 'ri'],
        unit:         'brate',
        serieWidth:   300,
        serieStyle:   'font-size: 10px;',
    }, {
        title:        'Messages',
        fieldType:    ['messages'],
        serieWidth:   400,
        unit:         ''
    }, {
        title:        'Errors',
        fieldType:    ['errors'],
        serieWidth:   400,
        unit:         ''
    }],

    _fieldLabel: {
        'dl_bitrate': 'PHY DL bitrate',
        'ul_bitrate': 'PHY UL bitrate',
        'mbms_bitrate': 'PHY MBMS bitrate',
        'dl_mcs': 'DL MCS',
        'ul_mcs': 'UL MCS',
        'dl_tx': 'DL transmissions',
        'dl_retx': 'DL retransmissions',
        'ul_tx': 'UL transmissions',
        'ul_retx': 'UL retransmissions',
        'dl_bler': 'DL bler',
        'ul_bler': 'UL bler',
        'dl_per': 'DL per',
        'ul_per': 'UL per',
        'cqi': 'CQI',
        'ri': 'layers',
    },

    constructor: function (config) {

        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        this.tbar.add(Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip("Informations"),
            iconCls: "icon-info",
            text: 'Info',
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    var win = this.client.getComponent('enbInfo');
                    if (!win) {
                        win = Ext.create('lte.client.enb.info', {
                            title: this.client.getName() + ' informations',
                            client: this.client,
                            listeners: {
                                scope: this,
                                close: function () {
                                    this.client.removeComponent('enbInfo', true);
                                }
                            }
                        });
                        this.client.addComponent('enbInfo', win);
                    }
                    win.show();
                }
            }
        }));

        this.addRFConfig(['npusch', 'pusch'], true);


        this.tbar.add(Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip("NTN status"),
            iconCls: "icon-sat",
            text: 'NTN',
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    var win = this.client.getComponent('enb_ntn');
                    if (!win) {
                        win = Ext.create('lte.client.enb.ntn', {
                            title: this.client.getName() + ' NTN',
                            client: this.client,
                            listeners: {
                                scope: this,
                                close: function () {
                                    this.client.removeComponent('enb_ntn', true);
                                }
                            }
                        });
                        this.client.addComponent('enb_ntn', win);
                    }
                    win.show();
                }
            }
        }));


        var cellStore = this._cellStore = Ext.create('Ext.data.Store', {
            fields: ["cell_id", "n_rb_dl", "n_rb_ul", "dl_bitrate", "ul_bitrate"]
        });

        this.ueStore = Ext.create('Ext.data.Store', {
            fields: ['rnti', 'enb_ue_id', 'mme_ue_id', 'cells']
        });

        this.sumPanel = Ext.create('Ext.panel.Panel', {
            border: 0,
            html: 'UEs: 0',
            width: 55,
        });

        this._filterList = [
            { param: 'dl_bitrate', text: 'DL bitrate' },
            { param: 'ul_bitrate', text: 'UL bitrate' },
        ];
        this._filterList.forEach( (f) => { f.value = f.text; }); // For combo template

        this.filterCombo = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel: '',
            queryMode: 'local',
            valueField: 'param',
            value: '',
            displayField: 'text',
            multiSelect: false,
            width: 100,
            labelSeparator: '',
            store: Ext.create('Ext.data.Store', {
                fields: ['param', 'text'],
                data: [{ param: '', text: 'Filter...', value: '' }].concat(this._filterList),
            }),

            tpl: Ext.create('Ext.XTemplate',
                '<tpl for=".">',
                '{value:this.valueRenderer}</div>',
                '</tpl>', {
                valueRenderer: function (v, rec) {
                    var txt = v ? v : 'None';
                    return '<div class="x-boundlist-item">' + txt + '</div>';
                }
            }),
            listeners: {
                scope: this,
                change: function(combo, newValue, oldValue, eOpts) {
                    this.setFilter(newValue);
                }
            },
        });

        this.filterValue = Ext.create({
            xtype: 'numberfield',
            value: 0,
            minValue: 0,
            hidden: true,
            width: 100,
        });

        this.selectedRNTI = null;
        this.ueGrid = Ext.create('Ext.grid.Panel', {
            store: this.ueStore,
            allowDeselect: true,
            viewConfig: { markDirty: false },
            tbar: [ this.sumPanel, '|', this.filterCombo, this.filterValue ],
            columns: {
                defaults: {
                    menuDisabled: true,
                    flex: 1,
                    align: 'right',
                },
                items: [{
                    text: 'UE ID',
                    dataIndex: 'enb_ue_id',
                }, {
                    text: 'RNTI',
                    dataIndex: 'rnti',
                    renderer: function(rnti, metaData, record, rowIndex, colIndex, store, view) {
                        return '0x' + rnti.toString(16);
                    }
                }, {
                    text: 'Cells',
                    dataIndex: 'cells',
                    flex: 0.8,
                    renderer: (cells, metaData, record, rowIndex, colIndex, store, view) => {
                        return cells.map((c) => { return this._getCell(c.cell_id).getName(); }).join(",");
                    },
                }, {
                    text: 'Core ID',
                    dataIndex: 'mme_ue_id',
                    renderer: (mme_ue_id) => {
                        return mme_ue_id ? mme_ue_id.toString(16) : '-';
                    },
                }, {
                    text: 'Filter',
                    hidden: true,
                    dataIndex: 'rnti',
                    flex: 4,
                    renderer: (rnti, metaData, record, rowIndex, colIndex, store, view) => {
                        var stats = this.statsCache[rnti];
                        if (stats) {
                            var value = stats[this._filter.param];
                            if (value !== undefined) {
                                switch (this._filter.param) {
                                case 'dl_bitrate':
                                case 'ul_bitrate':
                                    value = lteLogs.format1000(value, 3, 'bps', 'kbps', 'mbps');
                                    break;
                                }
                                return value;
                            }
                        }
                        return '';
                    },
                }],
            },
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {
                    if (selected.length) {
                        this.selectedRNTI = selected[0].get('rnti')
                        this.ueChart.comp.reset();
                        this.ueChart.tab.setVisible(true);
                    } else {
                        this.selectedRNTI = null;
                        this.ueChart.tab.setVisible(false);
                    }
                },

                // UE right click menu
                cellcontextmenu: function(view, td, cellIndex, record, tr, rowIndex, e, eOpts) {

                    var items = [];
                    var ue_data = record.getData();
                    var cell_id = ue_data.cells[0].cell_id;
                    for (var i = 0, count = cellStore.getCount(); i < count; i++) {
                        var cell_data = cellStore.getAt(i).getData();
                        if (cell_data.cell_id === cell_id) continue;

                        items.push({
                            text: 'Handover to cell ' + this._getCell(cell_data.cell_id).getName(),
                            scope: this,
                            iconCls: 'icon-air',
                            handler: (function(msg) {
                                this.client.sendMessage(msg, (function (r) {
                                    this._updater.update(true);
                                }).bind(this));
                            }).bind(this, {
                                message: 'handover',
                                enb_ue_id: ue_data.enb_ue_id,
                                pci: cell_data.cell_id,
                                dl_earfcn: cell_data.dl_earfcn
                            })
                        });
                    }

                    if (items.length) {
                        var menu = new Ext.menu.Menu({items: items});
                        var position = e.getXY();
                        e.stopEvent();
                        menu.showAt(position);
                    }
                },
            }
        });

        this.ueCache = {};
        this.statsCache = {};

        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            //autoDelay:        5000,
            dirty:            true,
            lock:            1,
            handler:        function () {
                this.client.sendMessage({message: 'ue_get', stats: !!this._filter}, this.ueGet.bind(this, this._filter));
            },
        });

        this.statsRFSamplesInit();

        this.add({
            region: 'west',
            layout: 'fit',
            split: true,
            width: 320,
            items: [this.ueGrid],
        });

        this.add({
            split: true,
            layout: 'fit',
            region: 'center',
            items: [this.getChartPanel(this._statsChart)],
        });

        this.ueChart = this._field2chart['ue.dl_bitrate'];
        this.ueChart.tab = this._chartPanel.tabBar.getComponent(this.ueChart.index);
        this.ueChart.tab.setVisible(false);
    },

    setFilter: function (param) {

        this._filter = this._filterList.find( (f) => { return f.param === param });
        var visible = !this._filter;

        var grid = this.ueGrid;
        grid.columns[1].setVisible(visible);
        grid.columns[3].setVisible(visible);
        grid.columns[4].setVisible(!visible);
        this.filterValue.setVisible(!visible);
        if (!visible)
            grid.columns[4].setText(this._filter.text);
    },

    ueGet: function (filter, msg) {

        var ue_list = msg.ue_list;
        if (filter) {
            var value = this.filterValue.getValue();
            ue_list = ue_list.filter( (ue) => {
                var stats = this.ueBuildStats(ue, msg.time);
                if (stats[filter.param] < value)
                    return false;
                return true;

            });
        }

        ue_list.forEach((ue) => {
            if (ue.ran_ue_id !== undefined) ue.enb_ue_id = ue.ran_ue_id;
            if (ue.amf_ue_id !== undefined) ue.mme_ue_id = ue.amf_ue_id;
        });

        // Update store
        lteLogs.storeUpdate(this.ueCache, this.ueStore, ue_list, 'rnti');

        var statsCache = {};
        msg.ue_list.forEach((ue) => {
            statsCache[ue.rnti] = this.statsCache[ue.rnti];
        });
        this.statsCache = statsCache;

        this.sumPanel.update('UEs: ' + ue_list.length);

        if (this.selectedRNTI === null || filter) return;

        var rec = this.ueCache.records[this.selectedRNTI];
        if (rec) {
            this.client.sendMessage({message: 'ue_get', ue_id: rec.get('enb_ue_id'), stats: true}, (msg) => {
                this.ueBuildStats(msg.ue_list[0], msg.time);
            });
        }
    },

    ueBuildStats: function (ue, time) {

        var stats0 = this.statsCache[ue.rnti];
        var stats = this.statsCache[ue.rnti] = {
            dl_bitrate: 0,
            ul_bitrate: 0,
            dl: 0,
            ul: 0,
            series: stats0 ? stats0.series : {},
            time: time,
        };

        var list = ue.erab_list || ue.qos_flow_list;
        if (list) {
            for (var i = 0; i < list.length; i++) {
                var erab = list[i];
                stats.dl += erab.dl_total_bytes;
                stats.ul += erab.ul_total_bytes;
            }

            if (stats0) {
                stats.dl_bitrate = 8 * (stats.dl - stats0.dl) / (time - stats0.time);
                stats.ul_bitrate = 8 * (stats.ul - stats0.ul) / (time - stats0.time);
            }
        }

        if (ue.rnti === this.selectedRNTI)
            this.updateSelectedUE(ue, stats);

        return stats;
    },

    // On selected UE
    updateSelectedUE: function (ue, stats) {

        var ue_id = ue.enb_ue_id;
        var now = new Date() * 1;
        var comp = this.ueChart.comp;
        var series = stats.series;

        if (stats.dl_bitrate !== undefined) {
            var id = ue_id + '-bitrate';
            if (!series[id]) {
                comp.addSerie(id + '-dl', {title: 'UE #' + ue_id + ', DL PDCP'});
                comp.addSerie(id + '-ul', {title: 'UE #' + ue_id + ', UL PDCP'});
                series[id] = true;
            }
            comp.addValues(id + '-dl', [{x: now, y: stats.dl_bitrate}]);
            comp.addValues(id + '-ul', [{x: now, y: stats.ul_bitrate}]);
        }

        ue.cells.forEach((cell) => {
            var id = ue_id + '-' + cell.cell_id;

            if (!series[id]) {
                var prefix = 'UE #' + ue_id + ', cell ' + this._getCell(cell.cell_id).getName();
                comp.addSerie(id + 'dl_bitrate', {title: prefix + ' DL PHY'});
                comp.addSerie(id + 'ul_bitrate', {title: prefix + ' UL PHY'});
                comp.addSerie(id + 'dl_mcs', {title: prefix + ' DL MCS', y: ['z']});
                comp.addSerie(id + 'ul_mcs', {title: prefix + ' UL MCS', y: ['z']});
                comp.addSerie(id + 'cqi', {title: prefix + ' CQI', y: ['z']});
                comp.addSerie(id + 'ri', {title: prefix + ' RI', y: ['z']});
                comp.addSerie(id + 'pusch_snr', {title: prefix + ' PUSCH SNR', y: ['z']});
                series[id] = true;
            };

            comp.addValues(id + 'dl_bitrate', [{x: now, y: cell.dl_bitrate}]);
            comp.addValues(id + 'ul_bitrate', [{x: now, y: cell.ul_bitrate}]);
            if (cell.dl_mcs) comp.addValues(id + 'dl_mcs', [{x: now, z: cell.dl_mcs}]);
            if (cell.ul_mcs) comp.addValues(id + 'ul_mcs', [{x: now, z: cell.ul_mcs}]);
            if (cell.ri !== undefined) comp.addValues(id + 'ri', [{x: now, z: cell.ri}]);
            if (cell.cqi !== undefined) comp.addValues(id + 'cqi', [{x: now, z: cell.cqi}]);
            if (cell.pusch_snr !== undefined) comp.addValues(id + 'pusch_snr', [{x: now, z: cell.pusch_snr}]);
        });
        comp.update();
    },

    setClientConfig: function (config) {
        // Better access
        var client = this.client;
        var data = client.getCellIds().map((function (id) { return client.getCell(id); }).bind(this));
        if (data.length > 0) {
            this._cellStore.setData(data);
        }

        this.setClientConfigRF(config);
    },

    _getCell: function (cell_id) {
        return this.client.getCell(cell_id);
    },

    _cellsStatsUpdate: function (chart, cells, now, global) {

        chart.fieldType.forEach((field) => {

            var total = 0;
            var count = 0;
            var comp  = chart.comp;
            var g     = global;

            for (var cell_id in cells) {
                var cell = cells[cell_id];
                switch (field) {
                case 'dl_bler':
                    if (!cell.dl_tx && !cell.dl_retx) continue;
                    value = cell.dl_retx / (cell.dl_tx + cell.dl_retx);
                    var y = 'bler';
                    g = false;
                    break;
                case 'ul_bler':
                    if (!cell.ul_tx && !cell.ul_retx) continue;
                    value = cell.ul_retx / (cell.ul_tx + cell.ul_retx);
                    var y = 'bler';
                    g = false;
                    break;
                case 'dl_per':
                    if (!cell.dl_tx && !cell.dl_err) continue;
                    value = cell.dl_err / (cell.dl_tx + cell.dl_err);
                    var y = 'bler';
                    g = false;
                    break;
                case 'ul_per':
                    if (!cell.ul_tx && !cell.ul_err) continue;
                    value = cell.ul_err / (cell.ul_tx + cell.ul_err);
                    var y = 'bler';
                    g = false;
                    break;
                default:
                    var y = 'y';
                    var value = cell[field];
                    break;
                }
                if (value === undefined) continue;

                var clientCell = this._getCell(cell_id);
                if (!clientCell) continue;

                var id = cell_id + "-" + field;
                var v = { x: now };
                v[y] = value;
                comp.addSerie(id, {
                    title: "Cell " + clientCell.getName() + " " + (this._fieldLabel[field] || field),
                    values: [v],
                    y: [y],
                });
                total += value;
                count++;
            };

            if (g && count) {
                comp.addSerie(field, {
                    title: 'Global ' + field,
                    values: [{x: now, y: total}]
                });
            }
            comp.update();
        });
    },

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var now = new Date() * 1;
            var cells = event.data.cells;
            var global = Object.keys(cells).length > 1;
            this._cellsStatsUpdate(this._chartList[0], cells, now, global);
            this._cellsStatsUpdate(this._chartList[1], cells, now, global);
            this.statsRFSamplesFeed(event);
            this._updateCounters(now, event.data.counters);
            var ntn = this.client.getComponent('enb_ntn');
            if (ntn) {
                ntn.update();
            }

            this._updater.update(true);
            break;
        }
    },
});


Ext.define("lte.client.enb.info", {

    extend: 'Ext.window.Window',
    layout: 'fit',
    width: 400,
    height: 600,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var ports = [];

        var addNode = function (list, cell, name, param) {
            list.push({
                name: name,
                param: param,
                cell: cell,
                type: name.toLowerCase(),
                leaf: true,
            });
        };
        var getValue = function (cell, param) {
            if (cell) {
                if (typeof param === 'string')
                    return cell[param];
                if (typeof param === 'function')
                    return param(cell);
            }
            return null;
        };

        var cells = this.client.getCells().map(function (cell) {
            var children = [];
            addNode(children, cell, 'Mode', 'mode');
            addNode(children, cell, 'Physical cell id', 'pci');
            addNode(children, cell, 'Antenna', function (cell) { return cell.n_antenna_dl + 'T' + cell.n_antenna_ul + 'R'; });
            addNode(children, cell, 'Layers', function (cell) { return 'DL: ' + cell.n_layer_dl + ', UL: ' + cell.n_layer_ul; });
            switch (cell.rat) {
            case 'lte':
                addNode(children, cell, 'DL EARFCN', 'dl_earfcn');
                addNode(children, cell, 'UL EARFCN', 'ul_earfcn');
                break;
            case 'nbiot':
                addNode(children, cell, 'DL EARFCN', 'dl_earfcn');
                addNode(children, cell, 'UL EARFCN', 'ul_earfcn');
                break;
            case 'nr':
                addNode(children, cell, 'DL ARFCN', 'dl_nr_arfcn');
                addNode(children, cell, 'UL ARFCN', 'ul_nr_arfcn');
                break;
            }

            addNode(children, cell, 'Gain', 'gain');

            return {
                name: 'Cell #' + cell.cell_id + (cell.label ? ', ' + cell.label : ''),
                expandable: true,
                expanded: false,
                cell: cell,
                iconCls: 'icon-comp',
                param: 'rat',
                children: children,
            };
        });

        var client = this.client;
        var edit = null;
        var grid = this._grid = Ext.create('Ext.tree.Panel', {
            store: {
                fields: ['name', 'param', 'cell', 'type'],
                root: {
                    name: '',
                    expanded: true,
                    children: [{
                        name: 'Cells',
                        expanded: true,
                        children: cells
                    }]
                }
            },
            rootVisible: false,
            viewConfig:{markDirty: false},
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1,
                    listeners: {
                        scope: this,
                        beforeedit: function (a, b, c, d, e) {
                            edit = grid.getStore().getAt(b.rowIdx);
                            switch (edit.get('type')) {
                            case 'gain':
                                return true;
                            }
                            return false;
                        },
                        afteredit: function (a, b, c, d, e) {
                            edit = null;
                        }
                    }
                })
            ],
            columns: {
                defaults: {
                    menuDisabled: true,
                },
                items: [{
                    xtype: 'treecolumn',
                    text: 'Information',
                    dataIndex: 'name',
                    width: 250,
                }, {
                    text: 'Value',
                    dataIndex: 'value',
                    flex: 1,
                    renderer: function(param, metaData, rec, rowIndex, colIndex, store, view) {
                        var v = getValue(rec.get('cell'), rec.get('param'));
                        if (v !== null)
                            return v;
                        return '&nbsp;'
                    },
                    getEditor: function (rec) {
                        var cell = rec.get('cell');
                        switch (rec.get('type')) {
                        case 'gain':
                            return {
                                xtype: 'numberfield',
                                maxValue: 0,
                                minValue: -200,
                                value: cell.gain,
                                listeners: {
                                    scope: this,
                                    change: function (me, value) {
                                        client.sendMessage({
                                            message: "cell_gain",
                                            cell_id: rec.get('cell').cell_id,
                                            gain: value
                                        });
                                        cell.gain = value;
                                    }
                                },
                            };
                            break;
                        }
                    },
                }],
            },
            listeners: {
                scope: this,
            },
        });
        this.add(grid);
        lteLogs.setWindowAutoHeight(this);
        this._listenerId = client.registerEventListener('*', this._eventListener.bind(this));
    },

    _eventListener: function (event) {
    },

    listeners: {
        close: function () {
            this.client.unregisterEventListener(this._listenerId);
        },
    },
});

Ext.define("lte.client.enb.ntn", {

    extend: 'Ext.window.Window',
    width: 1460,
    height: 620,
    resizable: false,

    constructor: function (config) {
        this.callParent(arguments);
    },

    update: function () {
        this.client.sendMessage({message: 'ntn_stats', cell_id: this.client.getCellIds()[this._cell_idx] | 0},
                                this.ntnGet.bind(this), this.ntnError.bind(this));
        this._draw();
        this._enbPanel.update();
        this._uePanel.update();
        this._dtcPanel.update();
    },

    ntnError: function(error) {
        this._sat = this._enbPos = {longitude : 0, latitude : 0};   /* Avoid undefined values in generic draw */
        this._uePanel.setVisible(false);
        this._dtcPanel.setVisible(false);
        this._enbPanel.setVisible(false);
        this._errorPanel.setHtml('    ' + error);
        this._errorPanel.setVisible(true);
    },

    ntnGet: function(msg) {
        this._errorPanel.setVisible(false);
        this._sat = msg.satellite;
        this._enbPos = msg.enb;
        this._enbPanel.setGroundInfo(msg.enb);
        this._enbPanel.setVisible(true);
        this._uePos = msg.csim_ue;
        this._beamPos = msg.em_beam;
        if (this._uePos) {
            this._uePanel.setVisible(true);
            this._uePanel.setGroundInfo(msg.csim_ue);
        } else {
            this._uePanel.setVisible(false);
        }
        this._dtcPos = msg.direct_to_cell;
        if (this._dtcPos) {
            if (!this._uePos) {
                this._dtcPanel.setVisible(true);
                this._dtcPanel.setGroundInfo(msg.direct_to_cell);
            } else {
                this._dtcPanel.setVisible(false);
                this._uePanel.addDtCInfo(msg.direct_to_cell);
            }
        } else {
            this._dtcPanel.setVisible(false);
        }
    },

    initComponent: function () {
        this.callParent(arguments);
        
        this._zoom = 6;
        this._centerObject = 0;
        this._centerButtonText = ['Center: sat', 'Center: eNB', 'Center: UE', 'Center: DtC'];
        this._cell_idx = 0;
        this._worldView = new LTEWorldView({zoom: 1, zoomFactor: this._zoom});

        /* Canvas to draw the world map */
        this._worldPanel = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            tbar: [
                { xtype: 'button', 
                  scope: this,
                  iconCls: 'icon-plus',
                  tooltip: lteLogs.tooltip('Zoom in'),
                  handler: function (b, e) {
                    if (this._zoom < 12)
                        this._zoom++;
                  }
                },
                { xtype: 'button', 
                  scope: this,
                  iconCls: 'icon-minus',
                  tooltip: lteLogs.tooltip('Zoom out'),
                  handler: function (b, e) {
                    if (this._zoom > 0)
                        this._zoom--;
                  }
                },
                { xtype: 'button',
                  scope: this,
                  iconCls: 'icon-zoom',
                  text: this._centerButtonText[0],
                  tooltip: lteLogs.tooltip('Toggle center object : sat, eNB, UE, dTC'),
                  handler: function (b, e) {
                    this._centerObject = (this._centerObject + 1) % 4;
                    b.setText(this._centerButtonText[this._centerObject]);
                  }
                },
                { xtype: 'displayfield',
                  text: 'Cell index:'
                },
                { xtype: 'numberfield',
                  width: 50,
                  value: this._cell_idx,
                  step: 1,
                  maxValue: this.client.getCellIds().length,
                  minValue: 0,
                  tooltip: lteLogs.tooltip("Select cell of interest"),
                  listeners: {
                    scope: this,
                    change: function(num, newValue, oldValue, eOpts) {
                      if (newValue < this.client.getCellIds().length && newValue >= 0) {
                        this._cell_idx = newValue;
                      }
                    }
                  }
                }
            ],
            listeners: {
                scope: this,
                boxready: function(comp, width, height, eOpts) {
                    var canvas = this._worldPanel.el.down("canvas").dom;
                    canvas.height = 500;
                    canvas.width = 700;
                    this._worldView.setCanvas(canvas);
                },
                resize: function(cont, width, height) {
                }
            },
        });

        this._errorPanel = Ext.create('Ext.panel.Panel',
          {
                visible: false,
                html: '',
          });
        this._enbPanel = Ext.create('lte.client.enb.ntn_ground_info',
          {
            title: "eNB",
          });
        this._uePanel = Ext.create('lte.client.enb.ntn_ground_info',
          {
            title: "UE",
          });
         this._dtcPanel = Ext.create('lte.client.enb.ntn_ground_info',
          {
            title: "Direct-To-Cell",
          });
            
        this._groundInfoPanel = Ext.create('Ext.panel.Panel', {
          layout: 'vbox',
          items: [this._enbPanel, this._uePanel, this._dtcPanel, this._errorPanel]
        });

        this.add(
        {
            layout: {
                type: 'hbox',
                align: 'center'
            },
            items: [this._worldPanel, this._groundInfoPanel]
        });
    },

    _cacheImage: function(img, name) {
        var img_local = this[img];
        if (!img_local) {
            img_local = this[img] = new Image();
            img_local.src = "resources/images/" + name;
        }
        return img_local;
    },

    _drawObject: function(img, ctx, pos) {
        var c = this._worldView.llaToZoomCoord(pos);
        ctx.drawImage(img, c.x-16, c.y-16, 32, 32);
        ctx.fillText(pos.latitude.toPrecision(5) + " , " + pos.longitude.toPrecision(5), c.x-16, c.y-25);
    },

    _draw: function() {
        var canvas = this._worldPanel.el.down("canvas").dom;
        var ctx = canvas.getContext("2d");
        var pos = undefined;
        switch(this._centerObject) {
            case 0:
              pos = this._sat;
              break;
            case 1:
              pos = this._enbPos;
              break;
            case 2:
              pos = this._uePos;
              break;
            case 3:
              pos = this._dtcPos;
              break;
        }
        if (!pos){
            return;
        }
        this._worldView.setCanvas(canvas);
        var center = this._worldView.llaToCoord(pos);
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        this._worldView.setZoom(1, center);
        this._worldView.setZoomFactor(Math.pow(1.3, this._zoom));
        this._worldView.drawBackground();
        
        ctx.font = "bold 15px sans-serif";
        ctx.fillStyle = "grey";
        var sat_img = this._cacheImage('sat', 'sat.png');
        this._drawObject(sat_img, ctx, this._sat);

        var enb_img = this._cacheImage('enb', 'air.png');
        this._drawObject(enb_img, ctx, this._enbPos);

        if (this._uePos) {
            var ue_img = this._cacheImage('ue', 'ue.png');
            this._drawObject(ue_img, ctx, this._uePos);
        }
        if (this._dtcPos) {
            var dtc_img = this._cacheImage('dtc', 'ue2.png');
            this._drawObject(dtc_img, ctx, this._dtcPos);
        }
        if (this._beamPos) {
            ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
            this._worldView.drawCell(this._beamPos, this._beamPos.radius);
        }
            
    }
});

Ext.define("lte.client.enb.ntn_ground_info", {
    extend: 'Ext.panel.Panel',

    constructor: function (config) {
        this.callParent(arguments);
        this.header = {
            padding: "4 10 4"
        };
        this.height = 285;
        this.border = false;
    },

    initComponent: function() {
        this.callParent(arguments);

        this._skyView = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            border: '2',
            width: 260,
            height: 260,
            //align: 'center',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {
                }
            }
        });
        

        this._dataPanel = Ext.create('Ext.form.Panel', {
            title: 'Data',
            header: false,
            border: false,
            bodyPadding: "10",
            width: 500,
            layout: {
              type: 'vbox',
            },
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'Distance (km)',
                labelWidth: 150,
                name: 'distance',
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Azimuth (deg)',
                labelWidth: 150,
                name: 'azimuth',
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Elevation (deg)',
                labelWidth: 150,
                name: 'elevation',
            }, {
                xtype: 'displayfield',
                fieldLabel: 'DL doppler (kHz)',
                labelWidth: 150,
                name: 'dl_doppler',
            }, {
                xtype: 'displayfield',
                fieldLabel: 'UL doppler (kHz)',
                labelWidth: 150,
                name: 'ul_doppler',
            }]
        });

        this.add(
        {  
          layout: {
            type: 'hbox',
            align: 'center'
          },
          items: [this._skyView, this._dataPanel],
        });
    },

    setGroundInfo: function(gi) {
        var d = gi.distance*0.001;
        var field = this._dataPanel.getForm().findField('distance')
        if (this._dtcInfo) {
            var diff = d - this._dtcInfo.distance*0.001;
            if (diff < 0) {
                field.setFieldStyle("color:orange");
            } else {
                field.setFieldStyle("color:black");
            }
            field.setValue(d.toPrecision(5)+ " (DtC " + (diff<0?"":"+") + diff.toPrecision(4)+")");
        } else {
            field.setValue(d.toPrecision(5));
        }
        this._elevation = gi.elevation.toPrecision(4);
        field = this._dataPanel.getForm().findField('elevation');
        if (this._elevation < 0) {
            field.setFieldStyle("color:red");
        } else if (this._elevation < 20) {
            field.setFieldStyle("color:orange");
        } else {
            field.setFieldStyle("color:black");
        }
        field.setValue(this._elevation);
        this._azimuth = gi.azimuth.toPrecision(4);
        this._dataPanel.getForm().findField('azimuth').setValue(this._azimuth);
        d = gi.dl_doppler*0.001;
        field = this._dataPanel.getForm().findField('dl_doppler');
        if (this._dtcInfo) {
            var diff = d - this._dtcInfo.dl_doppler*0.001;
            field.setValue(d.toPrecision(4)+ "  (DtC " + (diff<0?"":"+") + diff.toPrecision(4)+")");
        } else {
            field.setValue(d.toPrecision(4));
        }
        d = gi.ul_doppler*0.001;
        field = this._dataPanel.getForm().findField('ul_doppler');
         if (this._dtcInfo) {
            var diff = d - this._dtcInfo.ul_doppler*0.001;
            field.setValue(d.toPrecision(4)+ "  (DtC " + (diff<0?"":"+") + diff.toPrecision(4)+")");
        } else {
            field.setValue(d.toPrecision(4));
        }
    },

    addDtCInfo: function(dtci) {
        this._dtcInfo = dtci;
    },

    update: function() {
        this._draw();
    },

    _elProject: function (el) {
        //return Math.cos(el);
        return ((Math.PI - 2*el)/Math.PI);
    },

    _draw: function() {
        var canvas = this._skyView.el.down("canvas").dom;
        var ctx = canvas.getContext("2d");
        var s = 120;
        var o = 10;
        var el = (this._elevation * Math.PI) / 180.0;
        var az = (this._azimuth * Math.PI) / 180.0;
        var x = s+o + s*(this._elProject(el) * Math.sin(az));
        var y = s+o - s*(this._elProject(el) * Math.cos(az));
        var sat_img = this._sat_img;
        if (!sat_img) {
            var sat_img = this._sat_img = new Image();
            sat_img.src = "resources/images/sat.png";
        }

        canvas.width = 2*(s + o);
        canvas.height = 2*(s + o);
        /* Draw background */
        ctx.lineWidth = 2;
        ctx.strokeStyle = 'black';
        ctx.fillStyle= 'grey';
        ctx.beginPath();
        ctx.arc(s+o, s+o, s, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.fill();
        ctx.fillStyle= 'white';
        ctx.beginPath();
        ctx.arc(s+o, s+o, s*this._elProject(Math.PI/9), 0, 2 * Math.PI);
        ctx.fill();
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(s+o, s+o, s*this._elProject(Math.PI/6), 0, 2 * Math.PI);
        ctx.arc(s+o, s+o, s*this._elProject(Math.PI/3), 0, 2 * Math.PI);
        ctx.moveTo(o, s+o);
        ctx.lineTo(2*s+o, s+o);
        ctx.moveTo(s+o, o);
        ctx.lineTo(s+o, 2*s+o);
        ctx.stroke();

        /* Draw sat */
        if (this._elevation > 0) {
            ctx.drawImage(sat_img, x-16, y-16, 32, 32); 
        }
    }
});


        

     
     
 


