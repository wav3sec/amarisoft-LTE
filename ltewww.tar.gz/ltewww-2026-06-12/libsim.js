/*
 * Copyright (C) 2012-2026 Amarisoft
 *
 * Amarisoft Web interface 2026-06-12
 */
const MAX_DURATION = 3600 * 24 * 7;
const UE_SCENARIO_VERSION = 1;

// XXX: push in libSim
const UEConfig = {
    series: {
        br: {
            dl_bitrate: {title: '#<cell> DL bitrate'},
            ul_bitrate: {title: '#<cell> UL bitrate'},
        },
        sched: {
            dl_sched_users_min: {title: "#<cell> DL min users / TTI", enabled: false},
            dl_sched_users_avg: {title: "#<cell> DL average users / TTI"},
            dl_sched_users_max: {title: "#<cell> DL max users / TTI", enabled: false},
            ul_sched_users_min: {title: "#<cell> UL min users / TTI", enabled: false},
            ul_sched_users_avg: {title: "#<cell> UL average users / TTI"},
            ul_sched_users_max: {title: "#<cell> UL max users / TTI", enabled: false},
        },
        count: {
            ue_count: {title: '#<cell> UE count', y: ['z']},
        },
        packets: {
            dl_rx_count: {title: '#<cell> DL rx'},
            dl_err_count: {title: '#<cell> DL errors'},
            dl_bler: {title: '#<cell> DL BLER', y: ['bler']},
            ul_tx_count: {title: '#<cell> UL tx'},
            ul_retx_count: {title: '#<cell> UL retx'},
        },
        signal: {
            cfo: { title: '#<cell> Center Frequency Offset' },
        },
        signalue: {
            rsrp: { title: '<UE> RSRP' },
            rsrq: { title: '<UE> RSRQ' },
            snr: { title: '<UE> SNR' },
        },
    },

    setSerie: function (chart, serie, cells, y) {

        serie = this.series[serie];

        for (var cell_index in cells) {
            for (var id in serie) {
                var cfg = lteLogs.clone(serie[id]);
                if (!cfg.y && y) {
                    cfg.y = [y];
                }
                cfg.title = cfg.title.replace(/<cell>/, cell_index);
                chart.addSerie(id + '.' + cell_index, cfg);
            }
        }
    },
};

var lteSim = {

    sections: {name: 'New scenario', ue: {}, chan: {}, power: {}, scripts: [], pdn: [], loop: 0, start_delay: 0 /* multi */},

    ipDefinitionList: [
        {type: 'ping',     name: 'ICMP PING',      msg: 'ping',    fields: {payload_len: 1000, delay: 1, dst_addr: '192.168.3.1', apn: ''}},
        {type: 'udp',      name: 'UDP',            msg: 'cbr',     fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '192.168.3.1', direction: 'dl', apn: ''}},
        {type: 'rtp',      name: 'RTP',            msg: 'cbr',     fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '192.168.3.1', direction: 'dl', apn: ''}},
        {type: 'voip',     name: 'VOIP',           msg: 'cbr',     fields: {payload_len: 31, bit_rate: 12400, dst_addr: '192.168.3.1', direction: 'all', mean_talking_duration: 2, vaf: 50, apn: ''}},
        {type: 'flood',    name: 'Flood',          msg: 'flood',   fields: {payload_len: 1000, dst_addr: '192.168.3.1', direction: 'dl', apn: ''}},
        {type: 'tcp',      name: 'TCP',            msg: 'tcp',     fields: {dst_addr: '192.168.3.1', direction: 'all', apn: '', connections: 1, threshold: 1000000}},
        {type: 'http',     name: 'HTTP transfert', msg: 'http',    fields: {url: 'http://192.168.3.1:8080/data?size=10000', max_delay: 1, max_cnx: 1000, apn: ''}},
        {type: 'ethernet', name: 'Ethernet',       msg: 'cbr',     fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '00:00:00:00:00:00', direction: 'dl', apn: 'ethernet'}},
        {type: 'app',      name: 'Application',    msg: 'ext_app', fields: {prog: 'ext_app.sh', args: "iperf -c 192.168.2.1 -i 1 -d -t $d", tag: 'iperf', apn: ''}},
        //{type: 'register', name: 'Registration', msg: 'register', fields: {}, noIp: true},
    ],

    getIpDefinition: function (type) {
        for (var i = 0; i < this.ipDefinitionList.length; i++) {
            var def = this.ipDefinitionList[i];
            if (type === def.type)
                return def;
        }
        return null;
    },

    MAX_DISTANCE: 100 * 1000,

    // Random generation
    'random': {
        'gen': function gen(value, variability, min, max) {
            if (variability) {
                value = Math.random() * variability * 2 + value - variability;
            }
            if (!isNaN(min))
                value = Math.max(min, value);
            if (!isNaN(max))
                value = Math.min(max, value);
            return value;
        },

        'genInt': function (value, variability) {
            return Math.round(this.gen(value, variability));
        },

        'genRange': function (min, max) {
            return (Math.random() * (max - min) + min);
        },

        'genIntRange': function (min, max) {
            return Math.round(this.genRange(min, max));
        },

        'genTime': function (value, variability) {
            return Math.round(this.gen(value, variability) * 1000) / 1000;
        },

        'genByte': function (value, variability) {
            return Math.round(this.gen(value, variability) / 4) * 4;
        },

        /*'timeVar': function (value, variation) {
            if (!variation)
                return value;
            return this.genTime(value - variation, value + variation);
        },*/

        'position': function position(distance, variability) {
            var d = this.gen(distance, variability);
            var a = Math.random() * 2 * Math.PI;
            return [Math.floor(d * Math.cos(a)), Math.floor(d * Math.sin(a))];
        },

        'string': function genString(count, base) {
            var str = "";
            for (var i = 0; i < count; i++) {
                str += (Math.floor(Math.random() * base)).toString(base);
            }
            return str;
        },
    },

    setIPAuto: function (ue, sim) {
        for (var time = 0; time < Number.POSITIVE_INFINITY; time = range[1]) {
            var range = this._getOnRange(ue, time);
            if (!range) break; // No more range

            this.setIP(ue, sim, range);
        }
    },

    genStringValidator: function (string, pattern, size) {

        var m = string.match(this.genStringRegExp);
        if (m) {
            // Replacement will generate at least one character
            string = string.replace(this.genStringRegExp, '0');

            if (size && string.length > size) return false;

        } else {
            if (size && string.length !== size) return false;
        }

        return !!string.match(pattern);
    },

    genStringRegExp: /\$({([^}]+)})?/,

    genStringUpdate: function(string, size, value, base) {

        var m = string.match(this.genStringRegExp);
        if (m) {
            var pattern = m[0];
            value >>= 0;

            // ${f(i)}
            if (m[2]) {
                try {
                    value = Math.abs(Function('"use strict"; return ' + m[2].replace(/i/g, value) + ';')() >> 0);
                    if (isNaN(value))
                        value = 0;
                } catch (e) {
                    value = 0;
                }
            }

            var len = size - string.length + pattern.length;
            value = value.toString(base);
            while (value.length < len) value = '0' + value;
            string = string.replace(pattern, value);
        }
        while (string.length < size) string = '0' + string;
        return string;
    },

    genString: function(string, size, value, base) {
        return this.genStringUpdate(string, size, value, base).substr(0, size);
    },

    genStringExec: function (string, vars) {

        for (;;) {
            var m = string.match(/\$([\w\d]+)\b/);
            if (!m)
                break;

            var value = vars[m[1]];
            if (value === undefined)
                return null;

            string = string.replace(m[0], value);
        }

        for (;;) {
            var m = string.match(/\${([^}]+)}/);
            if (!m)
                break;

            var exp = m[1];
            for (var v in vars)
                exp = exp.replace(new RegExp("\\b" + v + "\\b", "g"), vars[v]);

            try {
                value = Function('"use strict"; return ' + exp + ';')() - 0;
                if (isNaN(value))
                    return null;

            } catch (e) {
                return null;
            }
            string = string.replace(m[0], value);
        }
        return string;
    },

    _setIPMsg: function(msg, cfg) {

        var msg_type = this.getIpDefinition(cfg.type).msg;

        msg.message = msg_type;
        switch (cfg.direction) {
        case 'all':
            if (cfg.type !== 'tcp') {
                var msg1 = lteLogs.clone(msg);
                msg.message = msg_type + '_send';
                msg1.message = msg_type + '_recv';
                return [msg1, msg];
            }
            break;
        case 'dl':
            if (cfg.type !== 'tcp') {
                msg.message = msg_type + '_recv';
            } else {
                msg.direction = 'rx';
            }
            break;
        case 'ul':
            if (cfg.type !== 'tcp') {
                msg.message = msg_type + '_send';
            } else {
                msg.direction = 'tx';
            }
            break;
        default:
            break;
        }
        if (cfg.apn) msg.apn = cfg.apn;

        return [msg];
    },

    setIP: function (ue, sim, range) {

        var random = lteSim.random;
        var rangeSize  = range[1] - range[0];
        var rangeStart = range[0];
        var rangeEnd   = range[1];

        this.info("Range:", rangeStart, rangeEnd);

        var apnConnected = {}; // Avoid multiple pdn_connect on same apn

        // Create final script
        sim.scripts.forEach( (cfg) => {

            if (Math.random() > cfg.probability) return;

            // Mandatory part
            var start_time = random.genTime(rangeStart + cfg.start_delay, cfg.start_delay_var);
            var end_time   = random.genTime(start_time + cfg.duration, cfg.duration_var);

            var msg = {
                ue_id:       ue.ue_id,
                start_time:  start_time,
                end_time:    end_time,
            };
            var script = {
                type:        cfg.type,
                time:        start_time,
                duration:    end_time - start_time,
                ip:          !cfg.noIp,
            };

            this.info(ue.imsi, "Add script", start_time.toFixed(3), end_time.toFixed(3));
            if (end_time > rangeEnd) {
                this.warn(ue.imsi, "Script too long for power on period:", end_time, rangeEnd);
                script.overflow = true;
            }

            // Specific part
            switch (cfg.type) {
            case 'udp':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.type = 'udp';
                break;
            case 'rtp':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.type = 'rtp';
                break;
            case 'voip':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.vaf                        = random.gen(cfg.vaf, cfg.vaf_var);
                msg.mean_talking_duration    = random.gen(cfg.mean_talking_duration, cfg.mean_talking_duration_var);
                msg.type = 'voip';
                break;
            case "flood":
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                break;
            case 'tcp':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.connections = cfg.connections;
                if (cfg.window_size)
                    msg.window_size = cfg.window_size;
                script.threshold = cfg.threshold;
                break;
            case "ping":
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.delay                    = cfg.delay;
                msg.id                        = cfg.id || random.genIntRange(1, 65535);
                break;
            case "http":
                if (ue.tun_setup_script) return;
                msg.url                        = cfg.url;
                msg.max_delay                = cfg.max_delay;
                msg.max_cnx                    = cfg.max_cnx;
                break;
            case 'app':
                if (!ue.tun_setup_script) return;
                msg.prog                    = cfg.prog;
                msg.delay                    = cfg.delay;
                msg.tag                        = cfg.tag;
                msg.args                    = [this.genStringExec(cfg.args, {d: cfg.duration, i: ue.ue_id})];
                break;
            case 'ethernet':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len             = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.type = 'ethernet';
                break;

            case 'register':
                var msg1 = lteLogs.clone(msg);
                msg1.start_time = msg.end_time;
                msg.message = 'register';
                msg1.message = 'deregister';
                delete msg.end_time;
                delete msg1.end_time;
                script.msg = [msg, msg1];
                break;

            default:
                break;
            }
            if (!script.msg)
                script.msg = this._setIPMsg(msg, cfg);
            script.name = cfg.name || this.getIpDefinition(cfg.type).name;
            script.category = 'UE #' + ue.ue_id;
            ue.scripts.push(script);

            // PDN
            var apn = cfg.apn;
            if (apn) {
                if (!apnConnected[apn]) {
                    for (var i = 0; i < sim.pdn.length; i++) {
                        var pdn = sim.pdn[i];
                        if (pdn.name === apn && pdn.connect === 'demand') {
                            script.msg.unshift(this._getPDNConnectMsg(pdn, ue.ue_id, start_time));
                            break;
                        }
                    }
                    apnConnected[apn] = true;
                }
            }

        });
    },

    _getPDNConnectMsg: function (pdn, ue_id, time) {
        return {
            message: 'pdn_connect',
            ue_id: ue_id,
            apn: pdn.name,
            pdn_type: pdn.type,
            start_time: time
        };
    },

    adjustTime: function(t) {
        return Math.round(t * 1000) / 1000;
    },

    _getOnRange: function _getOnRange(ue, time) {

        for (var i = 0; i < ue.scripts.length; i++) {
            var script = ue.scripts[i];
            if (script.type !== 'power') continue;

            if (time < script.time || (time >= script.time && time < script.time + script.duration))
                return [script.time, script.time + script.duration];
        }
        return null;
    },

    // On/off
    setOnOff: function (ueList, sim, start_delay) {
        var cfg = sim.power;

        // Merge default properties
        cfg = lteLogs.merge(lteLogs.clone(cfg), {
            duration:    [20, 20],
            on_time:    [10, 10], // On between 10 and 15s
            off_time:    [5, 10],
            caps:        2,
            on_max:        10,
        });

        var ue_count    = ueList.length;
        var min_delay    = 1 / cfg.caps;
        var caps_var    = cfg.caps_var / cfg.caps / 2;

        // Each UE:
        var ue_state = ueList.map(function (ue, id) { return {
            on_time:    0,
            off_time:    Number.NEGATIVE_INFINITY,
            id:            id,
            events:        []
        };});

        // Add and remove
        var duration = lteSim.random.genTime(cfg.duration);
        this.info("Generate power script for " + duration + "s");
        for (time = 0; time < duration;) {

            // Get powered on UE
            var on_list = ue_state.filter(function (ue) { return time < ue.off_time; });

            var available_list = ue_state.filter(function (ue) { return time >= ue.on_time; });

            this.info("[" + time.toFixed(2) + "] Check, on = " + on_list.length + ", available = " + available_list.length);
            if (available_list.length > 0 && on_list.length < cfg.on_max) {
                // Select off UE
                var id = lteSim.random.genIntRange(0, available_list.length - 1);
                var ue = available_list[id];

                // Power on time
                var start = time;
                if (caps_var)
                    start += lteSim.random.genTime(0, caps_var);

                // Power off time
                var end = start + lteSim.random.genTime(cfg.on_time, cfg.on_time_var);
                if (caps_var)
                    end += lteSim.random.genTime(0, caps_var);

                // Add power on/off event
                if (end <= duration) {
                    if (start < 0) start = 0; // In case of caps_var

                    ue.events.push({
                        id:     id,
                        start:  lteSim.adjustTime(start) + start_delay,
                        end:    lteSim.adjustTime(end) + start_delay
                    });
                    this.info("[" + time.toFixed(2) + "] Add " + ueList[id] + ", from " + start.toFixed(3) + " to " + end.toFixed(3));
                }

                // Next power off/on events
                ue.off_time = end + min_delay;
                ue.on_time  = end + lteSim.random.genTime(cfg.off_time, cfg.off_time_var);

                // Update
                time += min_delay;

            } else {
                this.info("[" + time.toFixed(2) + "] No space left");

                // No slot available, look for next time
                var next_time = Number.POSITIVE_INFINITY;
                ue_state.forEach(function (ue) {
                    if (ue.off_time > time)
                        next_time = Math.min(next_time, ue.off_time);
                    if (ue.on_time > time)
                        next_time = Math.min(next_time, ue.on_time);
                });
                time = next_time;
            }
        }

        // Add scripts
        ue_state.forEach((ue) => {
            ue.events.forEach((event) => {
                var ue_id = ueList[ue.id].ue_id;

                var msgList = [{
                    message:    'power_on',
                    ue_id:        ue_id,
                    start_time: event.start
                }, {
                    message:    'power_off',
                    ue_id:        ue_id,
                    start_time: event.end
                }];
                sim.pdn.forEach( (pdn) => {
                    if (pdn.connect === 'attach') {
                        msgList.push(this._getPDNConnectMsg(pdn, ue_id, event.start));
                    }
                });

                ueList[ue.id].scripts.push({
                    type:        'power',
                    name:        'Power on/off',
                    category:    'UE #' + ue_id,
                    time:        event.start,
                    duration:    event.end - event.start,
                    msg:         msgList,
                });
            });
        });
    },

    ue2db: function (def, chan, ue_id, cfg, idx) {

        var ue = {
            ue_id:      ue_id,
            imsi:       lteSim.genString(def.imsi, 15, ue_id),
            imeisv:     lteSim.genString(cfg.imeisv || "01234567$01", 16, ue_id),
            sim_algo:   def.sim_algo,
            scripts:    [],
        };

        if (chan.type !== 'none') {
            var angle = this.random.gen(chan.initial_angle, chan.initial_angle_var, -180, 180);
            if (chan.initial_radius) {
                var dist = this.random.gen(chan.initial_radius, chan.initial_radius_var, chan.min_distance, chan.max_distance);
            } else {
                var dist = this.random.genInt(chan.min_distance, chan.max_distance);
            }
            ue.max_distance = chan.max_distance;
            ue.min_distance = chan.min_distance;
            ue.bounce = chan.bounce;
            ue.noise_spd = chan.noise_spd;
            ue.position = [dist * Math.cos(angle), dist * Math.sin(angle)];
            ue.speed = this.random.gen(chan.speed, chan.speed_var, 0);
            ue.direction = this.random.gen(chan.direction, chan.direction_var, -180, 180);
            ue.channel = {type: chan.type};
            ue.channel_sim = true;
            if (chan.type !== 'awgn') {
                ue.channel.freq_doppler = chan.freq_doppler;
                if (chan.mimo_corr !== 'none')
                    ue.channel.mimo_correlation = chan.mimo_corr;
                ue.channel.A = chan.A;
                ue.channel.B = chan.B;
                switch (chan.type) {
                case 'tdla':
                case 'tdlb':
                case 'tdlc':
                case 'tdld':
                case 'tdle':
                    ue.channel.delay_spread = chan.delay_spread;
                    break;
                }
            }
        } else {
            ue.channel_sim = false;
        }

        switch (def.sim_algo) {
        case 'milenage':
            if (def.opc !== '') {
                ue.opc = lteSim.genString(def.opc, 32, idx, 16);
            } else {
                ue.op = lteSim.genString(def.op, 32, idx, 16);
            }
            ue.K = lteSim.genString(def.K, 32, idx, 16);
            break;
        case 'tuak':
            ue.top = lteSim.genString(def.top, 64, idx, 16);

            ue.K = lteSim.genStringUpdate(def.K, 32, idx, 16);
            if (ue.K.length > 32)
                ue.K = lteSim.genString(def.K, 64, idx, 16);
            break;
        case 'external':
            ue.external_sim = true;
            delete ue.imsi;
            delete ue.sim_algo;
            break;
        default:
            ue.K = lteSim.genString(def.K, 32, idx, 16);
            break;
        }
        if (def.res_len)
            ue.res_len = def.res_len;

        if (def.apn) {
            ue.apn = def.apn;
            ue.attach_pdn_type = def.attach_pdn_type;
        }

        switch (def.type) {
        case 'sim':
            break;
        case 'tun':
            ue.tun_setup_script = def.tun_setup_script;
            break;
        case 'rue':
            ue.tun_setup_script = def.tun_setup_script;
            ue.rue_addr = def.rue_addr;
            break;
        }
        // NEWPARAM: set json
        if (def.forced_cqi >= 0)
            ue.forced_cqi = def.forced_cqi;
        if (def.forced_ri > 0)
            ue.forced_ri = def.forced_ri;
        ue.spec_tolerance = def.spec_tolerance;
        ue.as_release = def.as_release;

        // UE rat
        var ratInfo = this.getRatInfo(def.rat);
        if (ratInfo.eutra) {
            switch (def.category) {
            case 'custom':
                ue.dl_category = def.dl_category;
                ue.ul_category = def.ul_category;
                break;
            case -1:
                ue.ue_category = 'm1';
                break;
            case -2:
                ue.ue_category = 'nb1';
                break;
            case -3:
                ue.ue_category = 'nb2';
                break;
            default:
                ue.ue_category = def.category;
                break;
            }
            if (ratInfo.eutra === 'endc') ue.en_dc_support = true;
        }
        if (ratInfo.nr) {
            if (ratInfo.rats[0] === 'nr') {
                if (ratInfo.eutra) {
                    if (!ue.dl_category) ue.dl_category = ue.ue_category;
                    if (!ue.ul_category) ue.ul_category = ue.ue_category;
                    ue.s1_support = true;
                }
                ue.ue_category = 'nr';
            } else {
                ue.n1_support = true;
            }
        }
        if (ratInfo.rat === 'lte' || ratInfo.rat === 'nbiot')
            ue.nas_5gs = def.nas_5gs;

        var cells = this.getCellIndexes(def.cell_index);
        if (cells) {
            var total = cells.reduce(function (w, cell) { return w + cell.weight; }, 0);

            var weight = Math.random() * total;
            for (var i = 0; i < cells.length; i++) {
                weight -= cells[i].weight;
                if (weight <= 0) {
                    ue.cell_index = cells[i].index;
                    ue.rrc_initial_selection = false;
                    break;
                }
            }
        }
        if (def.preferred_plmn_list)
            ue.preferred_plmn_list = def.preferred_plmn_list.split(/,/);

        if (def.mnc_3digits)
            ue.mnc_nb_digits = 3;

        return ue;
    },

    /*
     * sim: config generated by lte.sim.window
     * ue_ids: in cas of !sim.ue.enabled, apply scripts to this list of UEs
     */
    generateScripts: function (sim, ue_ids, cfg) {

        // Multi simulation
        if (!sim.multi) {
            sim = { multi: [sim] };
            var multi = false;
        } else {
            var multi = true;
        }

        var gen = {
            list:     [],
            scripts:  [],
            preReqs:  [],
            duration: 0
        };

        sim.multi.forEach( (sim) => {
            // Create UE ?
            if (sim.ue.count > 0) {
                var ueList = [];
                for (var i = 0; i < sim.ue.count; i++) {
                    ueList.push(this.ue2db(sim.ue, sim.chan, i + 1 + gen.list.length, cfg, i));
                }

            // Use UE
            } else {
                var ueList = ue_ids.map((function (ue_id) {
                    return {
                        "ue_id": ue_id,
                        "scripts": [],
                    };
                }).bind(this));
            }

            var start_delay = multi ? sim.start_delay : 0;

            // Power on/off
            if (sim.power.enabled) {
                this.setOnOff(ueList, sim, start_delay);

                ueList.forEach( (ue) => {
                    gen.preReqs.push({
                        message: 'power_off',
                        ue_id: ue.ue_id,
                    });

                    for (var time = 0; time < Number.POSITIVE_INFINITY; time = range[1]) {
                        var range = this._getOnRange(ue, time);
                        if (!range) break; // No more range
                        this.setIP(ue, sim, range);
                    }
                });

            } else {
                ueList.forEach( (ue) => {
                    this.setIP(ue, sim, [start_delay, Number.POSITIVE_INFINITY]);
                });
            }

            if (sim.chan.type !== 'none') {
                ueList.forEach( (ue) => {
                    gen.preReqs.push({
                        message: 'ue_move',
                        ue_id: ue.ue_id,
                        position: ue.position,
                        speed: ue.speed,
                        direction: ue.direction
                    });
                });
            }

            // Update ue_id and create full script list
            var scripts = [];
            var duration = 0;
            ueList.forEach((function (ue) {
                ue.scripts.forEach(function (script) {
                    scripts.push(script);
                    duration = Math.max(duration, script.time + script.duration);
                });
            }).bind(this));

            gen.list = gen.list.concat(ueList);
            gen.scripts = gen.scripts.concat(scripts);
            gen.duration = Math.max(gen.duration, duration);
        });

        // Sort scripts
        gen.scripts.sort(function (a, b) { return a.time - b.time; });

        return gen;
    },

    getRatInfo: function (rat) {
        var rats = (rat || '').split('|');
        var ratInfo = {
            eutra: false,
            endc: false,
            nr: false,
            multi: rats.length > 1,
            rat: rat,
            rats: rats,
        };
        rats.forEach( (r) => {
            switch (r) {
            case 'nbiot':
            case 'lte':
                ratInfo.eutra = r;
                break;
            case 'nsa':
                ratInfo.eutra = 'endc';
                ratInfo.multi = true;
                break;
            case 'nr':
                ratInfo.nr = true;
                break;
            }
        });
        return ratInfo;
    },

    updateSimConfig: function (sim) {

        for (var id in this.sections) {
            if (!sim.hasOwnProperty(id))
                sim[id] = lteLogs.clone(this.sections[id]);
        }

        // NEWPARAM: place default legacy value here
        lteLogs.merge(sim.ue, {
            type: 'sim',
            count: 0,
            category: 4,
            forced_ri: 0,
            forced_cqi: -1,
            as_release: 8,
            nas_5gs: false,
            dl_category: 10,
            ul_category: 10,
            spec_tolerance: false,
            purge_all: false,
            res_len: 0,
            imsi: "001010123456789",
            sim_algo: 'xor',
            K: "00112233445566778899aabbccddeeff",
            op: '',
            opc: '',
            top: '',
            tun_setup_script: "ue-ifup",
            rue_addr: "127.1.0.0",
            enabled: false,
            cell_index: '',
            preferred_plmn_list: '',
            attach_pdn_type: 'ipv4v6',
        });

        if (sim.chan.max_speed) {
            sim.chan.speed = sim.chan.speed_var = sim.chan.max_speed >> 1;
            delete sim.chan.max_speed;
        }

        lteLogs.merge(sim.chan, {
            max_distance:     500,
            min_distance:     0,
            speed:            50,
            speed_var:        10,
            direction:        0,
            direction_var:    180,
            initial_radius:   -1,
            initial_radius_var: 100,
            initial_angle:    0,
            initial_angle_var: 180,
            bounce:           'random',
            noise_spd:        -174,
            type:             'none',
            mimo_corr:        'none',
            delay_spread:     0,
            freq_doppler:     0,
            A:                15.3,
            B:                37.6,
        });
        lteLogs.merge(sim.power, {
            caps:            10,
            caps_var:        0,
            on_max:            10,
            on_time:        10,
            on_time_var:    0,
            off_time:        10,
            off_time_var:    0,
            duration:        30,
            enabled:    false
        });

        if (sim.loop === undefined) sim.loop = 0;

        var ue = sim.ue;
        switch (ue.rat) {
        case undefined:
            if (ue.category >= -1) {
                ue.rat = 'lte';
            } else {
                ue.rat = 'nbiot';
            }
            break;
        case 'lte-endc':
            ue.rat = 'nsa';
            break;
        }

        for (var i in sim.scripts) {
            var script = sim.scripts[i];

            var def = this.getIpDefinition(script.type);
            if (def) {
                lteLogs.merge(script, def.fields);
                lteLogs.merge(script, {
                    duration: 5,
                    duration_var: 0,
                    start_delay: 0,
                    start_delay_var: 0,
                    probability: 1,
                    apn: '',
                });
            }

            switch (script.type) {
            case 'cbr_send':
                script.type = 'udp';
                script.direction = 'ul';
                break;
            case 'cbr_recv':
                script.type = 'udp';
                script.direction = 'dl';
                break;
            case 'flood_send':
                script.type = 'flood';
                script.direction = 'ul';
                break;
            case 'flood_recv':
                script.type = 'flood';
                script.direction = 'dl';
                break;
            }
        }
        return sim;
    },

    getCellIndexes: function (val) {
        if (!val)
            return null;

        var indexes = val.split(',');
        for (var i = 0; i < indexes.length; i++) {
            var m = indexes[i].replace(/\s/g, '').match(/^([\d]+)(\/([\d\.]+))?$/);
            if (!m)
                return false;
            indexes[i] = {
                index: m[1] - 0,
                weight: parseFloat(m[3]) || 1
            };
        }
        return indexes;
    },

    init: function () {
        if (localStorage && localStorage.simLists !== undefined)
            this._enableTab();
    },

    _enableTab: function () {
        if (!this._simTab) {
            this._simTab = Ext.create('lte.sim.tab', {});
            lteLogs.addTab(this._simTab);
        }
    },

    _tabs: [],

    hasTabs: function () {
        return this._tabs.length > 0;
    },

    runOnAllTabs: function (sim) {
        this._tabs.forEach(function (tab) {
            tab.createUESimTab(sim);
        });
    },

    registerTab: function (tab) {
        this._enableTab();
        this._tabs.push(tab);
        this._simTab.updateButtons();
    },

    unregisterTab: function (tab) {
        var i = this._tabs.indexOf(tab);
        if (i >= 0) {
            this._tabs.splice(i, 1);
            this._simTab.updateButtons();
        }
    },

    get: function () {
        if (!this._simTab)
            return [];

        var list = [];
        var store = this._simTab._simStore;
        for (var i = 0, length = store.getCount(); i < length; i++) {
            list.push(store.getAt(i));
        }
        return list;
    },

    ueGetUpdate: function (ue_list) {
        ue_list.forEach((ue) => {
            if (!ue.pdn_list) ue.pdn_list = null;
            if (ue.cells) {
                ue.pci = ue.cells[0].pci;
                ue.rsrp = ue.cells[0].rsrp;
                ue.rsrq = ue.cells[0].rsrq;
                ue.snr = ue.cells[0].snr;
                ue.cell_index = ue.cells[0].index;
                ue.path_loss = ue.cells[0].path_loss;
            }
        });
        return ue_list;
    },

    _playerList: [],

    playerCancel: function (client) {
        this._playerList.forEach( (player) => {
            if (player.client === client) {
                player.stopTest();
            }
        });
    },

    playerAdd: function (player) {
        var idx = this._playerList.indexOf(player);
        if (idx < 0)
            this._playerList.push(player);
    },

    playerRemove: function (player) {
        var idx = this._playerList.indexOf(player);
        if (idx >= 0) {
            this._playerList.splice(idx, 1);
            return true;
        }
        return false;
    }
};

// Scenario player
var SimPlayer = function (sim, ue_ids, client, sendEvent)
{
    this._sim       = sim;
    this._ue_ids    = ue_ids || [];
    this._startDate = new Date();
    this.client     = client;
    this.sendEvent  = sendEvent;
    lteSim.playerAdd(this);
};

SimPlayer.prototype._testTimeout = 0;

SimPlayer.prototype.destroy = function ()
{
    this.stopTest();
    lteSim.playerRemove(this);
    this._closed = true;
};

SimPlayer.prototype.getGen = function ()
{
    return this._gen;
}

SimPlayer.prototype._reset = function ()
{
    this._gen = { scripts: [] }; /* Fake */
    this._globalStatus = this._genGlobalStatus();
    this._loopCount = 0;

    // Generate scripts
    this._gen = lteSim.generateScripts(this._sim, this._ue_ids, {imeisv: (lteLogs.hash(this.client.config.address) % 1e9) + '$01'});

    // Initialize display
    this._gen.list.forEach((ue) => {
        var sList = ue.scripts.filter(function (script) { return script.ip; });

        var curList = [];
        for (var i = 0; i < sList.length; i++) {
            var s0 = sList[i];

            s0.overlapList = [];
            s0.overlapMax = 0;

            // Purge
            for (var j = curList.length; j--;) {
                var s1 = curList[j];
                if (s1.time + s1.duration <= s0.time)
                    curList.splice(j, 1);
            }

            var n = curList.push(s0);

            for (var j = 0; j < curList.length; j++) {
                var s1 = curList[j];
                s1.overlapMax = Math.max(n, s1.overlapMax);
                s1.overlapList.push(s0);
                s0.overlapList.push(s1);
            }
        }

        this.sendEvent({ type: 'reset-ue', ue: ue });
    });

    clearTimeout(this._testTimeout);
    this._testTimeout = 0;
    this._testState = 'init';
    this.client.info("Start sim ", this._sim.name, "for", this._gen.list.length);
};

// Start
SimPlayer.prototype.start = function ()
{
    this._reset();

    // Create UE ?
    if (this._sim.ue.count) {
        lteLogs.load(true);

        var index = 0;
        var longList = this._gen.list.map(function (ue) {
            var cfg = {};
            for (var i in ue) {
                if (i !== "scripts")
                    cfg[i] = ue[i];
            }
            return cfg;
        });

        // Add UE by chunks
        var addUE = (resp) => {

            if (this._closed) return;

            if (resp) {
                var info = resp.info;
                var errors = info.filter(function (m) { return !m.match(/UE #\d+ already created/); });
                if (errors.length > 0) {
                    this.sendEvent({ type: 'error', error: lteLogs.htmlText(errors) });
                    lteLogs.load(false);
                    return;
                }
            }

            var shortList = longList.splice(0, 1000);
            if (!shortList.length) {
                lteLogs.load(false);
                this._startTest();
                return;
            }

            this.client.sendMessage({
                    message:    'ue_add',
                    text:        'Create UEs',
                    list:        shortList
                },
                addUE,
                true);
        };

        // First delete UEs
        if (this._sim.ue.purge_all) {
            this.client.sendMessage({ message: 'ue_del_all' }, (resp) => { addUE(); }, true);
        } else {
            this.client.sendMessage({
                    message:    'ue_del',
                    text:       'Delete UEs',
                    ue_id:      longList.map(function (ue) { return ue.ue_id; })
                },
                (resp) => { addUE(); },
                true
            );
        }
        return;
    }

    this._startTest();
};

SimPlayer.prototype.restart = function ()
{
    this._reset();
    this._startTest();
};

SimPlayer.prototype._startTest = function ()
{
    if (!this._gen.duration) {
        this.sendEvent({ type: 'none' });
        return;
    }

    this.sendEvent({ type: 'starting' });
    this._stopped = false;
    var count = this._gen.list.length;
    if (!count) {
        this._startTest1(); // XXX May never happen
    } else {
        this._gen.list.forEach((ue) => {
            this.client.sendMessage({message: 'cancel', group_id: ue.ue_id}, (msg) => {
                if (!(--count))
                    this._startTest1();
            });
        });
    }
};

SimPlayer.prototype._startTest1 = function ()
{
    this._testState = 'init';

    if (this._gen.preReqs.length > 0) {
        this.client.sendMessageList(this._gen.preReqs, (function (resp) {
            if (this._closed) return;
            this._startTest2();
        }).bind(this));
    } else {
        this._startTest2();
    }
};

SimPlayer.prototype._startTest2 = function ()
{
    this._testState = 'start';
};

SimPlayer.prototype._startTest3 = function ()
{
    // Init
    this.client.profileReset();

    var startTS = this._startTS;

    // Start scripts
    for (var i = 0, count = this._gen.scripts.length; i < count; i++) {
        var script = this._gen.scripts[i];

        script.color = null;
        script.ratio = 0;
        script.log = "Not started";
        script.status = "wait";
        script.output = '';
        script.error  = '';
        script.events = [];
        script.network = false;
        script.msg.forEach(function (m) { m.group_id = m.ue_id; });

        // Convert to absolute time
        var msgList = script.msg.map(function (m) {

            var m1 = Object.assign({absolute_time: true}, m);
            m1.start_time += startTS;
            if (m1.end_time !== undefined)
                m1.end_time += startTS;

            return m1;
        });

        switch (msgList[0].message) {
        case 'pdn_connect':
            var msg = msgList.shift();
            this.client.sendMessage(msg, (function (msgs, resp) {
                if (!this._closed)
                    this.client.sendMessageList(msgs, this._scriptMessageCallback.bind(this, script), true);

            }).bind(this, msgList), true);
            break;
        default:
            this.client.sendMessageList(msgList, this._scriptMessageCallback.bind(this, script), true);
            break;
        }
    };

    var now = new Date();
    this._startTime = now - 0;
    this._testState = 'run';
    this._statsDB = [];
    this._ueDB = [];
    this.sendEvent({ type: 'started' });
};

SimPlayer.prototype._scriptMessageCallback = function (script, respList, resp, index, end)
{
    // Protect
    if (this._closed) return;

    switch (script.type) {
    case 'power':
        if (resp.message === 'power_on') {
            script.status = 'start';
            script.log    = 'On';
        } else {
            script.status = 'done';
            script.log    = 'Off';
        }
        break;

    default:
        // Notification received
        if (resp.notification)
            return this._scriptMessageNotif(script, resp);

        resp.notification = 'progress'; // Fake
        this._scriptMessageNotif(script, resp);

        // Log
        if (end) {
            this._setScriptResult(script, respList);
            this.sendEvent({ type: 'script', script: script });
        }
        break;
    }

    if (this._testState === 'done')
        this._endTest();
};

SimPlayer.prototype.exportReport = function ()
{
    var csv = [];
    var sim = this._sim;

    // Config
    var cells = this.client.getParams('cells');
    csv.push("*** Config ***");
    for (var i in cells) {
        csv.push(['RB DL #' + i, cells[i].n_rb_dl]);
        csv.push(['RB UL #' + i, cells[i].n_rb_ul]);
    }
    if (!sim.multi && sim.power.enabled) {
        csv.push(["CAPS", sim.power.caps]);
        csv.push(["Max UE", sim.power.on_max]);
        csv.push(["Power on duration", sim.power.on_time]);
        csv.push(["Power off duration", sim.power.off_time]);
    }
    if (sim.ue.count) {
        csv.push(["UE", sim.ue.count]);
    } else {
        csv.push(["UE", this._ue_ids.length]);
    }
    csv.push("");

    // Scripts
    csv.push("*** Scripts ***");
    csv.push(["UE ID", "Name", "Type", "Start", "Stop", "Status", "Result"]);

    this._gen.scripts.forEach( (script) => {
        if (!script.ip) return;

        csv.push([
            script.category,
            script.name,
            script.type,
            script.time,
            script.time + script.duration,
            script.status,
            script.ratio * 100
        ]);
    });
    csv.push("");

    // Stats
    var ueSeries = lteLogs.ueSeries;

    csv.push("*** Stats ***");

    var line = ['Time'];
    for (var cell_index in cells) {
        (['br', 'sched']).forEach(function (id) {
            for (var i in UEConfig.series[id]) {
                line.push(UEConfig.series[id][i].title.replace(/<cell>/, cell_index));
            }
        });
    }
    csv.push(line);

    for (var i = 0; i < this._statsDB.length; i++) {
        var item = this._statsDB[i];
        var line = [item.time.toFixed(3)];
        for (var c in item.cells) {
            var cell = item.cells[c];

            (['br', 'sched']).forEach(function (id) {
                for (var j in UEConfig.series[id]) {
                    line.push(cell[j] | 0);
                }
            });
        }
        csv.push(line);
    }
    csv.push("");

    // UE
    csv.push("*** UEs ***");
    csv.push(['Time', 'UE id', 'CQI', 'RI', 'RSRP',
        'DL bitrate', 'DL rx', 'DL retx', 'DL mcs', 'DL RB',
        'UL bitrate', 'UL rx', 'UL retx', 'UL mcs', 'UL RB'
    ]);
    for (var i = 0; i < this._ueDB.length; i++) {
        var item = this._ueDB[i];
        for (var j = 0; j < item.ue_list.length; j++) {
            var ue = item.ue_list[j];
            var cell = ue.cells ? ue.cells[0] : ue;
            csv.push([
                item.time.toFixed(3),
                ue.ue_id,
                cell.cqi,
                cell.ri,
                cell.rsrp.toFixed(1),
                ue.dl_bitrate | 0,
                ue.dl_rx_count,
                ue.dl_retx_count,
                (ue.dl_mcs || 0).toFixed(1),
                ue.dl_rb !== undefined ? ue.dl_rb.toFixed(4) : '-',
                ue.ul_bitrate | 0,
                ue.ul_tx_count,
                ue.ul_retx_count,
                (ue.ul_mcs || 0).toFixed(1),
                ue.ul_rb !== undefined ? ue.ul_rb.toFixed(4) : '-',
            ]);
        }
    }
    csv.push("");

    // Format
    for (var i = 0; i < csv.length; i++) {
        var line = csv[i];
        if (line instanceof Array) {
            line = line.join(";");
        }
        csv[i] = line;
    }

    var date = new Date(this._startTime);
    var filename = sim.name + '-' + 
            ("0" + date.getFullYear()).slice(-4) +
            ("0" + (date.getMonth() + 1)).slice(-2) +
            ("0" + date.getDate()).slice(-2) + "-" +
            ("0" + date.getHours()).slice(-2) + ":" +
            ("0" + date.getMinutes()).slice(-2) + ":" +
            ("0" + date.getSeconds()).slice(-2) +
            '.csv';

    lteLogs.exportFile(csv.join("\n"), filename, 'text/csv;charset=utf-8;');
};

SimPlayer.prototype._genGlobalStatus = function ()
{
    var result  = 0;
    var ended   = 0;
    var started = 0;
    var error   = 0;
    var ok      = 0;
    var total   = 0;

    for (var i = 0, count = this._gen.scripts.length; i < count; i++) {
        var script = this._gen.scripts[i];
        if (!script.ip) continue;

        total++;
        switch (script.status) {
        case "start":
            started++;
            break;
        case "timeout":
        case 'cancel':
            ended++;
            error++;
            break;
        case "done":
            result += script.ratio;
            ended++;
            if (!script.ratio)
                error++;
            else if (script.ratio >= 1)
                ok++;
            break;
        }
    }
    return {
        result: result,
        ended: ended,
        started: started,
        error: error,
        ok: ok,
        total: total,
    };
};

// End
SimPlayer.prototype._endTest = function ()
{
    clearTimeout(this._testTimeout);
    if (this._testState !== 'done') {
        this.client.profileDump();
        this._testState = 'done';
        this._endDate = new Date() * 1;
    }

    if (!this._testTimeout) {
        if (!this._checkAllScriptDone()) {
            this._testTimeout = setTimeout(this._endTestTimeout.bind(this), 15000);
            return;
        }
    }
    var restart = !this._stopped && this._loopCount++ < this._sim.loop;

    if (restart) {
        var status = this._genGlobalStatus();
        for (var i in status) this._globalStatus[i] += status[i];
        this._startTest1();
    } else {
        this._loopCount--;
    }
    this.sendEvent({ type: 'end', restart: restart });
};

SimPlayer.prototype.getLoopCount = function ()
{
    return this._loopCount;
};

SimPlayer.prototype.getGlobalStatus = function (full)
{
    var status = this._genGlobalStatus();
    if (full)
        for (var i in status) this._globalStatus[i] += status[i];
    return status;
}

SimPlayer.prototype.stopTest = function ()
{
    switch (this._testState) {
    case 'run':
    case 'start':
        this._gen.list.forEach((function (ue) {
            this.client.sendMessage({message: 'cancel', group_id: ue.ue_id});
        }).bind(this));
        break;
    default:
        break;
    }

    this._stopped = true;
    this._endTest();
};

SimPlayer.prototype._checkAllScriptDone = function ()
{
    for (var i = 0; i < this._gen.scripts.length; i++) {
        var script = this._gen.scripts[i];
        if (script.status !== 'done' && script.status !== 'cancel') {
            return false;
        }
    }
    return true;
};

SimPlayer.prototype._endTestTimeout = function ()
{
    this._gen.scripts.forEach(function (script) {
        switch (script.status) {
        case 'done':
        case 'cancel':
            break;
        default:
            script.status = 'timeout';
            script.log    = 'Timeout';
            break;
        }
    });

    this._endTest();
    this._testTimeout = 0;
};


SimPlayer.prototype._setScriptResult = function (script, results)
{
    var globalRatio = 0;
    var log  = [];
    switch (script.type) {
    case "ping":
        var result = results[0];
        var report = result.report;
        if (report) {
            log.push(report.recv + "/" + report.sent + " replies");
            if (report.sent > 0)
                globalRatio = report.recv / report.sent;
        } else {
            log.push(result.error);
        }
        break;

    case "udp":
    case "ethernet":
    case "rtp":
    case "flood":
    case "voip":
        var ok = 0;
        var total = 0;
        for (var i = 0; i < results.length; i++) {
            var result = results[i];
            var report = result.report;
            var msg = script.msg[i];

            if (report) {
                total += report.sent;
                ok += report.recv;
                switch (msg.message) {
                case 'cbr_recv':
                case 'flood_recv':
                    if (report.sent > 0) {
                        var ratio = report.recv / report.sent;
                        log.push('DL: ' + Math.floor(ratio * 100) + '%, ' + report.recv + '/' + report.sent + ' packet(s) received');
                    }
                    break;

                case 'cbr_send':
                case 'flood_send':
                    if (report.sent > 0) {
                        var ratio = report.recv / report.sent;
                        log.push('UL: ' + Math.floor(ratio * 100) + '%, ' + report.recv + '/' + report.sent + ' packet(s) transferred');
                    }
                    break;
                }
            } else {
                log.push(result.error);
            }
        }
        if (total > 0)
            globalRatio = ok / total;
        break;

    case "http":
        var report = results[0].report;
        var rate = report.duration > 0 ? (8 * report.rx_size / report.duration / 1000000).toFixed(3) : 0;
        log.push(rate + " Mbps, " + (report.rx_size / 1000000).toFixed(3) + " MB, " + report.connections + " connection(s)");
        globalRatio = report.rx_size ? 1 : 0;
        break;
    case 'app':
        var res = SimCustomHandler(script.msg[0].tag, script.output.split(/\n/), script.error);
        globalRatio = Math.max(0, Math.min(1, res.ratio));
        log = res.log;
        if (typeof log === 'string')
            log = [log];
        break;
    case 'tcp':
        var report = results[0].report;
        globalRatio = 1;
        if (report.rx_size !== undefined) {
            var bitrate = 8 * report.rx_size / report.duration;
            log.push('DL: ' + lteLogs.formatBitrate(bitrate));
            globalRatio = Math.min(globalRatio, bitrate / script.threshold);
        }
        if (report.tx_size !== undefined) {
            var bitrate = 8 * report.tx_size / report.duration;
            log.push('UL: ' + lteLogs.formatBitrate(bitrate));
            globalRatio = Math.min(globalRatio, bitrate / script.threshold);
        }
        break;
    }
    var r = ('00' + Math.round((1 - globalRatio) * 255).toString(16)).slice(-2);
    var g = ('00' + Math.round(globalRatio * 255).toString(16)).slice(-2);
    var b = ('00' + Math.round(32).toString(16)).slice(-2);

    script.ratio    = globalRatio;
    script.log      = lteLogs.htmlText(log);
    script.color    = "#" + r + g + b;
    script.status   = "done";

    if (results[0].cancel)
        script.status = 'cancel';
};

SimPlayer.prototype._scriptMessageNotif = function (script, resp)
{
    var ts = resp.time - this._startTS - script.time;

    switch (resp.notification) {
    case 'start':
        if (script.status !== 'start') {
            script.status = 'start';
            script.log    = 'In progress...';

            this.sendEvent({ type: 'script', script: script });

            script.network = resp.network;
        }
        break;
    case 'info':
        if (resp.info)
            script.events.push(resp.info + ' at ' + ts.toFixed(1) + 's');
        break;
    case 'progress':
        if (resp.output) {
            script.output += resp.output;
        }
        if (resp.error) {
            script.error += resp.error;
        }
        if (script.type === 'tcp') {
            var log = [];
            if (resp.rx_size !== undefined)
                log.push('DL: ' + lteLogs.formatBitrate(8 * resp.rx_size / resp.duration));
            if (resp.tx_size !== undefined)
                log.push('UL: ' + lteLogs.formatBitrate(8 * resp.tx_size / resp.duration));
            script.log = log.join('<br/>');
        }
        break;
    }

    // Network state update
    if (resp.network !== undefined && script.network !== resp.network) {
        if (resp.network)
            script.events.push('Network up at ' + ts.toFixed(1) + 's');
        else
            script.events.push('Network down at ' + ts.toFixed(1) + 's');
        script.network = resp.network;
    }
};

SimPlayer.prototype.getTimestamp = function ()
{
    if (this._curTS === undefined)
        return -1;
    return this._curTS;
}

SimPlayer.prototype.eventListener = function (event) {

    switch (event.type) {
    case 'stats':
        var ts = event.data.time;
        switch (this._testState) {
        case 'start':
            this._startTS = ts + 1; // Start 1s later, let messages to arrive
            this._startTest3();
            // XXX: don't send all messages at once
            break;
        case 'run':
            break;
        default:
            return false;
        }

        // Timestamp
        this._curTS = ts = (ts - this._startTS) * 1000;

        // For each cell
        if (ts >= 0) {
            this._statsDB.push({time: (ts | 0) / 1000 , cells: event.data.cells});
        }

        // End ?
        clearTimeout(this._testTimeout);
        var limit = (this._gen.duration + 1) * 1000;
        if (ts >= limit) {
            this._curTS = limit;
            this._testTimeout = 0;
            this._endTest();
        } else {
            this._testTimeout = setTimeout( () => { this._endTestTimeout(); }, 10000);
        }
        break;
    case 'ue':
        switch (this._testState) {
        case 'run':
            var time = event.time - this._startTS;
            if (time >= 0) {
                this._ueDB.push({ time: time, ue_list: event.data });
            }
            break;
        }
        break;
    default:
        return false;
    }
    return true;
};



/* Nodejs mode */
var document;
if (process && !document) {
    var lteLogs = global.lteLogs;
    var Ext = global.Ext;
    module.exports = {
        lteSim: lteSim,
        createPlayer: function (sim, ue_ids, client, sendEvent) {
            return new SimPlayer(sim, ue_ids, client, sendEvent);
        },
        ueConfig: UEConfig,
    };
    lteSim.info = function () {};

    try {
        var SimCustomHandler = require('./libsim_custom.js').handler;
    } catch (e) {
        var SimCustomHandler = function (tag, output, error) {
            return {
                ratio: 0,
                log: "Custom handler not defined",
            }
        };
        console.error('Custom handler not defined');
    }
} else {
    lteLogs.setLogger("SIM", lteSim);
}



Ext.define("lte.sim.tab", {

    extend: 'Ext.panel.Panel',
    layout: 'border',

    title: 'UE Scenario',
    iconCls: 'icon-movie',

    tbar: {},

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {

        var newSimButton = Ext.create('Ext.Button', {
            text: 'Add',
            iconCls: 'icon-plus',
            scope: this,
            handler: function () {
                var cfg = lteSim.updateSimConfig({});
                simStore.add(cfg);
                simStore.sync();
            }
        });
        this._delSimButton = Ext.create('Ext.Button', {
            text: 'Remove',
            iconCls: 'icon-moins',
            scope: this,
            disabled: true,
            handler: function () {
                var record = simGrid.getSelection();
                simStore.remove(record[0]);
                simStore.sync();
            }
        });
        this._copySimButton = Ext.create('Ext.Button', {
            text: 'Copy',
            iconCls: 'icon-copy',
            scope: this,
            disabled: true,
            handler: function () {
                var sim = simGrid.getSelection()[0];
                var copy = lteLogs.clone(sim.getData());
                delete copy.id;
                copy.name = copy.name + " (copy)";
                simStore.add(copy);
            }
        });
        this._exportUESimButton = Ext.create('Ext.Button', {
            text: 'UE export',
            iconCls: 'icon-file',
            scope: this,
            tooltip: lteLogs.tooltip("Export scenario for UE configuration"),
            disabled: true,
            handler: function () {
                this._getSelectedSim(simGrid.getSelection(), false, (sim) => {
                    if (sim)
                        this._exportUESim(sim);
                });
            }
        });
        this._exportSimButton = Ext.create('Ext.Button', {
            text: 'Export',
            iconCls: 'icon-download',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip("Export scenario"),
            handler: function () {
                this._exportSim(simGrid.getSelection());
            }
        });
        this._importSimButton = Ext.create('Ext.Button', {
            text: 'Import',
            iconCls: 'icon-save',
            scope: this,
            tooltip: lteLogs.tooltip("Import scenario"),
            handler: function () {
                this._importSim();
            }
        });
        this._runSimButton = Ext.create('Ext.Button', {
            text: 'Run',
            iconCls: 'icon-play',
            tooltip: 'Run on all clients',
            disabled: true,
            scope: this,
            handler: function () {
                this._getSelectedSim(simGrid.getSelection(), true, (sim) => {
                    if (sim)
                        lteSim.runOnAllTabs(sim);
                });
            }
        });

        this.tbar = Ext.create('Ext.toolbar.Toolbar', {
            items: [
                newSimButton,
                this._delSimButton,
                this._copySimButton,
                this._exportSimButton,
                this._importSimButton,
                '|',
                this._exportUESimButton,
                this._runSimButton,
            ]
        });

        this.callParent(arguments);

        // Store: from local data
        var simStore = this._simStore = Ext.create('Ext.data.Store', {
            fields: ['name', 'scripts'].concat(Object.keys(lteSim.sections)),
            pageSize: 1000,
            proxy: {
                type: 'localstorage',
                id  : 'simLists'
            },
            listeners: {
                scope: this,
                load: function (s, records, success, eOpts) {
                    if (success) {
                        for (var i in records) {
                            var rec = records[i];
                            var data = rec.getData();
                            lteSim.updateSimConfig(data);
                            for (var id in lteSim.sections)
                                rec.set(id, data[id]);
                        }
                        simStore.sync();
                    }
                }
            }
        });

        var simGrid = this._simGrid = Ext.create('Ext.grid.Panel', {
            store: simStore,
            allowDeselect: true,
            multiSelect: true,
            columns: [{
                text: "Name",
                dataIndex: "name",
                flex: 1
            }, {
                text: "Dur.",
                dataIndex: "power",
                align: 'right',
                width: 60,
                renderer: function(power, metaData, record, rowIndex, colIndex, store, view) {
                    if (power.enabled)
                        return power.duration;
                    var scripts = record.get("scripts");
                    return scripts.reduce(function (d, s) { return Math.max(d, s.start_delay + s.duration); }, 0) || "&nbsp;";
                }
            }, {
                text: "UE",
                dataIndex: "ue",
                align: 'right',
                renderer: function(ue, metaData, record, rowIndex, colIndex, store, view) {
                    return ue.count > 0 ? ue.count : "&nbsp;";
                },
                width: 50
            }, {
                text: "IP",
                dataIndex: "scripts",
                align: 'right',
                renderer: function(scritps, metaData, record, rowIndex, colIndex, store, view) {
                    return scritps.length;
                },
                width: 50
            }, {
                text: "Power",
                dataIndex: "power",
                renderer: function(power, metaData, record, rowIndex, colIndex, store, view) {
                    if (power.enabled)
                        return power.caps + " caps, " + power.on_time + "/" + power.off_time + " on/off";
                    return "&nbsp;";
                },
                flex: 1,
            }],
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {

                    simPanel.removeAll();
                    if (selected.length === 1) {
                        var script = selected[0];
                        setTimeout(() => {
                            simPanel.add(Ext.create('lte.sim.panel', {
                                simRef: script,
                                simStore: simStore,
                                updateParent: (function () { this.updateButtons(); }).bind(this)
                            }));
                            this.updateButtons();
                        });
                    }
                },
            }
        });

        // Load
        Ext.Function.defer(function () { simStore.load();}, 100);

        this.add({
            region: 'center',
            layout: 'fit',
            items: [simGrid],
        });
        
        var simPanel = this.add({
            region: 'east',
            layout: 'fit',
            width: 600,
            items: [],
            split: true,
        });
    },

    _getSelectedSim: function (selection, run, cb) {

        if (!selection || !selection.length)
            return false;

        if (selection.length === 1) {
            cb(selection[0].getData());
            return true;
        }

        var data = [];
        var sims = { multi: [], name: '', loop: 0, ue: { count: 0 }};
        for (var i = 0; i < selection.length; i++) {
            var sim = selection[i].getData();
            sims.multi.push(sim);
            sims.ue.count += sim.ue.count;

            data.push({
                name: sim.name,
                delay: sim.start_delay || 0,
                sim: sim,
                rec: selection[i],
            });
        }
        sims.name = data.map( (d) => { return d.name; }).join(' / ');

        var simGrid = Ext.create('Ext.grid.Panel', {
            frameHeader: false,
            store: {
                fields: ['name', 'delay', 'sim', 'rec'],
                data: data,
            },
            viewConfig:{
                markDirty: false
            },
            selType: 'cellmodel',
            plugins: [Ext.create('Ext.grid.plugin.CellEditing', {clicksToEdit: 1})],
            columns: [{
                text: "Scenario",
                dataIndex: "name",
                width: 280,
            }, {
                text: "Start delay (s)",
                dataIndex: 'delay',
                editor: {
                    xtype: 'numberfield',
                    maxValue: 86400 * 10,
                    minValue: 0,
                },
            }],
            width: '100%',
        });

        var simName = Ext.create("Ext.form.field.Text", {
            fieldLabel: 'Name',
            value: sims.name,
            width: '100%',
            padding: 5,
        });

        var items = [simGrid, simName];
        if (run) {
            var simLoop = Ext.create("Ext.form.field.Number", {
                fieldLabel: 'Loop',
                value: sim.loop || 0,
                allowDecimals: false,
                minValue: 0,
                maxValue: 1000000,
                width: '100%',
                padding: 5,
            });
            items.push(simLoop);
        }

        var mySim = null;

        var win = Ext.create('Ext.window.Window', {
            title: lteLogs.getHTMLIcon('icon-ue') + ' Multi scenario',
            width: 550,
            height: 300,
            modal: true,
            constraint: true,
            maximizable: false,
            layout: 'vbox',
            items: items,
            bbar: [
                {
                    xtype: 'button',
                    text: 'Cancel',
                    handler: function () {
                        win.close();
                    }
                },
                '->',
                {
                    xtype: 'button',
                    text: 'Ok',
                    handler: () => {
                        for (var i = 0; i < simGrid.store.getCount(); i++) {
                            var rec = simGrid.store.getAt(i);
                            rec.get('sim').start_delay = rec.get('delay');
                            rec.get('rec').set('start_delay', rec.get('delay'));
                        }
                        mySim = sims;
                        sims.name = simName.getValue();
                        sims.loop = simLoop.getValue();
                        win.close();
                        this._simStore.sync();
                    }
                }
            ],
            listeners: {
                scope: this,
                close: function(panel, eOpts) {
                    cb(mySim);
                }
            }
        });
        win.show();
    },

    updateButtons: function () {

        var script = this._simGrid.getSelection();
        if (script && script.length) {
            if (script.length === 1) {
                var data = script[0].getData();
                this._delSimButton.setDisabled(false);
                this._copySimButton.setDisabled(false);
                this._exportSimButton.setDisabled(false);
                this._exportUESimButton.setDisabled(data.ue.count <= 0);
            } else {
                this._delSimButton.setDisabled(true);
                this._copySimButton.setDisabled(true);
                this._exportSimButton.setDisabled(true);
            }
            this._runSimButton.setDisabled(!lteSim.hasTabs());
        } else {
            this._delSimButton.setDisabled(true);
            this._copySimButton.setDisabled(true);
            this._exportSimButton.setDisabled(true);
            this._exportUESimButton.setDisabled(true);
            this._runSimButton.setDisabled(true);
        }
    },

    _exportSim: function (selection) {

        Ext.Msg.prompt('Export scenario', 'Enter export name:', function (btn, name) {

            if (btn !== 'ok')
                return;

            var exp = {
                version: UE_SCENARIO_VERSION,
                date: new Date() * 1,
                scenario: [],
                name: name,
            };

            var count = selection.length;
            for (var i = 0; i < count; i++) {
                var sim = selection[i].getData();
                sim = lteLogs.clone(sim);
                delete sim.id;
                exp.scenario.push(sim);
            }

            lteLogs.exportFile(JSON.stringify(exp), 'ue-scenario-' + name + '.cfg', 'application/json;charset=utf-8;');
        });
    },

    _importSim: function () {
        lteLogs.loadFile({
            cb: function (files) {
                if (!files)
                    return;

                try {
                    var exp = JSON.parse(new TextDecoder().decode(files[0].data));
                    if (!(exp.scenario instanceof Array) ||
                        typeof exp.version !== 'number' ||
                        typeof exp.date !== 'number' ||
                        typeof exp.name !== 'string' ||
                        !exp.version ||
                        !exp.date ||
                        !exp.name)
                        throw('Bad file format');

                    exp.scenario.forEach((function (sim) {
                        sim.name = '[' + exp.name + '] ' + sim.name;
                        this._simStore.add(lteSim.updateSimConfig(sim))
                    }).bind(this));

                } catch (e) {
                    lteLogs.warnBox('Can\'t load file', 'Bad file format');
                    return;
                }
            },
            scope: this
        });
    },

    _exportUESim: function (sim, cfg) {
        var gen = lteSim.generateScripts(sim, cfg, {imeisv: ((Math.random() * 1000000) >>> 0) + '$01'});

        // UE config
        gen.list.forEach(function (ue) {
            // Generate events from message
            var events = [];
            for (var i = 0; i < ue.scripts.length; i++) {
                var script = ue.scripts[i];
                for (var j = 0; j < script.msg.length; j++) {
                    var msg = script.msg[j];
                    msg.event = msg.message;
                    delete msg.message;
                    delete msg.ue_id;
                    events.push(msg);
                }
            }
            events.sort(function (a, b) { return a.start_time - b.start_time; });
            ue.sim_events = events;
            delete ue.scripts;
        });
        var mme_db = [];
        gen.list.forEach(function (ue) {
            if (ue.external_sim) return;

            var mme = {
                imsi: ue.imsi,
                K: ue.K,
                amf: 0x9001, // XXX
                sqn: "000000000000", // XXX
                sim_algo: ue.sim_algo,
            };
            (['opc', 'op', 'top', 'res_len']).forEach(function (id) {
                if (ue[id]) mme[id] = ue[id];
            });
            mme_db.push(mme);
        });

        gen.list.sort(function (a, b) {
            if (!a.sim_events.length)
                return 1;
            if (!b.sim_events.length)
                return -1;
            return a.sim_events[0].start_time - b.sim_events[0].start_time;
        });

        // Export
        lteLogs.exportFile('ue_list: ' + JSON.stringify(gen.list, null, 2), sim.name + '.ue.cfg', 'text/json;charset=utf-8;');
        lteLogs.exportFile('ue_db: ' + JSON.stringify(mme_db, null, 2), sim.name + '.mme.cfg', 'text/json;charset=utf-8;');

    },

});


